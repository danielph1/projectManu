import hashlib
import hmac
import secrets
from datetime import date, timedelta
from typing import Any, Dict, Optional, Set
from extra_streamlit_components import CookieManager
import time
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text

cookie_manager = CookieManager()

# ---------------------------------------------------------------------------
# CADASTRO ABERTO (Supabase Auth)
# True  = mostra aba "Criar conta" na tela de login (fase de implantação)
# False = só login (produção / sigilo — funcionários já cadastrados)
# ---------------------------------------------------------------------------
CADASTRO_ABERTO = True


from datetime import datetime, timedelta

# Duração do cookie quando "Lembrar-me" está marcado (dias).
SESSAO_DIAS_LEMBRAR = 14
# Sem "Lembrar-me": sessão curta (horas) — evita ficar preso logado.
SESSAO_HORAS_SEM_LEMBRAR = 12

CHAVES_SESSAO = [
    "usuario_logado",
    "filtro_categoria",
    "pagina_atual",
    "chat_vendedor_selecionado",
    "abrir_formulario",
    "filtro_vendedor_id",
    "busca_lead_campo",
    "busca_lead_aplicada",
    "busca_estoque_campo",
    "busca_estoque_aplicada",
    "busca_ficha_campo",
    "busca_ficha_aplicada",
    "fichas_limite",
    "fichas_filtro_chave",
    "ficha_detalhe_id",
    "transferencia_aberta_id",
    "busca_oficina_campo",
    "busca_oficina_aplicada",
    "logout_pendente",
]


def _dados_cookie_usuario(usuario: dict) -> dict:
    return {
        "id": int(usuario["id"]) if usuario.get("id") is not None else None,
        "nome": str(usuario.get("nome") or ""),
        "login": str(usuario.get("login") or ""),
        "tipo": str(usuario.get("tipo") or ""),
        "tipo_original": str(usuario.get("tipo_original") or ""),
        "vendedor_id": (
            int(usuario["vendedor_id"])
            if usuario.get("vendedor_id") is not None
            else None
        ),
        "loja": str(usuario.get("loja") or "381"),
        "is_admin": bool(usuario.get("is_admin", False)),
    }


def salvar_sessao(usuario: dict, lembrar: bool = False):
    """
    Persiste login em cookie.
    lembrar=True  → até SESSAO_DIAS_LEMBRAR dias
    lembrar=False → poucas horas (fecha o browser e some em breve)
    """
    dados = _dados_cookie_usuario(usuario)
    if lembrar:
        expira = datetime.now() + timedelta(days=SESSAO_DIAS_LEMBRAR)
    else:
        expira = datetime.now() + timedelta(hours=SESSAO_HORAS_SEM_LEMBRAR)
    try:
        cookie_manager.set("usuario_logado", dados, expires_at=expira)
    except Exception:
        pass


def carregar_sessao():
    """
    Lê o cookie. IMPORTANTE: chamar em todo rerun para o CookieManager
    montar o componente (senão delete/set não aplicam).
    """
    try:
        valor = cookie_manager.get("usuario_logado")
        if not valor or not isinstance(valor, dict):
            return None
        if not valor.get("id"):
            return None
        return valor
    except Exception:
        return None


def limpar_sessao():
    """
    Logout de verdade:
    1) marca logout_pendente (impede recarregar cookie no próximo run)
    2) apaga cookie (delete + set vazio expirado)
    3) zera session_state
    4) rerun → tela de login
    """
    st.session_state["logout_pendente"] = True
    st.session_state["usuario_logado"] = None

    try:
        cookie_manager.delete("usuario_logado")
    except Exception:
        pass
    try:
        # Garante expiração imediata (alguns browsers ignoram só o delete)
        cookie_manager.set(
            "usuario_logado",
            {},
            expires_at=datetime(1970, 1, 1),
        )
    except Exception:
        pass

    for chave in CHAVES_SESSAO:
        if chave == "logout_pendente":
            continue
        st.session_state.pop(chave, None)

    st.session_state["usuario_logado"] = None
    st.session_state["logout_pendente"] = True
    st.rerun()
# ============================================================
# CONFIGURAÇÃO
# ============================================================

st.set_page_config(
    page_title="Manu Automoveis",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ===========================================================================
# TEMA VISUAL — altere os valores HEX abaixo para mudar as cores do app.
# Depois de mudar, salve e recarregue a página (Ctrl+R / F5).
# ===========================================================================
COR_FUNDO       = "#0b0f14"   # fundo geral da página
COR_SIDEBAR     = "#121820"   # barra lateral
COR_CARD        = "#161d27"   # cards / expanders
COR_BORDA       = "#243041"   # bordas sutis
COR_PRIMARIA    = "#3b82f6"   # botão ativo / destaque
COR_PRIMARIA_2  = "#2563eb"   # hover do botão ativo
COR_SUCESSO     = "#22c55e"   # aprovado / pronto
COR_AVISO       = "#eab308"   # pendente
COR_ERRO        = "#ef4444"   # negado / sair
COR_TEXTO       = "#e8eef7"   # texto principal
COR_TEXTO_MUTED = "#94a3b8"   # legendas / secundário
COR_INPUT       = "#1a2330"   # campos de formulário

st.markdown(
    f"""
    <style>
    /* Só esconde o que polui o rodapé: GitHub + "Made with Streamlit" / coroa.
       Sidebar e header ficam 100% normais (botão nativo de recolher/expandir). */
    footer {{visibility: hidden !important; height: 0 !important;}}
    a[href*="github.com"] {{display: none !important;}}
    a[href*="streamlit.io"] {{display: none !important;}}
    .viewerBadge_container__1QSob,
    .viewerBadge_link__1SLeB,
    .viewerBadge_text__1JaDK {{
        display: none !important;
    }}

    :root {{
        --cor-fundo: {COR_FUNDO};
        --cor-sidebar: {COR_SIDEBAR};
        --cor-card: {COR_CARD};
        --cor-borda: {COR_BORDA};
        --cor-primaria: {COR_PRIMARIA};
        --cor-primaria-2: {COR_PRIMARIA_2};
        --cor-sucesso: {COR_SUCESSO};
        --cor-aviso: {COR_AVISO};
        --cor-erro: {COR_ERRO};
        --cor-texto: {COR_TEXTO};
        --cor-texto-muted: {COR_TEXTO_MUTED};
        --cor-input: {COR_INPUT};
    }}

    .stApp {{
        background-color: var(--cor-fundo) !important;
        color: var(--cor-texto) !important;
    }}
    [data-testid="stSidebar"] {{
        background-color: var(--cor-sidebar) !important;
        border-right: 1px solid var(--cor-borda) !important;
    }}

    div.stButton > button[kind="primary"],
    button[data-testid="baseButton-primary"] {{
        background-color: var(--cor-primaria) !important;
        border-color: var(--cor-primaria) !important;
        color: #fff !important;
    }}
    div.stButton > button[kind="primary"]:hover,
    button[data-testid="baseButton-primary"]:hover {{
        background-color: var(--cor-primaria-2) !important;
        border-color: var(--cor-primaria-2) !important;
    }}

    [data-testid="stExpander"] {{
        background: var(--cor-card) !important;
        border: 1px solid var(--cor-borda) !important;
        border-radius: 12px !important;
    }}

    .chat-reacao-resumo {{
        display: inline-flex;
        gap: 6px;
        flex-wrap: wrap;
        margin-top: 4px;
        font-size: 0.9rem;
        color: var(--cor-texto-muted);
    }}
    .chat-reacao-chip {{
        background: var(--cor-card);
        border: 1px solid var(--cor-borda);
        border-radius: 999px;
        padding: 2px 8px;
    }}
    .vendedor-card {{
        background: var(--cor-card);
        border: 1px solid var(--cor-borda);
        border-radius: 14px;
        padding: 14px 16px;
        margin-bottom: 10px;
        min-height: 120px;
    }}
    .vendedor-card h4 {{ margin: 0 0 6px 0; color: var(--cor-texto); }}
    .vendedor-card .muted {{ color: var(--cor-texto-muted); font-size: 0.85rem; }}
    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# PERFIS E PERMISSÕES
# ============================================================
#
# Os valores abaixo aceitam tanto os nomes novos quanto os nomes
# que aparecem nas suas tabelas atuais:
#
# vendedor, admin, elfenai, documento
#
# Internamente, o programa normaliza:
# admin       -> gerente
# elfenai     -> elfen_ai
# documento   -> documentista
#

# ---------------------------------------------------------------------------
# ROLE_ALIASES: nomes gravados no banco → nome interno único.
# admin / marketing = poder GLOBAL
# gerente           = poder limitado à LOJA do usuário
# ---------------------------------------------------------------------------
ROLE_ALIASES = {
    # Poder global
    "admin": "admin",
    "administrador": "admin",
    "dono": "admin",
    "proprietario": "admin",
    "proprietário": "admin",
    "owner": "admin",
    # marketing = perfil próprio (global, sem métricas financeiras)
    "marketing": "marketing",
    # Poder por loja
    "gerente": "gerente",
    # Demais perfis
    "vendedor": "vendedor",
    "elfenai": "elfen_ai",
    "elfen ai": "elfen_ai",
    "elfen_ai": "elfen_ai",
    "documento": "documentista",
    "documentista": "documentista",
    "financeiro": "financeiro",
    "guariba": "guariba",
    "mecanico": "mecanico",
    "mecânico": "mecanico",
}

LOJAS_DISPONIVEIS = ("381", "746", "NINA")


def normalizar_loja(loja: Any) -> str:
    valor = str(loja or "381").strip().upper()
    return valor if valor in LOJAS_DISPONIVEIS else "381"


def gerar_link_whatsapp(telefone: Any) -> Optional[str]:
    """Gera link wa.me para números brasileiros cadastrados."""
    if telefone is None:
        return None
    try:
        if pd.isna(telefone):
            return None
    except (TypeError, ValueError):
        pass

    if isinstance(telefone, (int, float)):
        try:
            telefone = str(int(telefone))
        except (OverflowError, ValueError):
            return None

    digitos = "".join(
        caractere
        for caractere in str(telefone)
        if caractere.isdigit()
    )
    if not digitos:
        return None

    # Remove prefixos nacionais comuns antes de acrescentar o código do Brasil.
    if digitos.startswith("0") and len(digitos) in {11, 12}:
        digitos = digitos[1:]
    elif digitos.startswith("0") and len(digitos) in {13, 14}:
        digitos = digitos[3:]

    if digitos.startswith("55") and len(digitos) in {12, 13}:
        numero_internacional = digitos
    elif len(digitos) in {10, 11}:
        numero_internacional = f"55{digitos}"
    else:
        return None

    return f"https://wa.me/{numero_internacional}"


PERMISSIONS: Dict[str, Set[str]] = {
    "vendedor": {
        "view_leads",
        "view_stock",
        "view_transferencias",
        "add_transfer_attachment",
        "create_lead",
        "edit_own_lead",
        "delete_own_lead",
        "use_chat",
        "view_own_metrics",
        "view_documents",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_credit_fichas",
        "edit_own_credit_data",
        "view_oficina",
        "view_faturamento",
        "view_ia_suporte",
    },
    # admin = poder global (todas as lojas)
    "admin": {
        "*",
    },
    # gerente = mesmas telas, mas o SQL filtra pela loja do usuário
    "gerente": {
        "*",
    },
    # marketing = global (todas lojas), sem métricas $ de crédito
    "marketing": {
        "view_leads",
        "view_stock",
        "view_transferencias",
        "create_lead",
        "edit_own_lead",
        "use_chat",
        "view_tasks",
        "manage_tasks",
        "respond_tasks",
        "view_goals",
        "view_credit_fichas",
        "view_pending_clients",  # clientes com boleto/pendência
        "view_oficina",
        "view_faturamento",
        "transfer_leads",
        "view_ia_suporte",
    },
    "elfen_ai": {
        "view_leads",
        "view_stock",
        "view_transferencias",
        "use_chat",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_credit_fichas",
        "edit_bank_results",
        "edit_sales_boleto",
        "view_financial",
        "view_oficina",
        "view_faturamento",
        "view_ia_suporte",
    },
    "financeiro": {
        "view_leads",
        "view_stock",
        "view_transferencias",
        "use_chat",
        "view_financial",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_credit_fichas",
        "edit_sales_boleto",
        "view_credit_metrics",
        "view_oficina",
        "view_faturamento",
        "view_ia_suporte",
    },
    "documentista": {
        "view_leads",
        "view_stock",
        "manage_stock",
        "view_transferencias",
        "use_chat",
        "view_documents",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_credit_fichas",
        "view_oficina",
        "view_faturamento",
    },
    # Oficina: sem leads, transferências nem fichas de crédito.
    "guariba": {
        "view_stock",
        "use_chat",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_oficina",
        "edit_oficina",
        "manage_oficina",
    },
    "mecanico": {
        "view_stock",
        "use_chat",
        "view_tasks",
        "respond_tasks",
        "view_goals",
        "view_oficina",
        "edit_oficina",
        "manage_oficina",
    },
}


def normalizar_tipo(tipo: Any) -> str:
    """Converte os nomes gravados no banco para um nome interno único."""
    valor = str(tipo or "").strip().lower().replace("-", "_")
    return ROLE_ALIASES.get(valor, valor)


def usuario_tem(permissao: str) -> bool:
    usuario = st.session_state.get("usuario_logado")
    if not usuario:
        return False
    permissoes_usuario = PERMISSIONS.get(usuario["tipo"], set())
    return "*" in permissoes_usuario or permissao in permissoes_usuario


def usuario_e_gerente() -> bool:
    """Gerente de loja (escopo local)."""
    return st.session_state.get("usuario_logado", {}).get("tipo") == "gerente"


def usuario_e_admin() -> bool:
    """Admin (dono) — poder global total."""
    return st.session_state.get("usuario_logado", {}).get("tipo") == "admin"


def usuario_e_marketing() -> bool:
    return st.session_state.get("usuario_logado", {}).get("tipo") == "marketing"


def usuario_e_gestor() -> bool:
    """Admin ou gerente — métricas e gestão operacional completa."""
    return usuario_e_admin() or usuario_e_gerente()


def usuario_pode_gerir_tarefas() -> bool:
    """Admin, gerente ou marketing criam/editam/excluem tarefas."""
    t = st.session_state.get("usuario_logado", {}).get("tipo")
    return t in {"admin", "gerente", "marketing"} or usuario_tem("manage_tasks")


def usuario_pode_transferir_leads() -> bool:
    t = st.session_state.get("usuario_logado", {}).get("tipo")
    return t in {"admin", "gerente", "marketing"} or usuario_tem("transfer_leads")


def loja_do_usuario() -> str:
    return normalizar_loja(
        st.session_state.get("usuario_logado", {}).get("loja", "381")
    )


# ============================================================
# BANCO DE DADOS
# ============================================================

@st.cache_resource
def get_engine():
    """
    A URL deve estar em .streamlit/secrets.toml ou nos Secrets do
    Streamlit Cloud:

    [postgres]
    url = "postgresql://..."
    """
    db_url = st.secrets["postgres"]["url"]
    return create_engine(db_url, pool_pre_ping=True)


engine = get_engine()


# ============================================================
# SUPABASE STORAGE
# ============================================================
#
# Secrets (.streamlit/secrets.toml ou Streamlit Cloud):
#
#   [supabase]
#   url = "https://SEU_PROJETO.supabase.co"
#   service_role_key = "eyJ..."   # Settings → API → service_role
#
# Buckets usados (já existentes no projeto):
#   manu_arquivos  → fichas, estoque, oficina, transferências
#   chat           → anexos do chat geral
#
# O banco guarda apenas storage_path + storage_bucket (não o binário).
# ============================================================

STORAGE_BUCKET_ARQUIVOS = "manu_arquivos"
STORAGE_BUCKET_CHAT = "chat"


def _supabase_config() -> tuple[Optional[str], Optional[str]]:
    try:
        cfg = st.secrets.get("supabase", {})
        return cfg.get("url"), cfg.get("service_role_key") or cfg.get("key")
    except Exception:
        return None, None


def upload_para_storage(
    bucket: str,
    caminho: str,
    conteudo: bytes,
    mime_type: str = "application/octet-stream",
) -> Optional[str]:
    """
    Envia bytes para o Supabase Storage.
    Retorna o caminho (path) gravado ou None se falhar / não configurado.
    """
    import urllib.request
    import urllib.error

    base_url, key = _supabase_config()
    if not base_url or not key:
        return None

    url = f"{base_url.rstrip('/')}/storage/v1/object/{bucket}/{caminho}"
    req = urllib.request.Request(
        url,
        data=conteudo,
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "apikey": key,
            "Content-Type": mime_type or "application/octet-stream",
            "x-upsert": "true",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            if resp.status in {200, 201}:
                return caminho
    except urllib.error.HTTPError as erro:
        # 400 se objeto já existe sem upsert em algumas configs
        try:
            detalhe = erro.read().decode("utf-8", errors="ignore")
        except Exception:
            detalhe = str(erro)
        st.warning(f"Storage upload falhou ({erro.code}): {detalhe[:200]}")
    except Exception as erro:
        st.warning(f"Storage indisponível: {erro}")
    return None


def url_publica_storage(bucket: str, caminho: str) -> Optional[str]:
    base_url, _ = _supabase_config()
    if not base_url or not caminho:
        return None
    return f"{base_url.rstrip('/')}/storage/v1/object/public/{bucket}/{caminho}"


def url_assinada_storage(
    bucket: str,
    caminho: str,
    expires_sec: int = 3600,
) -> Optional[str]:
    """Gera URL assinada (bucket privado). Fallback para pública."""
    import urllib.request
    import json

    base_url, key = _supabase_config()
    if not base_url or not key or not caminho:
        return url_publica_storage(bucket, caminho)

    url = (
        f"{base_url.rstrip('/')}/storage/v1/object/sign/"
        f"{bucket}/{caminho}"
    )
    body = json.dumps({"expiresIn": expires_sec}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "apikey": key,
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            signed = data.get("signedURL") or data.get("signedUrl")
            if signed:
                if signed.startswith("http"):
                    return signed
                return f"{base_url.rstrip('/')}{signed}"
    except Exception:
        pass
    return url_publica_storage(bucket, caminho)


def baixar_do_storage(bucket: str, caminho: str) -> Optional[bytes]:
    import urllib.request

    base_url, key = _supabase_config()
    if not base_url or not key or not caminho:
        return None
    url = f"{base_url.rstrip('/')}/storage/v1/object/{bucket}/{caminho}"
    req = urllib.request.Request(
        url,
        headers={"Authorization": f"Bearer {key}", "apikey": key},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read()
    except Exception:
        return None


def caminho_storage_unico(prefixo: str, nome_arquivo: str) -> str:
    """ex.: fichas/123/20261008_a1b2_documento.pdf"""
    import re as _re
    from datetime import datetime as _dt
    import secrets as _secrets

    limpo = _re.sub(r"[^a-zA-Z0-9._-]", "_", nome_arquivo or "arquivo")
    stamp = _dt.utcnow().strftime("%Y%m%d_%H%M%S")
    return f"{prefixo}/{stamp}_{_secrets.token_hex(3)}_{limpo}"




# ============================================================
# SENHAS
# ============================================================
#

PBKDF2_ITERATIONS = 310_000
PASSWORD_PREFIX = "pbkdf2_sha256"


def criar_hash_senha(senha: str) -> str:
    salt = secrets.token_bytes(16)
    derivada = hashlib.pbkdf2_hmac(
        "sha256",
        senha.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )
    return (
        f"{PASSWORD_PREFIX}${PBKDF2_ITERATIONS}$"
        f"{salt.hex()}${derivada.hex()}"
    )


def verificar_senha(senha_digitada: str, senha_salva: str) -> tuple[bool, bool]:
    """
    Retorna:
      (senha_correta, precisa_migrar)

    precisa_migrar=True significa que o valor antigo estava em texto
    puro e deve ser substituído por um hash seguro.
    """
    senha_salva = str(senha_salva or "")

    if not senha_salva.startswith(f"{PASSWORD_PREFIX}$"):
        senha_correta = hmac.compare_digest(senha_digitada, senha_salva)
        return senha_correta, senha_correta

    try:
        prefixo, iteracoes, salt_hex, hash_hex = senha_salva.split("$")
        iteracoes_int = int(iteracoes)
        salt = bytes.fromhex(salt_hex)
        hash_esperado = bytes.fromhex(hash_hex)
        hash_recebido = hashlib.pbkdf2_hmac(
            "sha256",
            senha_digitada.encode("utf-8"),
            salt,
            iteracoes_int,
        )
        return hmac.compare_digest(hash_recebido, hash_esperado), False
    except (ValueError, TypeError):
        return False, False


# ============================================================
# AUTENTICAÇÃO E SESSÃO
# ============================================================


# ============================================================
# SUPABASE AUTH (cadastro / login opcional)
# ============================================================
#
# Secrets:
#   [supabase]
#   url = "https://xxx.supabase.co"
#   service_role_key = "sb_secret_..."   # ou anon publishable se Auth permitir
#   anon_key = "sb_publishable_..."      # preferível para signup/login do usuário
#
# Fluxo:
#   1. signup no Auth → cria auth.users
#   2. insert em public.usuarios com auth_user_id + tipo + loja
#   3. login: Auth valida senha; perfil/tipo vêm de public.usuarios
# Cadastro pode ser desligado com CADASTRO_ABERTO = False
# ============================================================

def _supabase_anon_key() -> Optional[str]:
    try:
        cfg = st.secrets.get("supabase", {})
        return (
            cfg.get("anon_key")
            or cfg.get("publishable_key")
            or cfg.get("service_role_key")
            or cfg.get("key")
        )
    except Exception:
        return None


def supabase_auth_request(
    path: str,
    payload: dict,
    use_service: bool = False,
) -> tuple[bool, dict]:
    """POST em /auth/v1/{path}. Retorna (ok, json)."""
    import urllib.request
    import urllib.error
    import json as _json

    base_url, service_key = _supabase_config()
    anon = _supabase_anon_key()
    key = service_key if use_service else (anon or service_key)
    if not base_url or not key:
        return False, {"error": "supabase não configurado nos secrets"}

    url = f"{base_url.rstrip('/')}/auth/v1/{path.lstrip('/')}"
    body = _json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "apikey": key,
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            data = _json.loads(raw) if raw else {}
            return True, data
    except urllib.error.HTTPError as erro:
        try:
            data = _json.loads(erro.read().decode("utf-8"))
        except Exception:
            data = {"error": str(erro)}
        return False, data
    except Exception as erro:
        return False, {"error": str(erro)}


def cadastrar_usuario_supabase(
    nome: str,
    login: str,
    email: str,
    senha: str,
    tipo: str,
    loja: str,
    telefone: str = "",
) -> tuple[bool, str]:
    """
    Cria conta no Supabase Auth + linha em public.usuarios.
    Tipo/loja são gravados só na tabela local (integridade de perfil).
    """
    nome = (nome or "").strip()
    login = (login or "").strip().lower()
    email = (email or "").strip().lower()
    tipo_n = normalizar_tipo(tipo)
    loja_n = normalizar_loja(loja)

    if not nome or not login or not email or not senha:
        return False, "Preencha nome, login, e-mail e senha."
    if tipo_n not in PERMISSIONS:
        return False, f"Tipo '{tipo}' inválido."
    if len(senha) < 6:
        return False, "Senha deve ter pelo menos 6 caracteres."

    # Impede login duplicado na tabela local
    try:
        with engine.connect() as conn:
            existe = conn.execute(
                text(
                    """
                    SELECT id FROM public.usuarios
                    WHERE LOWER(login) = LOWER(:login)
                       OR LOWER(COALESCE(email, '')) = LOWER(:email)
                    LIMIT 1
                    """
                ),
                {"login": login, "email": email},
            ).scalar()
            if existe:
                return False, "Já existe usuário com este login ou e-mail."
    except Exception as erro:
        return False, f"Erro ao verificar usuário: {erro}"

    ok, data = supabase_auth_request(
        "signup",
        {"email": email, "password": senha},
        use_service=False,
    )
    if not ok:
        msg = data.get("msg") or data.get("error_description") or data.get("error") or str(data)
        return False, f"Auth: {msg}"

    user = data.get("user") or {}
    auth_uid = user.get("id")
    if not auth_uid:
        # alguns retornos colocam em data.id
        auth_uid = data.get("id")

    senha_hash = criar_hash_senha(senha)
    telefone_n = (telefone or "").strip() or None
    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO public.usuarios (
                        nome, login, senha_hash, tipo, loja,
                        email, telefone, auth_user_id, ativo
                    )
                    VALUES (
                        :nome, :login, :senha_hash, :tipo, :loja,
                        :email, :telefone, :auth_user_id, TRUE
                    )
                    """
                ),
                {
                    "nome": nome,
                    "login": login,
                    "senha_hash": senha_hash,
                    "tipo": tipo_n,
                    "loja": loja_n,
                    "email": email,
                    "telefone": telefone_n,
                    "auth_user_id": auth_uid,
                },
            )
    except Exception as erro:
        return False, (
            f"Auth criado, mas falhou ao gravar perfil local: {erro}. "
            "Rode schema_auth_faturamento_realtime.sql"
        )

    return True, "Conta criada. Faça login."


def autenticar_via_supabase_email(email: str, senha: str, lembrar: bool = False) -> bool:
    """Login pelo Auth; carrega tipo/loja de public.usuarios."""
    ok, data = supabase_auth_request(
        "token?grant_type=password",
        {"email": email.strip(), "password": senha},
        use_service=False,
    )
    if not ok:
        return False
    user = data.get("user") or {}
    auth_uid = user.get("id")
    if not auth_uid:
        return False
    try:
        with engine.connect() as conn:
            result = conn.execute(
                text(
                    """
                    SELECT id, nome, login, tipo, vendedor_id, loja, ativo
                    FROM public.usuarios
                    WHERE auth_user_id::text = :uid
                       OR LOWER(COALESCE(email, '')) = LOWER(:email)
                    LIMIT 1
                    """
                ),
                {"uid": auth_uid, "email": email.strip()},
            ).mappings().first()
        if not result or result["ativo"] is False:
            return False
        tipo = normalizar_tipo(result["tipo"])
        if tipo not in PERMISSIONS:
            return False
        st.session_state["usuario_logado"] = {
            "id": result["id"],
            "nome": result["nome"],
            "login": result["login"],
            "tipo": tipo,
            "tipo_original": result["tipo"],
            "vendedor_id": result["vendedor_id"],
            "loja": normalizar_loja(result.get("loja", "381")),
            "is_admin": tipo in {"admin", "gerente"},
            "auth_user_id": auth_uid,
        }
        salvar_sessao(st.session_state["usuario_logado"], lembrar=lembrar)
        return True
    except Exception:
        return False


def autenticar(login_input: str, senha_input: str, lembrar: bool = False) -> bool:
    try:
        try:
            query = text(
                """
                SELECT
                    id,
                    nome,
                    login,
                    senha_hash,
                    tipo,
                    vendedor_id,
                    loja,
                    ativo
                FROM public.usuarios
                WHERE LOWER(login) = LOWER(:login)
                LIMIT 1
                """
            )
            with engine.connect() as conn:
                result = conn.execute(
                    query,
                    {"login": login_input.strip()},
                ).mappings().first()
        except Exception:
            # Compatibilidade durante a janela entre publicar o código e
            # executar a migração de lojas.
            query = text(
                """
                SELECT id, nome, login, senha_hash, tipo, vendedor_id, ativo
                FROM public.usuarios
                WHERE LOWER(login) = LOWER(:login)
                LIMIT 1
                """
            )
            with engine.connect() as conn:
                result = conn.execute(
                    query,
                    {"login": login_input.strip()},
                ).mappings().first()

        if not result:
            return False

        if result["ativo"] is False:
            st.error("Este usuário está inativo.")
            return False

        senha_correta, precisa_migrar = verificar_senha(
            senha_input.strip(),
            result["senha_hash"],
        )

        if not senha_correta:
            return False

        tipo = normalizar_tipo(result["tipo"])

        if tipo not in PERMISSIONS:
            st.error(f"O tipo de usuário '{result['tipo']}' não está configurado.")
            return False

        # Migração automática dos registros antigos que estavam
        # armazenados como texto puro.
        if precisa_migrar:
            with engine.begin() as conn:
                conn.execute(
                    text(
                        """
                        UPDATE public.usuarios
                        SET senha_hash = :senha_hash
                        WHERE id = :id
                        """
                    ),
                    {
                        "senha_hash": criar_hash_senha(senha_input.strip()),
                        "id": result["id"],
                    },
                )

        st.session_state["usuario_logado"] = {
            "id": result["id"],
            "nome": result["nome"],
            "login": result["login"],
            "tipo": tipo,
            "tipo_original": result["tipo"],
            "vendedor_id": result["vendedor_id"],
            "loja": normalizar_loja(result.get("loja", "381")),
            "is_admin": tipo in {"admin", "gerente"},
        }

        salvar_sessao(st.session_state["usuario_logado"], lembrar=lembrar)

        return True

    except Exception as erro:
        st.error(f"Erro ao conectar para login: {erro}")
        return False


def inicializar_sessao():
    """
    Inicializa session_state e, se não estiver em logout,
    tenta restaurar o usuário do cookie.
    """
    defaults = {
        "usuario_logado": None,
        "filtro_categoria": "todos",
        "pagina_atual": "leads",
        "chat_vendedor_selecionado": None,
        "abrir_formulario": False,
        "banco_filtro": None,
        "filtro_vendedor_id": None,
        "leads_limite": 24,
        "leads_filtro_chave": None,
        "busca_lead_aplicada": "",
        "busca_estoque_aplicada": "",
        "fichas_limite": 24,
        "fichas_filtro_chave": None,
        "busca_ficha_aplicada": "",
        "busca_oficina_aplicada": "",
        "logout_pendente": False,
    }

    for chave, valor in defaults.items():
        if chave not in st.session_state:
            st.session_state[chave] = valor

    # Sempre consulta o cookie (monta o componente CookieManager)
    usuario_cookie = carregar_sessao()

    # Logout em andamento: NÃO restaura cookie
    if st.session_state.get("logout_pendente"):
        st.session_state["usuario_logado"] = None
        # Quando o cookie já sumiu, libera a flag
        if not usuario_cookie:
            st.session_state["logout_pendente"] = False
        return

    if st.session_state.get("usuario_logado") is None and usuario_cookie:
        st.session_state["usuario_logado"] = usuario_cookie


inicializar_sessao()


# ============================================================
# ESCOPO DE DADOS POR PERFIL
# ============================================================

def escopo_leads(usuario: Dict[str, Any]) -> tuple[str, Dict[str, Any]]:
    """
    Retorna:
      - uma condição SQL fixa, criada pelo sistema;
      - os parâmetros dessa condição.

    Nenhum valor digitado pelo usuário é inserido diretamente no SQL.
    """
    tipo = usuario["tipo"]

    if tipo == "vendedor":
        if not usuario.get("vendedor_id"):
            return "FALSE", {}
        return "l.vendedor_id = :scope_vendedor_id", {
            "scope_vendedor_id": usuario["vendedor_id"],
        }

    # admin e marketing: veem leads de TODAS as lojas
    if tipo in {"admin", "marketing"}:
        return "TRUE", {}

    # gerente: só leads de vendedores da mesma loja
    if tipo == "gerente":
        return """
            (
                l.vendedor_id IN (
                    SELECT v.id FROM public.vendedores v
                    WHERE UPPER(COALESCE(v.loja, '381')) = UPPER(:scope_loja)
                )
                OR l.vendedor_id IS NULL
            )
        """, {"scope_loja": normalizar_loja(usuario.get("loja", "381"))}

    if tipo == "elfen_ai":
        return "TRUE", {}

    if tipo == "financeiro":
        return """
            (
                COALESCE(l.aprovou_credito, FALSE) = TRUE
                OR COALESCE(l.venda_concluida, FALSE) = TRUE
                OR COALESCE(l.vendeu, FALSE) = TRUE
            )
        """, {}

    if tipo == "documentista":
        return """
            (
                COALESCE(l.venda_concluida, FALSE) = TRUE
                OR COALESCE(l.vendeu, FALSE) = TRUE
            )
        """, {}

    return "FALSE", {}


def pode_editar_lead(lead: pd.Series, usuario: Dict[str, Any]) -> bool:
    if usuario["tipo"] in {"admin", "gerente"}:
        return True

    return (
        usuario["tipo"] == "vendedor"
        and usuario.get("vendedor_id") is not None
        and lead.get("vendedor_id") == usuario["vendedor_id"]
    )


def pode_deletar_lead(lead: pd.Series, usuario: Dict[str, Any]) -> bool:
    if usuario["tipo"] in {"admin", "gerente"}:
        return True

    return (
        usuario["tipo"] == "vendedor"
        and usuario.get("vendedor_id") is not None
        and lead.get("vendedor_id") == usuario["vendedor_id"]
    )


# ============================================================
# CONSULTAS AUXILIARES
# ============================================================

@st.cache_data(ttl=60, show_spinner=False)
def obter_vendedores() -> pd.DataFrame:
    try:
        query = text(
            """
            SELECT id, nome, loja
            FROM public.vendedores
            WHERE COALESCE(ativo, TRUE) = TRUE
            ORDER BY nome
            """
        )

        with engine.connect() as conn:
            df = pd.read_sql_query(query, conn)

        if "foto_url" not in df.columns:
            df["foto_url"] = None

        return df

    except Exception:
        # Compatibilidade caso a tabela ainda não tenha a coluna ativo.
        try:
            with engine.connect() as conn:
                df = pd.read_sql_query(
                    text(
                        """
                        SELECT id, nome
                        FROM public.vendedores
                        ORDER BY nome
                        """
                    ),
                    conn,
                )
            df["foto_url"] = None
            df["loja"] = "381"
            return df
        except Exception:
            return pd.DataFrame(columns=["id", "nome", "foto_url"])


@st.cache_data(ttl=15, show_spinner=False)
def obter_metricas(
    usuario: Dict[str, Any],
    vendedor_filtro: Optional[int] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
) -> Dict[str, int]:
    condicao, parametros = escopo_leads(usuario)
    filtros = [condicao]

    if vendedor_filtro is not None:
        filtros.append("l.vendedor_id = :metricas_vendedor_id")
        parametros["metricas_vendedor_id"] = vendedor_filtro
    if data_inicio is not None:
        filtros.append("l.data_lead >= :metricas_data_inicio")
        parametros["metricas_data_inicio"] = data_inicio
    if data_fim is not None:
        filtros.append("l.data_lead < :metricas_data_fim")
        parametros["metricas_data_fim"] = data_fim + timedelta(days=1)

    query = text(
        f"""
        SELECT
            COUNT(l.id) AS total_leads,
            COUNT(l.id) FILTER (
                WHERE COALESCE(l.gerou_ficha, FALSE) = TRUE
            ) AS total_fichas,
            COUNT(l.id) FILTER (
                WHERE COALESCE(l.aprovou_credito, FALSE) = TRUE
            ) AS total_aprovados,
            COUNT(l.id) FILTER (
                WHERE COALESCE(l.respondeu, FALSE) = TRUE
            ) AS total_responderam,
            COUNT(l.id) FILTER (
                WHERE
                    COALESCE(l.venda_concluida, FALSE) = TRUE
                    OR COALESCE(l.vendeu, FALSE) = TRUE
            ) AS total_vendidos
        FROM public.leads l
        WHERE {" AND ".join(f"({filtro})" for filtro in filtros)}
        """
    )

    try:
        with engine.connect() as conn:
            result = conn.execute(query, parametros).mappings().first()

        return {
            "total_leads": int(result["total_leads"] or 0),
            "total_fichas": int(result["total_fichas"] or 0),
            "total_aprovados": int(result["total_aprovados"] or 0),
            "total_responderam": int(result["total_responderam"] or 0),
            "total_vendidos": int(result["total_vendidos"] or 0),
        }
    except Exception as erro:
        st.error(f"Erro nas métricas: {erro}")
        return {
            "total_leads": 0,
            "total_fichas": 0,
            "total_aprovados": 0,
            "total_responderam": 0,
            "total_vendidos": 0,
        }


@st.cache_data(ttl=15, show_spinner=False)
def buscar_leads(
    usuario: Dict[str, Any],
    categoria: str,
    termo_busca: str,
    vendedor_filtro: Optional[int] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
    limite: int = 60,
) -> pd.DataFrame:
    escopo, parametros = escopo_leads(usuario)
    filtros = [escopo]

    # Categorias do painel de leads.
    # "negados" = gerou ficha e crédito explicitamente negado (aprovou_credito = FALSE).
    filtros_por_categoria = {
        "fichas": "l.gerou_ficha = TRUE",
        "aprovados": (
            "l.gerou_ficha = TRUE "
            "AND l.aprovou_credito = TRUE"
        ),
        "negados": (
            "l.gerou_ficha = TRUE "
            "AND COALESCE(l.aprovou_credito, TRUE) = FALSE"
        ),
        "responderam": "l.respondeu = TRUE",
        "nao_responderam": "COALESCE(l.respondeu, FALSE) = FALSE",
        "vendidos": (
            "l.venda_concluida = TRUE OR l.vendeu = TRUE"
        ),
    }
    if categoria in filtros_por_categoria:
        filtros.append(
            f"({filtros_por_categoria[categoria]})"
        )

    termo_limpo = termo_busca.strip()
    if termo_limpo:
        # Busca tolerante a erros:
        # 1) ILIKE parcial  2) similaridade pg_trgm (>= 0.3)
        # Requer: CREATE EXTENSION IF NOT EXISTS pg_trgm;
        filtros.append(
            """
            (
                l.nome_lead ILIKE :termo
                OR l.nome_completo ILIKE :termo
                OR l.cpf ILIKE :termo
                OR l.telefone ILIKE :termo
                OR l.observacao ILIKE :termo
                OR l.carro_selecionado ILIKE :termo
                OR l.placa_carro ILIKE :termo
                OR similarity(COALESCE(l.nome_lead, ''), :termo_raw) > 0.3
                OR similarity(COALESCE(l.nome_completo, ''), :termo_raw) > 0.3
                OR similarity(COALESCE(l.carro_selecionado, ''), :termo_raw) > 0.25
            )
            """
        )
        parametros["termo"] = f"%{termo_limpo}%"
        parametros["termo_raw"] = termo_limpo

    if vendedor_filtro is not None:
        filtros.append("l.vendedor_id = :vendedor_filtro")
        parametros["vendedor_filtro"] = vendedor_filtro
    if data_inicio is not None:
        filtros.append("l.data_lead >= :data_inicio")
        parametros["data_inicio"] = data_inicio
    if data_fim is not None:
        filtros.append("l.data_lead < :data_fim")
        parametros["data_fim"] = data_fim + timedelta(days=1)

    query = text(
        f"""
        SELECT
            l.id,
            l.nome_lead,
            l.telefone,
            l.data_lead,
            l.gerou_ficha,
            l.cliente_na_loja,
            l.venda_concluida,
            l.vendeu,
            l.respondeu,
            l.cpf,
            l.nome_completo,
            l.data_nascimento,
            l.nome_pai,
            l.nome_mae,
            l.rg,
            l.data_expedicao,
            l.orgao_expeditor,
            l.email,
            l.endereco,
            l.bairro,
            l.cidade,
            l.estado,
            l.cep,
            l.empresa,
            l.cnpj,
            l.endereco_empresa,
            l.bairro_empresa,
            l.cidade_empresa,
            l.estado_empresa,
            l.cep_empresa,
            l.tempo_carreira,
            l.salario,
            l.banco_correntista,
            l.habilitado,
            l.aprovou_credito,
            l.carro_selecionado,
            l.marca_carro,
            l.cor_carro,
            l.ano_carro,
            l.placa_carro,
            l.valor_carro,
            l.observacao,
            l.valor_entrada,
            l.updated_at,
            l.vendedor_id,
            v.nome AS nome_vendedor,
            ultima_transferencia.vendedor_origem_nome
                AS ultima_transferencia_origem,
            ultima_transferencia.vendedor_destino_nome
                AS ultima_transferencia_destino,
            ultima_transferencia.transferido_por_nome
                AS ultima_transferencia_por,
            ultima_transferencia.transferido_em
                AS ultima_transferencia_em,
            COUNT(*) OVER() AS total_registros
        FROM public.leads l
        LEFT JOIN public.vendedores v
            ON v.id = l.vendedor_id
        LEFT JOIN LATERAL (
            SELECT
                t.vendedor_origem_nome,
                t.vendedor_destino_nome,
                t.transferido_por_nome,
                t.transferido_em
                    AT TIME ZONE 'America/Sao_Paulo' AS transferido_em
            FROM public.lead_transferencias t
            WHERE t.lead_id = l.id
            ORDER BY t.transferido_em DESC, t.id DESC
            LIMIT 1
        ) ultima_transferencia ON TRUE
        WHERE {" AND ".join(f"({filtro})" for filtro in filtros)}
        ORDER BY l.updated_at DESC NULLS LAST, l.id DESC
        LIMIT :limite
        """
    )

    parametros["limite"] = max(min(int(limite), 200), 1)
    try:
        with engine.connect() as conn:
            return pd.read_sql_query(query, conn, params=parametros)
    except Exception:
        # Fallback se pg_trgm ainda não foi instalado
        if "termo_raw" in parametros:
            filtros_simples = [
                f for f in str(query).split("WHERE")[0:1]
            ]
            # re-executa só com ILIKE removendo similarity
            query_txt = str(query.text) if hasattr(query, "text") else str(query)
            query_txt = query_txt.replace(
                "OR similarity(COALESCE(l.nome_lead, ''), :termo_raw) > 0.3", ""
            ).replace(
                "OR similarity(COALESCE(l.nome_completo, ''), :termo_raw) > 0.3", ""
            ).replace(
                "OR similarity(COALESCE(l.carro_selecionado, ''), :termo_raw) > 0.25", ""
            )
            parametros.pop("termo_raw", None)
            with engine.connect() as conn:
                return pd.read_sql_query(text(query_txt), conn, params=parametros)
        raise


def marcar_mensagens_como_lidas(meu_id: int, outro_id: int) -> None:
    if not meu_id or not outro_id:
        return

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                UPDATE public.chat_mensagens
                SET lida = TRUE
                WHERE destinatario_id = :meu_id
                  AND remetente_id = :outro_id
                  AND lida = FALSE
                """
            ),
            {"meu_id": meu_id, "outro_id": outro_id},
        )


def contar_mensagens_nao_lidas(
    meu_id: Optional[int],
    remetente_id: Optional[int] = None,
) -> int:
    if not meu_id:
        return 0

    if remetente_id:
        query = text(
            """
            SELECT COUNT(*)
            FROM public.chat_mensagens
            WHERE destinatario_id = :meu_id
              AND remetente_id = :remetente_id
              AND lida = FALSE
            """
        )
        parametros = {
            "meu_id": meu_id,
            "remetente_id": remetente_id,
        }
    else:
        query = text(
            """
            SELECT COUNT(*)
            FROM public.chat_mensagens
            WHERE destinatario_id = :meu_id
              AND lida = FALSE
            """
        )
        parametros = {"meu_id": meu_id}

    try:
        with engine.connect() as conn:
            return int(conn.execute(query, parametros).scalar() or 0)
    except Exception:
        return 0


@st.cache_data(ttl=60, show_spinner=False)
def obter_usuarios_ativos() -> pd.DataFrame:
    try:
        query = text(
            """
            SELECT id, nome, login, tipo, vendedor_id, loja, ativo
            FROM public.usuarios
            WHERE COALESCE(ativo, TRUE) = TRUE
            ORDER BY nome
            """
        )
        with engine.connect() as conn:
            return pd.read_sql_query(query, conn)
    except Exception:
        query = text(
            """
            SELECT id, nome, login, tipo, vendedor_id, ativo
            FROM public.usuarios
            WHERE COALESCE(ativo, TRUE) = TRUE
            ORDER BY nome
            """
        )
        with engine.connect() as conn:
            usuarios = pd.read_sql_query(query, conn)
        usuarios["loja"] = "381"
        return usuarios


def atualizar_loja_usuario(usuario_id: int, loja: str) -> None:
    loja_normalizada = normalizar_loja(loja)
    try:
        with engine.begin() as conn:
            usuario = conn.execute(
                text(
                    """
                    SELECT vendedor_id
                    FROM public.usuarios
                    WHERE id = :usuario_id
                    """
                ),
                {"usuario_id": usuario_id},
            ).mappings().first()
            conn.execute(
                text(
                    """
                    UPDATE public.usuarios
                    SET loja = :loja
                    WHERE id = :usuario_id
                    """
                ),
                {
                    "loja": loja_normalizada,
                    "usuario_id": usuario_id,
                },
            )
            if usuario and usuario.get("vendedor_id"):
                conn.execute(
                    text(
                        """
                        UPDATE public.vendedores
                        SET loja = :loja
                        WHERE id = :vendedor_id
                        """
                    ),
                    {
                        "loja": loja_normalizada,
                        "vendedor_id": usuario["vendedor_id"],
                    },
                )
        st.cache_data.clear()
        st.success("Loja atualizada.")
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao atualizar loja: {erro}")


@st.cache_data(ttl=20, show_spinner=False)
def contar_tarefas_nao_visualizadas(usuario_id: int) -> int:
    query = text(
        """
        SELECT COUNT(*)
        FROM public.tarefas
        WHERE destinatario_id = :usuario_id
          AND visualizada_at IS NULL
        """
    )

    try:
        with engine.connect() as conn:
            return int(
                conn.execute(query, {"usuario_id": usuario_id}).scalar()
                or 0
            )
    except Exception:
        # Mantém a aplicação funcionando caso a migração ainda não
        # tenha sido executada.
        return 0


def marcar_tarefas_como_visualizadas(usuario_id: int) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                UPDATE public.tarefas
                SET visualizada_at = NOW(),
                    updated_at = NOW()
                WHERE destinatario_id = :usuario_id
                  AND visualizada_at IS NULL
                """
            ),
            {"usuario_id": usuario_id},
        )


def obter_tarefas(usuario: Dict[str, Any]) -> pd.DataFrame:
    # Admin / gerente / marketing veem todas; demais só as próprias
    if usuario["tipo"] in {"admin", "gerente", "marketing"}:
        filtro = "TRUE"
        parametros = {}
    else:
        filtro = "t.destinatario_id = :usuario_id"
        parametros = {"usuario_id": usuario["id"]}

    query = text(
        f"""
        SELECT
            t.id,
            t.titulo,
            t.descricao,
            t.destinatario_id,
            t.criado_por_id,
            t.resposta,
            t.observacao,
            t.visualizada_at,
            t.respondida_at,
            t.created_at,
            t.updated_at,
            destinatario.nome AS destinatario_nome,
            criador.nome AS criador_nome
        FROM public.tarefas t
        JOIN public.usuarios destinatario
            ON destinatario.id = t.destinatario_id
        JOIN public.usuarios criador
            ON criador.id = t.criado_por_id
        WHERE {filtro}
        ORDER BY
            CASE WHEN t.resposta IS NULL THEN 0 ELSE 1 END,
            t.created_at DESC
        """
    )

    with engine.connect() as conn:
        return pd.read_sql_query(query, conn, params=parametros)


def obter_metas(usuario: Dict[str, Any]) -> pd.DataFrame:
    """
    Escopo de visibilidade das metas:
    - gerente/admin: vê todas
    - demais: só metas direcionadas a si, ao seu tipo, à sua loja
      ou metas gerais (sem destinatário/tipo/loja)
    Colunas opcionais (schema_oficina / schema_metas_v2):
      destinatario_tipo, destinatario_loja, concluida
    """
    if usuario["tipo"] == "gerente":
        filtro = "TRUE"
        parametros = {}
    else:
        filtro = """
            (
                m.destinatario_id = :usuario_id
                OR (
                    m.destinatario_id IS NULL
                    AND COALESCE(m.destinatario_tipo, '') = ''
                    AND COALESCE(m.destinatario_loja, '') = ''
                )
                OR LOWER(COALESCE(m.destinatario_tipo, '')) = LOWER(:tipo_usuario)
                OR UPPER(COALESCE(m.destinatario_loja, '')) = UPPER(:loja_usuario)
            )
        """
        parametros = {
            "usuario_id": usuario["id"],
            "tipo_usuario": usuario.get("tipo") or "",
            "loja_usuario": usuario.get("loja") or "",
        }

    query = text(
        f"""
        SELECT
            m.id,
            m.titulo,
            m.descricao,
            m.unidade,
            m.valor_objetivo,
            m.periodo_inicio,
            m.periodo_fim,
            m.destinatario_id,
            m.criado_por_id,
            m.ativo,
            m.created_at,
            m.updated_at,
            destinatario.nome AS destinatario_nome,
            criador.nome AS criador_nome,
            COALESCE(m.destinatario_tipo, NULL) AS destinatario_tipo,
            COALESCE(m.destinatario_loja, NULL) AS destinatario_loja,
            COALESCE(m.concluida, NULL) AS concluida
        FROM public.metas m
        LEFT JOIN public.usuarios destinatario
            ON destinatario.id = m.destinatario_id
        JOIN public.usuarios criador
            ON criador.id = m.criado_por_id
        WHERE ({filtro})
          AND m.ativo = TRUE
        ORDER BY m.periodo_fim ASC NULLS LAST, m.created_at DESC
        """
    )

    try:
        with engine.connect() as conn:
            return pd.read_sql_query(query, conn, params=parametros)
    except Exception:
        # Fallback se as colunas novas ainda não existem.
        query_legado = text(
            f"""
            SELECT
                m.id,
                m.titulo,
                m.descricao,
                m.unidade,
                m.valor_objetivo,
                m.periodo_inicio,
                m.periodo_fim,
                m.destinatario_id,
                m.criado_por_id,
                m.ativo,
                m.created_at,
                m.updated_at,
                destinatario.nome AS destinatario_nome,
                criador.nome AS criador_nome
            FROM public.metas m
            LEFT JOIN public.usuarios destinatario
                ON destinatario.id = m.destinatario_id
            JOIN public.usuarios criador
                ON criador.id = m.criado_por_id
            WHERE ({filtro if usuario['tipo'] == 'gerente' else 'm.destinatario_id = :usuario_id OR m.destinatario_id IS NULL'})
              AND m.ativo = TRUE
            ORDER BY m.periodo_fim ASC NULLS LAST, m.created_at DESC
            """
        )
        params_legado = {} if usuario["tipo"] == "gerente" else {"usuario_id": usuario["id"]}
        with engine.connect() as conn:
            df = pd.read_sql_query(query_legado, conn, params=params_legado)
        df["destinatario_tipo"] = None
        df["destinatario_loja"] = None
        df["concluida"] = None
        return df


def converter_data(valor: Any) -> date:
    if valor is None or pd.isna(valor):
        return date.today()
    return pd.to_datetime(valor).date()


def converter_data_opcional(valor: Any) -> Optional[date]:
    """Converte datas brasileiras ou ISO para date; aceita campos vazios."""
    if valor is None:
        return None
    try:
        if pd.isna(valor):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor

    texto = str(valor).strip()
    if not texto:
        return None

    # Ano com dois dígitos: 30–99 => 1930–1999; 00–29 => 2000–2029.
    # Assim, por exemplo, 15/04/50 é interpretado como 15/04/1950.
    partes_data = None
    for separador in ("/", "-"):
        partes = texto.split(separador)
        if (
            len(partes) == 3
            and all(parte.isdigit() for parte in partes)
            and len(partes[0]) <= 2
            and len(partes[1]) <= 2
            and len(partes[2]) == 2
        ):
            partes_data = partes
            break
    if partes_data is None and texto.isdigit() and len(texto) == 6:
        partes_data = [texto[:2], texto[2:4], texto[4:]]

    if partes_data is not None:
        dia, mes, ano_curto = (int(parte) for parte in partes_data)
        ano = 1900 + ano_curto if ano_curto >= 30 else 2000 + ano_curto
        try:
            return date(ano, mes, dia)
        except ValueError:
            return None

    for formato in (
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%Y-%m-%d",
        "%d%m%Y",
    ):
        try:
            return datetime.strptime(texto, formato).date()
        except ValueError:
            continue
    return None


def data_para_texto_br(valor: Any) -> Optional[str]:
    """Formata datas opcionais como DD/MM/AAAA para campos TEXT."""
    data_convertida = converter_data_opcional(valor)
    return (
        data_convertida.strftime("%d/%m/%Y")
        if data_convertida
        else None
    )


def formatar_data_br(
    valor: Any,
    incluir_hora: bool = False,
    padrao: str = "-",
) -> str:
    """Exibe datas do banco no padrão brasileiro, sem alterar o banco."""
    if valor is None:
        return padrao
    try:
        if pd.isna(valor):
            return padrao
        data = pd.to_datetime(valor)
        formato = "%d/%m/%Y %H:%M" if incluir_hora else "%d/%m/%Y"
        return data.strftime(formato)
    except (TypeError, ValueError, OverflowError):
        texto = str(valor).strip()
        return texto or padrao


def numero_seguro(valor: Any, padrao: float = 0.0) -> float:
    if valor is None or pd.isna(valor):
        return padrao
    return float(valor)


def inteiro_seguro(valor: Any, padrao: int = 1) -> int:
    if valor is None or pd.isna(valor):
        return padrao
    return int(valor)


BANCOS_CREDITO = [
    "Itau",
    "Bradesco",
    "Santander",
    "Safra",
    "Creditas",
    "BV",
    "Pan",
]


def contar_notificacoes_nao_lidas(usuario_id: int) -> int:
    query = text(
        """
        SELECT COUNT(*)
        FROM public.notificacoes
        WHERE usuario_id = :usuario_id
          AND lida = FALSE
        """
    )

    try:
        with engine.connect() as conn:
            return int(
                conn.execute(query, {"usuario_id": usuario_id}).scalar()
                or 0
            )
    except Exception:
        return 0


def marcar_notificacoes_como_lidas(usuario_id: int) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                UPDATE public.notificacoes
                SET lida = TRUE
                WHERE usuario_id = :usuario_id
                  AND lida = FALSE
                """
            ),
            {"usuario_id": usuario_id},
        )


def criar_notificacao_vendedor(
    vendedor_id: Optional[int],
    ficha_id: int,
    titulo: str,
    mensagem: str,
    conn: Any,
) -> None:
    if not vendedor_id:
        return

    usuario = conn.execute(
        text(
            """
            SELECT id
            FROM public.usuarios
            WHERE vendedor_id = :vendedor_id
              AND COALESCE(ativo, TRUE) = TRUE
            ORDER BY id
            LIMIT 1
            """
        ),
        {"vendedor_id": vendedor_id},
    ).mappings().first()

    if not usuario:
        return

    conn.execute(
        text(
            """
            INSERT INTO public.notificacoes (
                usuario_id,
                tipo,
                titulo,
                mensagem,
                ficha_id
            )
            VALUES (
                :usuario_id,
                'resultado_ficha',
                :titulo,
                :mensagem,
                :ficha_id
            )
            """
        ),
        {
            "usuario_id": usuario["id"],
            "titulo": titulo,
            "mensagem": mensagem,
            "ficha_id": ficha_id,
        },
    )


def criar_notificacao_nova_ficha(
    vendedor_id: Optional[int],
    ficha_id: int,
    nome_cliente: str,
    conn: Any,
) -> None:
    """
    Avisa o vendedor responsável, gerentes e usuários do ElfenAI ativos.
    Assim a ficha pendente não depende de alguém abrir a tela.
    """
    if not vendedor_id:
        filtro_vendedor = "FALSE"
    else:
        filtro_vendedor = "u.vendedor_id = :vendedor_id"

    conn.execute(
        text(
            f"""
            INSERT INTO public.notificacoes (
                usuario_id,
                tipo,
                titulo,
                mensagem,
                ficha_id
            )
            SELECT
                u.id,
                'nova_ficha',
                'Nova ficha de crédito pendente',
                :mensagem,
                :ficha_id
            FROM public.usuarios u
            WHERE COALESCE(u.ativo, TRUE) = TRUE
              AND (
                    {filtro_vendedor}
                    OR REGEXP_REPLACE(
                        LOWER(COALESCE(u.tipo, '')),
                        '[^a-z0-9]',
                        '',
                        'g'
                    ) IN (
                        'gerente',
                        'admin',
                        'administrador',
                        'dono',
                        'owner',
                        'elfenai'
                    )
              )
            """
        ),
        {
            "vendedor_id": vendedor_id,
            "mensagem": (
                f"A ficha de {nome_cliente} foi criada e está "
                "aguardando análise dos bancos."
            ),
            "ficha_id": ficha_id,
        },
    )


def criar_ficha_credito(
    conn: Any,
    lead_id: int,
    vendedor_id: Optional[int],
    valor_entrada: float,
    usuario_id: int,
) -> int:
    """
    Cria a ficha uma única vez e inicializa os sete bancos como pendentes.
    """
    ficha_existente = conn.execute(
        text(
            """
            SELECT id
            FROM public.fichas_credito
            WHERE lead_id = :lead_id
            """
        ),
        {"lead_id": lead_id},
    ).scalar()

    if ficha_existente:
        return int(ficha_existente)

    ficha_id = conn.execute(
        text(
            """
            INSERT INTO public.fichas_credito (
                lead_id,
                vendedor_id,
                valor_entrada,
                criado_por_id,
                atualizado_por_id
            )
            VALUES (
                :lead_id,
                :vendedor_id,
                :valor_entrada,
                :usuario_id,
                :usuario_id
            )
            RETURNING id
            """
        ),
        {
            "lead_id": lead_id,
            "vendedor_id": vendedor_id,
            "valor_entrada": max(float(valor_entrada or 0), 0),
            "usuario_id": usuario_id,
        },
    ).scalar_one()

    for banco in BANCOS_CREDITO:
        conn.execute(
            text(
                """
                INSERT INTO public.ficha_bancos (ficha_id, banco)
                VALUES (:ficha_id, :banco)
                ON CONFLICT (ficha_id, banco) DO NOTHING
                """
            ),
            {"ficha_id": ficha_id, "banco": banco},
        )

    nome_cliente = conn.execute(
        text(
            """
            SELECT COALESCE(nome_completo, nome_lead, 'Cliente')
            FROM public.leads
            WHERE id = :lead_id
            """
        ),
        {"lead_id": lead_id},
    ).scalar() or "Cliente"
    criar_notificacao_nova_ficha(
        vendedor_id=vendedor_id,
        ficha_id=int(ficha_id),
        nome_cliente=str(nome_cliente),
        conn=conn,
    )

    return int(ficha_id)


def salvar_anexos_ficha(
    conn: Any,
    ficha_id: int,
    usuario_id: int,
    arquivos: Any,
) -> None:
    """
    Persiste anexos da ficha.
    Preferência: Supabase Storage (bucket manu_arquivos).
    Fallback: arquivo_bytes no Postgres se Storage não estiver configurado.
    """
    if not arquivos:
        return

    if not isinstance(arquivos, (list, tuple)):
        arquivos = [arquivos]

    for arquivo in arquivos:
        if arquivo is None:
            continue
        conteudo = arquivo.getvalue()
        if not conteudo:
            continue
        nome = getattr(arquivo, "name", None) or "documento"
        mime = getattr(arquivo, "type", None) or "application/octet-stream"
        caminho = caminho_storage_unico(f"fichas/{ficha_id}", nome)
        path_ok = upload_para_storage(
            STORAGE_BUCKET_ARQUIVOS, caminho, conteudo, mime
        )
        conn.execute(
            text(
                """
                INSERT INTO public.ficha_anexos (
                    ficha_id,
                    nome_arquivo,
                    mime_type,
                    arquivo_bytes,
                    storage_bucket,
                    storage_path,
                    enviado_por_id
                )
                VALUES (
                    :ficha_id,
                    :nome_arquivo,
                    :mime_type,
                    :arquivo_bytes,
                    :storage_bucket,
                    :storage_path,
                    :usuario_id
                )
                """
            ),
            {
                "ficha_id": ficha_id,
                "nome_arquivo": nome,
                "mime_type": mime,
                # se subiu pro storage, não grava binário no banco
                "arquivo_bytes": None if path_ok else conteudo,
                "storage_bucket": STORAGE_BUCKET_ARQUIVOS if path_ok else None,
                "storage_path": path_ok,
                "usuario_id": usuario_id,
            },
        )


@st.cache_data(ttl=60, show_spinner=False)
def obter_anexos_ficha(ficha_id: int) -> pd.DataFrame:
    query = text(
        """
        SELECT
            a.id,
            a.nome_arquivo,
            a.mime_type,
            a.arquivo_bytes,
            a.storage_bucket,
            a.storage_path,
            a.categoria,
            a.created_at,
            u.nome AS enviado_por
        FROM public.ficha_anexos a
        LEFT JOIN public.usuarios u
            ON u.id = a.enviado_por_id
        WHERE a.ficha_id = :ficha_id
        ORDER BY a.created_at DESC, a.id DESC
        """
    )
    with engine.connect() as conn:
        return pd.read_sql_query(
            query,
            conn,
            params={"ficha_id": ficha_id},
        )


def mostrar_anexos_ficha(
    ficha_id: int,
    usuario: Dict[str, Any],
    chave: str,
    expandido: bool = False,
) -> None:
    """Mostra e, quando permitido, recebe documentos da ficha."""
    try:
        anexos = obter_anexos_ficha(ficha_id)
    except Exception as erro:
        st.warning(
            "Execute schema_fichas_credito.sql para ativar os anexos. "
            f"Detalhe: {erro}"
        )
        return

    with st.expander(
        f"📎 Documentos e anexos ({len(anexos)})",
        expanded=expandido,
    ):
        if anexos.empty:
            st.caption("Nenhum anexo enviado.")
        else:
            for _, anexo in anexos.iterrows():
                conteudo = anexo.get("arquivo_bytes")
                if conteudo is None or (
                    isinstance(conteudo, float) and pd.isna(conteudo)
                ):
                    conteudo = None
                # Preferência: baixar do Storage se houver path
                if not conteudo and anexo.get("storage_path"):
                    conteudo = baixar_do_storage(
                        anexo.get("storage_bucket") or STORAGE_BUCKET_ARQUIVOS,
                        anexo.get("storage_path"),
                    )
                if not conteudo:
                    # link assinado como fallback
                    link = None
                    if anexo.get("storage_path"):
                        link = url_assinada_storage(
                            anexo.get("storage_bucket") or STORAGE_BUCKET_ARQUIVOS,
                            anexo.get("storage_path"),
                        )
                    nome = anexo.get("nome_arquivo") or "documento"
                    col_anexo_1, col_anexo_2 = st.columns([3, 1])
                    col_anexo_1.write(
                        f"**{nome}** · "
                        f"{formatar_data_br(anexo.get('created_at'), True)}"
                    )
                    if link:
                        col_anexo_2.markdown(f"[Baixar]({link})")
                    continue
                nome = anexo.get("nome_arquivo") or "documento"
                mime = (
                    anexo.get("mime_type")
                    or "application/octet-stream"
                )
                col_anexo_1, col_anexo_2 = st.columns([3, 1])
                col_anexo_1.write(
                    f"**{nome}** · "
                    f"{formatar_data_br(anexo.get('created_at'), True)}"
                )
                col_anexo_2.download_button(
                    "Baixar",
                    data=bytes(conteudo) if not isinstance(conteudo, bytes) else conteudo,
                    file_name=nome,
                    mime=mime,
                    key=f"baixar_anexo_{chave}_{anexo['id']}",
                )
                if usuario_tem("view_documents"):
                    if st.button(
                        "Excluir",
                        key=f"excluir_anexo_{chave}_{anexo['id']}",
                    ):
                        excluir_anexo_ficha_modal(
                            ficha_id,
                            int(anexo["id"]),
                            str(nome),
                        )

        if (
            usuario_tem("view_documents")
            or usuario_tem("add_transfer_attachment")
        ):
            novos_anexos = st.file_uploader(
                "Adicionar documentos",
                type=[
                    "pdf",
                    "png",
                    "jpg",
                    "jpeg",
                    "webp",
                    "doc",
                    "docx",
                    "xls",
                    "xlsx",
                ],
                accept_multiple_files=True,
                key=f"upload_anexo_{chave}",
            )
            if st.button(
                "Salvar anexos",
                key=f"salvar_anexo_{chave}",
                disabled=not novos_anexos,
            ):
                try:
                    with engine.begin() as conn:
                        salvar_anexos_ficha(
                            conn,
                            ficha_id,
                            usuario["id"],
                            novos_anexos,
                        )
                    st.cache_data.clear()
                    st.success("Anexos adicionados à ficha.")
                    st.rerun()
                except Exception as erro:
                    st.error(f"Erro ao salvar anexos: {erro}")


def excluir_anexo_ficha(
    ficha_id: int,
    anexo_id: int,
) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                DELETE FROM public.ficha_anexos
                WHERE id = :anexo_id
                  AND ficha_id = :ficha_id
                """
            ),
            {
                "anexo_id": anexo_id,
                "ficha_id": ficha_id,
            },
        )


@st.dialog("Excluir documento")
def excluir_anexo_ficha_modal(
    ficha_id: int,
    anexo_id: int,
    nome_arquivo: str,
) -> None:
    usuario = st.session_state["usuario_logado"]
    if not usuario_tem("view_documents"):
        st.error("Somente gerente e documentista podem excluir documentos.")
        return

    st.warning(
        f"O arquivo **{nome_arquivo}** será excluído definitivamente."
    )
    confirmar = st.button(
        "Excluir arquivo",
        type="primary",
        use_container_width=True,
    )
    if confirmar:
        try:
            excluir_anexo_ficha(ficha_id, anexo_id)
            st.cache_data.clear()
            st.success("Arquivo excluído.")
            st.rerun()
        except Exception as erro:
            st.error(f"Erro ao excluir arquivo: {erro}")


@st.cache_data(ttl=60, show_spinner=False)
def obter_contagem_anexos_fichas(
    ficha_ids: tuple[int, ...],
) -> Dict[int, int]:
    if not ficha_ids:
        return {}

    ids_sql = ",".join(str(int(ficha_id)) for ficha_id in ficha_ids)
    query = text(
        f"""
        SELECT ficha_id, COUNT(*) AS total
        FROM public.ficha_anexos
        WHERE ficha_id IN ({ids_sql})
        GROUP BY ficha_id
        """
    )
    try:
        with engine.connect() as conn:
            resultado = conn.execute(query).mappings().all()
        return {
            int(item["ficha_id"]): int(item["total"] or 0)
            for item in resultado
        }
    except Exception:
        return {}


@st.dialog("Documentos da ficha")
def abrir_anexos_ficha_modal(
    ficha_id: int,
    usuario: Dict[str, Any],
) -> None:
    mostrar_anexos_ficha(
        ficha_id,
        usuario,
        f"modal_ficha_{ficha_id}",
        expandido=True,
    )


def mostrar_botao_anexos_ficha(
    ficha_id: int,
    usuario: Dict[str, Any],
    chave: str,
    quantidade: int = 0,
) -> None:
    if st.button(
        f"📎 Documentos e anexos ({quantidade})",
        key=f"abrir_anexos_ficha_{chave}_{ficha_id}",
        use_container_width=True,
    ):
        abrir_anexos_ficha_modal(ficha_id, usuario)


@st.cache_data(ttl=20, show_spinner=False)
def obter_fichas_credito(
    usuario: Dict[str, Any],
    status: str = "todas",
    busca: str = "",
    banco_filtro: Optional[str] = None,
    limite: int = 24,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
) -> pd.DataFrame:
    if usuario["tipo"] == "vendedor":
        filtro_acesso = "f.vendedor_id = :vendedor_id"
        parametros: Dict[str, Any] = {
            "vendedor_id": usuario.get("vendedor_id")
        }
    elif usuario["tipo"] == "gerente":
        # Gerente: só fichas de vendedores da sua loja
        filtro_acesso = """
            f.vendedor_id IN (
                SELECT v.id FROM public.vendedores v
                WHERE UPPER(COALESCE(v.loja, '381')) = UPPER(:scope_loja)
            )
        """
        parametros = {"scope_loja": normalizar_loja(usuario.get("loja", "381"))}
    else:
        filtro_acesso = "TRUE"
        parametros = {}

    pode_ver_financeiro = (
        usuario["tipo"] in {"financeiro", "gerente", "admin", "elfen_ai"}
        or usuario_tem("view_financial")
        or usuario_tem("edit_sales_boleto")
    )
    campos_financeiros = """
            f.valor_entrada,
            f.comprou,
            f.data_compra,
            f.valor_veiculo,
            f.valor_financiado,
            f.banco_contratado,
            f.valor_liberado,
            f.entrada_total,
            f.entrada_paga,
            f.valor_pendente,
            f.gerou_boleto,
            f.boleto_valor,
            f.boleto_meses,
            f.boleto_total,
            f.fin_meses,
            f.fin_valor_parcela,
    """ if pode_ver_financeiro else """
            NULL::numeric AS valor_entrada,
            NULL::boolean AS comprou,
            NULL::date AS data_compra,
            NULL::numeric AS valor_veiculo,
            NULL::numeric AS valor_financiado,
            NULL::varchar AS banco_contratado,
            NULL::numeric AS valor_liberado,
            NULL::numeric AS entrada_total,
            NULL::numeric AS entrada_paga,
            NULL::numeric AS valor_pendente,
            NULL::boolean AS gerou_boleto,
            NULL::numeric AS boleto_valor,
            NULL::integer AS boleto_meses,
            NULL::numeric AS boleto_total,
            NULL::integer AS fin_meses,
            NULL::numeric AS fin_valor_parcela,
    """

    filtro_status = """
        (
            :status = 'todas'
            OR f.status_geral = :status
        )
    """
    filtro_busca = """
        (
            :busca = ''
            OR l.nome_lead ILIKE :termo
            OR l.nome_completo ILIKE :termo
            OR l.cpf ILIKE :termo
            OR l.telefone ILIKE :termo
            OR v.nome ILIKE :termo
        )
    """

    filtro_banco = "TRUE"
    join_banco = ""
    if banco_filtro:
        join_banco = """
            JOIN public.ficha_bancos banco_filtro
                ON banco_filtro.ficha_id = f.id
               AND banco_filtro.banco = :banco_filtro
        """
        filtro_banco = "banco_filtro.banco = :banco_filtro"

    parametros.update(
        {
            "status": status,
            "busca": busca.strip(),
            "termo": f"%{busca.strip()}%",
            "banco_filtro": banco_filtro,
        }
    )

    # Filtro de período (created_at da ficha)
    filtro_periodo = "TRUE"
    if data_inicio is not None:
        filtro_periodo = f"({filtro_periodo}) AND f.created_at >= :f_data_inicio"
        parametros["f_data_inicio"] = data_inicio
    if data_fim is not None:
        filtro_periodo = f"({filtro_periodo}) AND f.created_at < :f_data_fim"
        parametros["f_data_fim"] = data_fim + timedelta(days=1)

    # Ordem global:
    # 1) pendente + cliente na loja (primeiro que chegou = topo)
    # 2) demais pendentes (ordem de chegada)
    # 3) aprovadas/negadas no fundo
    ordem_fichas = """
        CASE
            WHEN f.status_geral = 'pendente'
                 AND COALESCE(l.cliente_na_loja, FALSE) = TRUE THEN 0
            WHEN f.status_geral = 'pendente' THEN 1
            ELSE 2
        END,
        f.created_at ASC NULLS LAST,
        f.id ASC
    """

    query = text(
        f"""
        SELECT
            f.id,
            f.lead_id,
            f.vendedor_id,
            f.status_geral,
            {campos_financeiros}
            f.created_at,
            f.updated_at,
            l.cliente_na_loja,
            l.nome_lead,
            l.nome_completo,
            l.cpf,
            l.rg,
            l.nome_pai,
            l.nome_mae,
            l.data_nascimento,
            l.data_expedicao,
            l.orgao_expeditor,
            l.email,
            l.endereco,
            l.bairro,
            l.cidade,
            l.estado,
            l.cep,
            l.empresa,
            l.cnpj,
            l.endereco_empresa,
            l.bairro_empresa,
            l.cidade_empresa,
            l.estado_empresa,
            l.cep_empresa,
            l.tempo_carreira,
            l.salario,
            l.banco_correntista,
            l.habilitado,
            l.produto_interesse,
            l.carro_selecionado,
            l.ano_carro,
            l.placa_carro,
            l.valor_carro,
            l.telefone,
            v.nome AS vendedor_nome,
            COUNT(*) OVER() AS total_registros
        FROM public.fichas_credito f
        JOIN public.leads l
            ON l.id = f.lead_id
        LEFT JOIN public.vendedores v
            ON v.id = f.vendedor_id
        {join_banco}
        WHERE ({filtro_acesso})
          AND ({filtro_status})
          AND ({filtro_busca})
          AND ({filtro_banco})
          AND ({filtro_periodo})
        ORDER BY {ordem_fichas}
        LIMIT :limite
        """
    )

    parametros["limite"] = max(min(int(limite), 100), 1)
    with engine.connect() as conn:
        return pd.read_sql_query(query, conn, params=parametros)


@st.cache_data(ttl=20, show_spinner=False)
def obter_analises_banco(ficha_id: int) -> pd.DataFrame:
    query = text(
        """
        SELECT
            id,
            ficha_id,
            banco,
            status,
            valor_financiado,
            valor_entrada,
            parcela_48,
            parcela_60,
            observacao,
            atualizado_por_id,
            updated_at
        FROM public.ficha_bancos
        WHERE ficha_id = :ficha_id
        ORDER BY
            CASE banco
                WHEN 'Itau' THEN 1
                WHEN 'Bradesco' THEN 2
                WHEN 'Santander' THEN 3
                WHEN 'Safra' THEN 4
                WHEN 'Creditas' THEN 5
                WHEN 'BV' THEN 6
                WHEN 'Pan' THEN 7
                ELSE 99
            END
        """
    )

    with engine.connect() as conn:
        return pd.read_sql_query(
            query,
            conn,
            params={"ficha_id": ficha_id},
        )


@st.cache_data(ttl=20, show_spinner=False)
def obter_analises_banco_lote(
    ficha_ids: tuple[int, ...],
) -> Dict[int, pd.DataFrame]:
    if not ficha_ids:
        return {}

    ids_sql = ",".join(str(int(ficha_id)) for ficha_id in ficha_ids)
    query = text(
        f"""
        SELECT
            id,
            ficha_id,
            banco,
            status,
            valor_financiado,
            valor_entrada,
            parcela_48,
            parcela_60,
            observacao,
            atualizado_por_id,
            updated_at
        FROM public.ficha_bancos
        WHERE ficha_id IN ({ids_sql})
        ORDER BY
            ficha_id,
            CASE banco
                WHEN 'Itau' THEN 1
                WHEN 'Bradesco' THEN 2
                WHEN 'Santander' THEN 3
                WHEN 'Safra' THEN 4
                WHEN 'Creditas' THEN 5
                WHEN 'BV' THEN 6
                WHEN 'Pan' THEN 7
                ELSE 99
            END
        """
    )
    try:
        with engine.connect() as conn:
            dados = pd.read_sql_query(query, conn)
        return {
            int(ficha_id): grupo.drop(columns=["ficha_id"])
            for ficha_id, grupo in dados.groupby("ficha_id")
        }
    except Exception:
        return {}


@st.cache_data(ttl=30, show_spinner=False)
def obter_fichas_com_valor_pendente() -> pd.DataFrame:
    query = text(
        """
        SELECT
            f.id,
            f.lead_id,
            l.nome_lead,
            l.nome_completo,
            l.cpf,
            l.telefone,
            l.data_nascimento,
            l.habilitado,
            l.produto_interesse,
            l.carro_selecionado,
            l.ano_carro,
            l.placa_carro,
            l.valor_carro,
            v.nome AS vendedor_nome,
            f.data_compra,
            f.valor_veiculo,
            f.banco_contratado,
            f.valor_liberado,
            f.entrada_total,
            f.entrada_paga,
            f.valor_pendente,
            f.boleto_valor,
            f.boleto_meses,
            f.boleto_total
        FROM public.fichas_credito f
        JOIN public.leads l
            ON l.id = f.lead_id
        LEFT JOIN public.vendedores v
            ON v.id = f.vendedor_id
        WHERE f.comprou = TRUE
          AND f.gerou_boleto = TRUE
          AND f.valor_pendente > 0
        ORDER BY f.valor_pendente DESC, f.updated_at DESC
        """
    )

    with engine.connect() as conn:
        return pd.read_sql_query(query, conn)


@st.cache_data(ttl=20, show_spinner=False)
def obter_fichas_documentais(usuario: Dict[str, Any]) -> pd.DataFrame:
    if usuario["tipo"] == "vendedor":
        filtro_vendedor = "AND f.vendedor_id = :transferencia_vendedor_id"
        parametros = {
            "transferencia_vendedor_id": usuario.get("vendedor_id")
        }
    else:
        filtro_vendedor = ""
        parametros = {}

    query = text(
        f"""
        SELECT
            f.id AS ficha_id,
            f.lead_id,
            f.vendedor_id,
            f.status_geral,
            f.data_compra,
            f.updated_at AS ficha_updated_at,
            l.nome_lead,
            l.nome_completo,
            l.cpf,
            l.telefone,
            l.data_nascimento,
            l.produto_interesse,
            l.carro_selecionado,
            l.ano_carro,
            l.placa_carro,
            l.valor_carro,
            l.venda_concluida,
            l.vendeu,
            v.nome AS vendedor_nome,
            COALESCE(p.status, 'nao_iniciado') AS transferencia_status,
            p.observacao AS transferencia_observacao,
            p.updated_at AS transferencia_updated_at,
            COALESCE(p.reconheceu_firma, FALSE)
                AS transferencia_reconheceu_firma,
            COALESCE(p.gravame, FALSE) AS transferencia_gravame,
            COALESCE(p.documento_pronto, FALSE)
                AS transferencia_documento_pronto
        FROM public.fichas_credito f
        JOIN public.leads l
            ON l.id = f.lead_id
        LEFT JOIN public.vendedores v
            ON v.id = f.vendedor_id
        LEFT JOIN public.processos_transferencia p
            ON p.ficha_id = f.id
        WHERE (
            f.comprou = TRUE
            OR COALESCE(l.venda_concluida, FALSE) = TRUE
            OR COALESCE(l.vendeu, FALSE) = TRUE
        )
          {filtro_vendedor}
        ORDER BY
            CASE COALESCE(p.status, 'nao_iniciado')
                WHEN 'em_andamento' THEN 1
                WHEN 'nao_iniciado' THEN 2
                WHEN 'pronto' THEN 3
                ELSE 4
            END,
            f.updated_at DESC
        """
    )

    with engine.connect() as conn:
        return pd.read_sql_query(query, conn, params=parametros)


def salvar_processo_transferencia(
    usuario: Dict[str, Any],
    ficha: pd.Series,
    status: str,
    observacao: str,
    reconheceu_firma: bool,
    gravame: bool,
    documento_pronto: bool,
) -> None:
    if usuario["tipo"] not in {"documentista", "gerente"}:
        st.error("Você não pode atualizar o processo documental.")
        return

    status_validos = {"nao_iniciado", "em_andamento", "pronto"}
    if status not in status_validos:
        st.error("Status de transferência inválido.")
        return

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO public.processos_transferencia (
                        ficha_id,
                        status,
                        observacao,
                        atualizado_por_id,
                        reconheceu_firma,
                        gravame,
                        documento_pronto
                    )
                    VALUES (
                        :ficha_id,
                        :status,
                        :observacao,
                        :usuario_id,
                        :reconheceu_firma,
                        :gravame,
                        :documento_pronto
                    )
                    ON CONFLICT (ficha_id) DO UPDATE
                    SET status = EXCLUDED.status,
                        observacao = EXCLUDED.observacao,
                        atualizado_por_id = EXCLUDED.atualizado_por_id,
                        reconheceu_firma = EXCLUDED.reconheceu_firma,
                        gravame = EXCLUDED.gravame,
                        documento_pronto = EXCLUDED.documento_pronto,
                        updated_at = NOW()
                    """
                ),
                {
                    "ficha_id": int(ficha["ficha_id"]),
                    "status": status,
                    "observacao": observacao.strip() or None,
                    "usuario_id": usuario["id"],
                    "reconheceu_firma": reconheceu_firma,
                    "gravame": gravame,
                    "documento_pronto": documento_pronto,
                },
            )

            criar_notificacao_vendedor(
                ficha.get("vendedor_id"),
                int(ficha["ficha_id"]),
                f"Transferência atualizada: {ficha['nome_lead']}",
                f"Processo documental: {status.replace('_', ' ')}.",
                conn,
            )

        st.success("Processo de transferência atualizado.")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao salvar processo documental: {erro}")


def recalcular_status_ficha(conn: Any, ficha_id: int) -> str:
    statuses = conn.execute(
        text(
            """
            SELECT status
            FROM public.ficha_bancos
            WHERE ficha_id = :ficha_id
            """
        ),
        {"ficha_id": ficha_id},
    ).scalars().all()

    if any(status == "aprovado" for status in statuses):
        novo_status = "aprovada"
    elif statuses and all(status == "negado" for status in statuses):
        novo_status = "negada"
    else:
        novo_status = "pendente"

    conn.execute(
        text(
            """
            UPDATE public.fichas_credito
            SET status_geral = :status,
                updated_at = NOW()
            WHERE id = :ficha_id
            """
        ),
        {"status": novo_status, "ficha_id": ficha_id},
    )

    conn.execute(
        text(
            """
            UPDATE public.leads l
            SET aprovou_credito = CASE
                    WHEN :status = 'aprovada' THEN TRUE
                    WHEN :status = 'negada' THEN FALSE
                    ELSE NULL
                END,
                updated_at = NOW()
            FROM public.fichas_credito f
            WHERE f.id = :ficha_id
              AND l.id = f.lead_id
            """
        ),
        {"status": novo_status, "ficha_id": ficha_id},
    )

    return novo_status


def salvar_analise_banco(
    usuario: Dict[str, Any],
    ficha: pd.Series,
    banco_id: int,
    banco: str,
    status: str,
    valor_financiado: Optional[float],
    valor_entrada: Optional[float],
    parcela_48: Optional[float],
    parcela_60: Optional[float],
    observacao: str,
) -> None:
    if not usuario_tem("edit_bank_results"):
        st.error("Você não pode alterar análises bancárias.")
        return

    if status == "aprovado" and valor_financiado is None:
        st.error("Uma aprovação precisa ter o valor financiado.")
        return

    # Para uma recusa ou pendência, os valores financeiros ficam nulos.
    if status != "aprovado":
        valor_financiado = None
        valor_entrada = None
        parcela_48 = None
        parcela_60 = None

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE public.ficha_bancos
                    SET
                        status = :status,
                        valor_financiado = :valor_financiado,
                        valor_entrada = :valor_entrada,
                        parcela_48 = :parcela_48,
                        parcela_60 = :parcela_60,
                        observacao = :observacao,
                        atualizado_por_id = :usuario_id,
                        updated_at = NOW()
                    WHERE id = :banco_id
                      AND ficha_id = :ficha_id
                    """
                ),
                {
                    "status": status,
                    "valor_financiado": valor_financiado,
                    "valor_entrada": valor_entrada,
                    "parcela_48": parcela_48,
                    "parcela_60": parcela_60,
                    "observacao": observacao.strip() or None,
                    "usuario_id": usuario["id"],
                    "banco_id": banco_id,
                    "ficha_id": ficha["id"],
                },
            )

            novo_status_geral = recalcular_status_ficha(
                conn,
                int(ficha["id"]),
            )
            criar_notificacao_vendedor(
                ficha.get("vendedor_id"),
                int(ficha["id"]),
                f"Atualização da ficha de {ficha['nome_lead']}",
                f"{banco}: {status}. Resultado geral: "
                f"{novo_status_geral}.",
                conn,
            )

        st.success(f"Resultado do {banco} salvo.")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao salvar análise bancária: {erro}")


def salvar_dados_financeiros_ficha(
    usuario: Dict[str, Any],
    ficha: pd.Series,
    comprou: bool,
    data_compra: Optional[date],
    valor_veiculo: Optional[float],
    banco_contratado: Optional[str],
    valor_liberado: Optional[float],
    entrada_total: Optional[float],
    entrada_paga: Optional[float],
    gerou_boleto: bool,
    boleto_valor: Optional[float],
    boleto_meses: Optional[int],
    fin_meses: Optional[int] = None,
    fin_valor_parcela: Optional[float] = None,
) -> None:
    pode_alterar = usuario_tem("edit_sales_boleto")

    if not pode_alterar:
        st.error("Você não pode alterar esses dados financeiros.")
        return

    if not comprou:
        data_compra = None
        valor_veiculo = None
        banco_contratado = None
        valor_liberado = 0
        entrada_total = 0
        entrada_paga = 0
        valor_pendente = 0
        gerou_boleto = False
        fin_meses = None
        fin_valor_parcela = None
    else:
        entrada_total = max(float(entrada_total or 0), 0)
        entrada_paga = max(float(entrada_paga or 0), 0)
        valor_liberado = max(float(valor_liberado or 0), 0)
        valor_pendente = max(entrada_total - entrada_paga, 0)
        fin_meses = int(fin_meses) if fin_meses else None
        fin_valor_parcela = (
            max(float(fin_valor_parcela or 0), 0) if fin_valor_parcela else None
        )

    if not gerou_boleto:
        boleto_valor = None
        boleto_meses = None
        boleto_total = 0
    else:
        boleto_total = (
            float(boleto_valor or 0) * int(boleto_meses or 0)
        )

    if gerou_boleto and (
        boleto_valor is None or not boleto_meses or boleto_meses <= 0
    ):
        st.error(
            "Informe o valor e a quantidade de meses do boleto."
        )
        return

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE public.fichas_credito
                    SET
                        comprou = :comprou,
                        data_compra = :data_compra,
                        valor_veiculo = :valor_veiculo,
                        banco_contratado = :banco_contratado,
                        valor_liberado = :valor_liberado,
                        valor_financiado = :valor_liberado,
                        entrada_total = :entrada_total,
                        valor_entrada = :entrada_total,
                        entrada_paga = :entrada_paga,
                        valor_pendente = :valor_pendente,
                        gerou_boleto = :gerou_boleto,
                        boleto_valor = :boleto_valor,
                        boleto_meses = :boleto_meses,
                        boleto_total = :boleto_total,
                        fin_meses = :fin_meses,
                        fin_valor_parcela = :fin_valor_parcela,
                        atualizado_por_id = :usuario_id,
                        updated_at = NOW()
                    WHERE id = :ficha_id
                    """
                ),
                {
                    "comprou": comprou,
                    "data_compra": data_compra,
                    "valor_veiculo": valor_veiculo,
                    "banco_contratado": banco_contratado,
                    "valor_liberado": valor_liberado,
                    "entrada_total": entrada_total,
                    "entrada_paga": entrada_paga,
                    "valor_pendente": valor_pendente,
                    "gerou_boleto": gerou_boleto,
                    "boleto_valor": boleto_valor,
                    "boleto_meses": boleto_meses,
                    "boleto_total": boleto_total,
                    "fin_meses": fin_meses,
                    "fin_valor_parcela": fin_valor_parcela,
                    "usuario_id": usuario["id"],
                    "ficha_id": ficha["id"],
                },
            )

            conn.execute(
                text(
                    """
                    UPDATE public.leads l
                    SET venda_concluida = :comprou,
                        vendeu = :comprou,
                        updated_at = NOW()
                    FROM public.fichas_credito f
                    WHERE f.id = :ficha_id
                      AND l.id = f.lead_id
                    """
                ),
                {
                    "comprou": comprou,
                    "ficha_id": ficha["id"],
                },
            )

            if comprou:
                nome_cli = (
                    ficha.get("nome_completo")
                    or ficha.get("nome_lead")
                    or "cliente"
                )
                criar_notificacao_vendedor(
                    ficha.get("vendedor_id"),
                    int(ficha["id"]),
                    f"Venda confirmada — faturar: {nome_cli}",
                    (
                        f"ElfenAI/financeiro marcou compra na ficha #{int(ficha['id'])}. "
                        f"Abra Faturamento: os dados da venda já vêm pré-preenchidos "
                        f"(banco, entrada, boletos). Você ainda pode criar faturamento "
                        f"manual para venda à vista."
                    ),
                    conn,
                )

        st.success("Dados financeiros salvos.")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao salvar dados financeiros: {erro}")


def salvar_dados_cadastrais_ficha(
    usuario: Dict[str, Any],
    ficha: pd.Series,
    nome_completo: str,
    cpf: str,
    data_nascimento: Any,
    habilitado: bool,
    carro_interesse: str,
    valor_entrada: Optional[float],
    dados_adicionais: Dict[str, Any],
) -> None:
    pode_alterar = (
        usuario_tem("edit_bank_results")
        or (
            usuario_tem("edit_own_credit_data")
            and ficha.get("vendedor_id") == usuario.get("vendedor_id")
        )
    )

    if not pode_alterar:
        st.error("Você não pode alterar os dados da ficha.")
        return

    if not nome_completo.strip() or not cpf.strip():
        st.error("Nome completo e CPF são obrigatórios.")
        return

    nascimento_convertido = converter_data_opcional(data_nascimento)
    if (
        str(data_nascimento or "").strip()
        and nascimento_convertido is None
    ):
        st.error(
            "Data de nascimento inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
        )
        return

    expedicao_digitada = dados_adicionais.get("data_expedicao")
    expedicao_convertida = converter_data_opcional(expedicao_digitada)
    if (
        str(expedicao_digitada or "").strip()
        and expedicao_convertida is None
    ):
        st.error(
            "Data de expedição inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
        )
        return
    dados_adicionais["data_expedicao"] = data_para_texto_br(
        expedicao_convertida
    )

    valor_entrada_atualizacao = (
        None
        if valor_entrada is None
        else max(float(valor_entrada or 0), 0)
    )

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE public.leads
                    SET
                        nome_completo = :nome_completo,
                        cpf = :cpf,
                        data_nascimento = :data_nascimento,
                        habilitado = :habilitado,
                        produto_interesse = :produto_interesse,
                        carro_selecionado = :produto_interesse,
                        nome_pai = :nome_pai,
                        nome_mae = :nome_mae,
                        rg = :rg,
                        data_expedicao = :data_expedicao,
                        orgao_expeditor = :orgao_expeditor,
                        empresa = :empresa,
                        cnpj = :cnpj,
                        endereco_empresa = :endereco_empresa,
                        bairro_empresa = :bairro_empresa,
                        cidade_empresa = :cidade_empresa,
                        estado_empresa = :estado_empresa,
                        cep_empresa = :cep_empresa,
                        endereco = :endereco,
                        bairro = :bairro,
                        cidade = :cidade,
                        estado = :estado,
                        cep = :cep,
                        email = :email,
                        tempo_carreira = :tempo_carreira,
                        salario = :salario,
                        banco_correntista = :banco_correntista,
                        valor_entrada = COALESCE(
                            :valor_entrada,
                            valor_entrada
                        ),
                        updated_at = NOW()
                    WHERE id = :lead_id
                    """
                ),
                {
                    "nome_completo": nome_completo.strip(),
                    "cpf": cpf.strip(),
                    "data_nascimento": nascimento_convertido,
                    "habilitado": habilitado,
                    "produto_interesse": (
                        carro_interesse.strip() or None
                    ),
                    "valor_entrada": valor_entrada_atualizacao,
                    "lead_id": ficha["lead_id"],
                    **dados_adicionais,
                },
            )
            conn.execute(
                text(
                    """
                    UPDATE public.fichas_credito
                    SET valor_entrada = COALESCE(
                            :valor_entrada,
                            valor_entrada
                        ),
                        atualizado_por_id = :usuario_id,
                        updated_at = NOW()
                    WHERE id = :ficha_id
                    """
                ),
                {
                    "valor_entrada": valor_entrada_atualizacao,
                    "usuario_id": usuario["id"],
                    "ficha_id": ficha["id"],
                },
            )

        st.success("Dados cadastrais da ficha atualizados.")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao atualizar dados da ficha: {erro}")


@st.cache_data(ttl=30, show_spinner=False)
def obter_metricas_credito(
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Métricas de fichas; opcionalmente filtradas por created_at."""
    filtros_f = ["TRUE"]
    params: Dict[str, Any] = {}
    if data_inicio is not None:
        filtros_f.append("f.created_at >= :m_data_inicio")
        params["m_data_inicio"] = data_inicio
    if data_fim is not None:
        filtros_f.append("f.created_at < :m_data_fim")
        params["m_data_fim"] = data_fim + timedelta(days=1)
    where_f = " AND ".join(filtros_f)

    query_bancos = text(
        f"""
        SELECT
            b.banco,
            COUNT(DISTINCT b.ficha_id) AS fichas_analisadas,
            COUNT(*) FILTER (WHERE b.status = 'aprovado')
                AS total_aprovados,
            COUNT(*) FILTER (WHERE b.status = 'negado')
                AS total_negados,
            COUNT(*) FILTER (WHERE b.status = 'pendente')
                AS total_pendentes,
            ROUND(
                100.0 * COUNT(*) FILTER (WHERE b.status = 'aprovado')
                / NULLIF(COUNT(*), 0),
                2
            ) AS taxa_aprovacao
        FROM public.ficha_bancos b
        JOIN public.fichas_credito f ON f.id = b.ficha_id
        WHERE {where_f}
        GROUP BY b.banco
        ORDER BY total_aprovados DESC, taxa_aprovacao DESC
        """
    )

    query_geral = text(
        f"""
        SELECT
            COUNT(*) AS total_fichas,
            COUNT(*) FILTER (WHERE status_geral = 'aprovada')
                AS fichas_aprovadas,
            COUNT(*) FILTER (WHERE status_geral = 'negada')
                AS fichas_negadas,
            COUNT(*) FILTER (WHERE status_geral = 'pendente')
                AS fichas_pendentes,
            COUNT(*) FILTER (WHERE comprou = TRUE)
                AS total_compras,
            COALESCE(SUM(valor_liberado + entrada_paga)
                FILTER (WHERE comprou = TRUE), 0) AS valor_vendas_bruto,
            COALESCE(SUM(valor_liberado)
                FILTER (WHERE comprou = TRUE), 0) AS valor_liberado,
            COALESCE(SUM(entrada_paga)
                FILTER (WHERE comprou = TRUE), 0) AS entrada_paga,
            COUNT(*) FILTER (
                WHERE comprou = TRUE AND gerou_boleto = TRUE
            )
                AS total_boletos,
            COALESCE(SUM(valor_pendente)
                FILTER (WHERE comprou = TRUE AND valor_pendente > 0), 0)
                AS valor_pendente,
            COALESCE(SUM(boleto_total)
                FILTER (WHERE comprou = TRUE AND gerou_boleto = TRUE), 0)
                AS valor_boletos,
            COUNT(*) FILTER (
                WHERE comprou = TRUE
                  AND gerou_boleto = TRUE
                  AND valor_pendente > 0
            ) AS clientes_com_valor_pendente
        FROM public.fichas_credito f
        WHERE {where_f}
        """
    )

    with engine.connect() as conn:
        por_banco = pd.read_sql_query(query_bancos, conn, params=params)
        geral = conn.execute(query_geral, params).mappings().first()

    return por_banco, dict(geral or {})


# ============================================================
# MODAIS DE EDIÇÃO
# ============================================================

@st.dialog("Editar Lead")
def editar_lead_modal(lead_data: pd.Series, df_vendedores: pd.DataFrame):
    usuario = st.session_state["usuario_logado"]

    if not pode_editar_lead(lead_data, usuario):
        st.error("Você não tem permissão para editar este lead.")
        return

    st.write(f"Editando informações de **{lead_data['nome_lead']}**")

    # Fora do formulário para atualizar a tela ao marcar/desmarcar.
    gerou_ficha = st.checkbox(
        "Gerou ficha",
        value=bool(lead_data.get("gerou_ficha", False)),
        key=f"editar_gerou_ficha_{lead_data['id']}",
    )

    def valor_lead(campo: str) -> str:
        valor = lead_data.get(campo)
        if valor is None or pd.isna(valor):
            return ""
        return str(valor)

    cliente_na_loja = False
    anexos_ficha = []
    anexos_token_key = f"editar_anexos_token_{lead_data['id']}"
    st.session_state.setdefault(anexos_token_key, 0)
    anexos_widget_key = (
        f"editar_anexos_ficha_{lead_data['id']}_"
        f"{st.session_state[anexos_token_key]}"
    )

    with st.form(f"form_edicao_{lead_data['id']}"):
        novo_nome = st.text_input(
            "Nome do Lead",
            value=str(lead_data.get("nome_lead") or ""),
        )
        novo_tel = st.text_input(
            "Telefone",
            value=str(lead_data.get("telefone") or ""),
        )

        ids_vendedores = (
            df_vendedores["id"].tolist()
            if not df_vendedores.empty
            else []
        )

        vendedor_atual = lead_data.get("vendedor_id")
        index_vendedor = (
            ids_vendedores.index(vendedor_atual)
            if vendedor_atual in ids_vendedores
            else 0
        )

        if usuario["tipo"] == "gerente" and ids_vendedores:
            novo_vendedor_id = st.selectbox(
                "Vendedor responsável",
                options=ids_vendedores,
                index=index_vendedor,
                format_func=lambda valor: df_vendedores.loc[
                    df_vendedores["id"] == valor, "nome"
                ].iloc[0],
            )
        else:
            novo_vendedor_id = vendedor_atual
            st.info(
                "Apenas o gerente pode alterar o vendedor responsável."
            )

        col2, col3 = st.columns(2)
        respondeu = col2.checkbox(
            "Respondeu",
            value=bool(lead_data.get("respondeu", False)),
        )
        venda_concluida = col3.checkbox(
            "Venda concluída",
            value=bool(
                lead_data.get(
                    "venda_concluida",
                    lead_data.get("vendeu", False),
                )
            ),
        )

        novo_nome_completo = None
        novo_cpf = None
        nova_data_nascimento = None
        nova_habilitacao = None
        nova_entrada = None
        novo_carro_selecionado = None
        novo_ano_carro = None
        nova_placa_carro = None
        novo_valor_carro = None

        if gerou_ficha:
            st.markdown("### Dados completos da ficha")
            cliente_na_loja = st.checkbox(
                "Cliente está na loja",
                value=bool(lead_data.get("cliente_na_loja", False)),
                key=f"editar_cliente_na_loja_{lead_data['id']}",
                help="Clientes na loja aparecem primeiro para o ElfenAI.",
            )
            ficha_dados_1, ficha_dados_2 = st.columns(2)
            with ficha_dados_1:
                novo_nome_completo = st.text_input(
                    "Nome completo",
                    value=(
                        valor_lead("nome_completo")
                        or valor_lead("nome_lead")
                    ),
                )
                novo_cpf = st.text_input(
                    "CPF",
                    value=valor_lead("cpf"),
                )
                nova_data_nascimento = st.text_input(
                    "Data de nascimento (DD/MM/AAAA)",
                    value=(
                        data_para_texto_br(
                            valor_lead("data_nascimento")
                        )
                        or ""
                    ),
                    placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                    help="Sem limite mínimo de ano. Digite a data completa.",
                )
                novo_nome_pai = st.text_input(
                    "Nome do pai",
                    value=valor_lead("nome_pai"),
                )
                novo_nome_mae = st.text_input(
                    "Nome da mãe",
                    value=valor_lead("nome_mae"),
                )
                novo_rg = st.text_input(
                    "RG",
                    value=valor_lead("rg"),
                )
                nova_data_expedicao = st.text_input(
                    "Data de expedição do RG (DD/MM/AAAA)",
                    value=(
                        data_para_texto_br(
                            valor_lead("data_expedicao")
                        )
                        or ""
                    ),
                    placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                )
                novo_orgao_expeditor = st.text_input(
                    "Órgão expedidor",
                    value=valor_lead("orgao_expeditor"),
                )
                novo_email = st.text_input(
                    "E-mail",
                    value=valor_lead("email"),
                )
                novo_endereco = st.text_input(
                    "Endereço residencial",
                    value=valor_lead("endereco"),
                )
                novo_bairro = st.text_input(
                    "Bairro residencial",
                    value=valor_lead("bairro"),
                )
                nova_cidade = st.text_input(
                    "Cidade residencial",
                    value=valor_lead("cidade"),
                )
                novo_estado = st.text_input(
                    "Estado residencial",
                    value=valor_lead("estado"),
                    max_chars=2,
                )
                novo_cep = st.text_input(
                    "CEP residencial",
                    value=valor_lead("cep"),
                    max_chars=9,
                )

            with ficha_dados_2:
                st.markdown("#### Dados da empresa (opcional)")
                st.caption(
                    "Para cliente autônomo, deixe os campos da empresa em branco."
                )
                nova_empresa = st.text_input(
                    "Nome da empresa",
                    value=valor_lead("empresa"),
                )
                novo_cnpj = st.text_input(
                    "CNPJ",
                    value=valor_lead("cnpj"),
                )
                novo_endereco_empresa = st.text_input(
                    "Endereço da empresa",
                    value=valor_lead("endereco_empresa"),
                )
                novo_bairro_empresa = st.text_input(
                    "Bairro da empresa",
                    value=valor_lead("bairro_empresa"),
                )
                nova_cidade_empresa = st.text_input(
                    "Cidade da empresa",
                    value=valor_lead("cidade_empresa"),
                )
                novo_estado_empresa = st.text_input(
                    "Estado da empresa",
                    value=valor_lead("estado_empresa"),
                    max_chars=2,
                )
                novo_cep_empresa = st.text_input(
                    "CEP da empresa",
                    value=valor_lead("cep_empresa"),
                    max_chars=9,
                )
                novo_tempo_carreira = st.text_input(
                    "Tempo de trabalho na empresa",
                    value=valor_lead("tempo_carreira"),
                )
                novo_salario = st.number_input(
                    "Salário mensal",
                    min_value=0.0,
                    value=numero_seguro(lead_data.get("salario")),
                    step=100.0,
                )
                novo_banco_correntista = st.text_input(
                    "Banco correntista",
                    value=valor_lead("banco_correntista"),
                )

            nova_habilitacao = st.checkbox(
                "Cliente habilitado",
                value=bool(lead_data.get("habilitado")),
            )
            nova_entrada = st.number_input(
                "Valor de entrada",
                min_value=0.0,
                value=numero_seguro(lead_data.get("valor_entrada")),
                step=100.0,
            )
            st.markdown("#### Veículo da ficha")
            ficha_col_1, ficha_col_2 = st.columns(2)
            with ficha_col_1:
                novo_carro_selecionado = st.text_input(
                    "Carro selecionado / modelo",
                    value=(
                        valor_lead("carro_selecionado")
                        or valor_lead("produto_interesse")
                    ),
                )
                nova_marca_carro = st.text_input(
                    "Marca do carro*",
                    value=valor_lead("marca_carro") or "",
                )
                nova_placa_carro = st.text_input(
                    "Placa do carro",
                    value=valor_lead("placa_carro"),
                    placeholder="ABC1D23",
                    max_chars=8,
                )
                nova_cor_carro = st.text_input(
                    "Cor do carro*",
                    value=valor_lead("cor_carro") or "",
                )
            with ficha_col_2:
                novo_ano_carro = st.number_input(
                    "Ano do carro",
                    min_value=1900,
                    max_value=2100,
                    step=1,
                    value=(
                        inteiro_seguro(lead_data.get("ano_carro"), 2026)
                        if pd.notna(lead_data.get("ano_carro"))
                        else None
                    ),
                    format="%d",
                )
                novo_valor_carro = st.number_input(
                    "Valor do carro",
                    min_value=0.0,
                    step=1000.0,
                    value=(
                        numero_seguro(lead_data.get("valor_carro"))
                        if pd.notna(lead_data.get("valor_carro"))
                        else None
                    ),
                )

        nova_observacao = st.text_area(
            "Observações",
            value=str(lead_data.get("observacao") or ""),
        )

        salvar = st.form_submit_button(
            "Salvar alterações",
            use_container_width=True,
            type="primary",
        )

    if gerou_ficha:
        anexos_ficha = st.file_uploader(
            "Anexar documentos à ficha",
            type=[
                "pdf",
                "png",
                "jpg",
                "jpeg",
                "webp",
                "doc",
                "docx",
                "xls",
                "xlsx",
            ],
            accept_multiple_files=True,
            key=anexos_widget_key,
            help=(
                "Fotos, PDFs e outros documentos ficam vinculados à ficha. "
                "Com anexo, os campos da ficha podem ficar em branco."
            ),
        )
        salvar_anexos_lead = st.button(
            "Salvar anexos da ficha",
            key=f"salvar_anexos_lead_{lead_data['id']}",
            disabled=not anexos_ficha,
            use_container_width=True,
        )
        if salvar_anexos_lead:
            gerou_ficha_salva = lead_data.get("gerou_ficha")
            if pd.isna(gerou_ficha_salva) or not bool(gerou_ficha_salva):
                st.info(
                    "Salve primeiro as alterações que marcam a ficha como "
                    "gerada; depois você poderá salvar os anexos."
                )
                return
            try:
                with engine.begin() as conn:
                    ficha_id = conn.execute(
                        text(
                            """
                            SELECT id
                            FROM public.fichas_credito
                            WHERE lead_id = :lead_id
                            """
                        ),
                        {"lead_id": int(lead_data["id"])},
                    ).scalar()
                    if not ficha_id:
                        ficha_id = criar_ficha_credito(
                            conn=conn,
                            lead_id=int(lead_data["id"]),
                            vendedor_id=lead_data.get("vendedor_id"),
                            valor_entrada=numero_seguro(
                                lead_data.get("valor_entrada")
                            ),
                            usuario_id=int(usuario["id"]),
                        )
                    salvar_anexos_ficha(
                        conn,
                        int(ficha_id),
                        int(usuario["id"]),
                        anexos_ficha,
                    )
                st.cache_data.clear()
                st.session_state[anexos_token_key] += 1
                st.success("Anexos vinculados à ficha.")
                st.rerun()
            except Exception as erro:
                st.error(f"Erro ao salvar anexos da ficha: {erro}")

    if not salvar:
        return

    nascimento_convertido = None
    expedicao_formatada = None
    if gerou_ficha:
        nascimento_convertido = converter_data_opcional(
            nova_data_nascimento
        )
        if (
            str(nova_data_nascimento or "").strip()
            and nascimento_convertido is None
        ):
            st.error(
                "Data de nascimento inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
            )
            return

        expedicao_convertida = converter_data_opcional(
            nova_data_expedicao
        )
        if (
            str(nova_data_expedicao or "").strip()
            and expedicao_convertida is None
        ):
            st.error(
                "Data de expedição inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
            )
            return
        expedicao_formatada = data_para_texto_br(
            expedicao_convertida
        )

    if gerou_ficha and not anexos_ficha and (
        not novo_nome_completo
        or not novo_cpf
        or not novo_carro_selecionado
        or not nova_placa_carro
        or not novo_ano_carro
        or novo_valor_carro is None
        or novo_valor_carro <= 0
    ):
        st.warning(
            "Para gerar a ficha, informe nome completo, CPF, carro, "
            "placa, ano e valor do carro."
        )
        return

    transferencia_solicitada = novo_vendedor_id != vendedor_atual
    vendedor_destino_nome = None
    vendedor_origem_nome = None
    vendedor_origem_id = None
    if transferencia_solicitada:
        if usuario["tipo"] != "gerente":
            st.error("Somente o gerente pode transferir um lead.")
            return

        destino = df_vendedores.loc[
            df_vendedores["id"] == novo_vendedor_id,
            "nome",
        ]
        if destino.empty:
            st.error("Não foi possível identificar o vendedor de destino.")
            return

        vendedor_destino_nome = str(destino.iloc[0])
        vendedor_origem_nome_bruto = lead_data.get("nome_vendedor")
        vendedor_origem_nome = (
            str(vendedor_origem_nome_bruto)
            if pd.notna(vendedor_origem_nome_bruto)
            and str(vendedor_origem_nome_bruto).strip()
            else "Sem vendedor"
        )
        vendedor_origem_id = (
            int(vendedor_atual)
            if pd.notna(vendedor_atual)
            else None
        )

    nova_placa_carro = (
        nova_placa_carro.strip().replace("-", "").replace(" ", "").upper()
        if gerou_ficha and nova_placa_carro
        else None
    )

    def vazio_para_none(valor: Any) -> Optional[str]:
        valor = str(valor or "").strip()
        return valor or None

    try:
        query = text(
            """
            UPDATE public.leads
            SET
                nome_lead = :nome_lead,
                telefone = :telefone,
                vendedor_id = :vendedor_id,
                gerou_ficha = :gerou_ficha,
                cliente_na_loja = :cliente_na_loja,
                respondeu = :respondeu,
                venda_concluida = :venda_concluida,
                vendeu = :venda_concluida,
                aprovou_credito = CASE
                    WHEN :gerou_ficha = TRUE AND :tem_ficha = TRUE
                    THEN aprovou_credito
                    ELSE NULL
                END,
                cpf = CASE
                    WHEN :gerou_ficha = TRUE THEN :cpf
                    ELSE cpf
                END,
                nome_completo = COALESCE(
                    :nome_completo,
                    nome_completo
                ),
                data_nascimento = CASE
                    WHEN :gerou_ficha = TRUE THEN :data_nascimento
                    ELSE data_nascimento
                END,
                produto_interesse = :carro_selecionado,
                carro_selecionado = :carro_selecionado,
                marca_carro = :marca_carro,
                cor_carro = :cor_carro,
                ano_carro = :ano_carro,
                placa_carro = :placa_carro,
                valor_carro = :valor_carro,
                observacao = :observacao,
                updated_at = NOW()
            WHERE id = :lead_id
            """
        )

        with engine.begin() as conn:
            tem_ficha = conn.execute(
                text(
                    """
                    SELECT EXISTS(
                        SELECT 1
                        FROM public.fichas_credito
                        WHERE lead_id = :lead_id
                    )
                    """
                ),
                {"lead_id": lead_data["id"]},
            ).scalar()

            conn.execute(
                query,
                {
                    "nome_lead": vazio_para_none(novo_nome),
                    "telefone": vazio_para_none(novo_tel),
                    "vendedor_id": novo_vendedor_id,
                    "gerou_ficha": gerou_ficha,
                    "cliente_na_loja": (
                        cliente_na_loja if gerou_ficha else False
                    ),
                    "respondeu": respondeu,
                    "venda_concluida": venda_concluida,
                    "tem_ficha": bool(tem_ficha),
                    "cpf": vazio_para_none(novo_cpf),
                    "nome_completo": (
                        vazio_para_none(novo_nome_completo)
                        if gerou_ficha
                        else None
                    ),
                    "data_nascimento": nascimento_convertido,
                    "carro_selecionado": (
                        vazio_para_none(novo_carro_selecionado)
                        if gerou_ficha
                        else None
                    ),
                    "marca_carro": (
                        vazio_para_none(nova_marca_carro)
                        if gerou_ficha
                        else None
                    ),
                    "cor_carro": (
                        vazio_para_none(nova_cor_carro)
                        if gerou_ficha
                        else None
                    ),
                    "ano_carro": novo_ano_carro if gerou_ficha else None,
                    "placa_carro": nova_placa_carro,
                    "valor_carro": (
                        novo_valor_carro if gerou_ficha else None
                    ),
                    "observacao": vazio_para_none(nova_observacao),
                    "lead_id": lead_data["id"],
                },
            )

            if transferencia_solicitada:
                conn.execute(
                    text(
                        """
                        INSERT INTO public.lead_transferencias (
                            lead_id,
                            vendedor_origem_id,
                            vendedor_origem_nome,
                            vendedor_destino_id,
                            vendedor_destino_nome,
                            transferido_por_id,
                            transferido_por_nome
                        )
                        VALUES (
                            :lead_id,
                            :vendedor_origem_id,
                            :vendedor_origem_nome,
                            :vendedor_destino_id,
                            :vendedor_destino_nome,
                            :transferido_por_id,
                            :transferido_por_nome
                        )
                        """
                    ),
                    {
                        "lead_id": int(lead_data["id"]),
                        "vendedor_origem_id": vendedor_origem_id,
                        "vendedor_origem_nome": vendedor_origem_nome,
                        "vendedor_destino_id": int(novo_vendedor_id),
                        "vendedor_destino_nome": vendedor_destino_nome,
                        "transferido_por_id": int(usuario["id"]),
                        "transferido_por_nome": str(usuario["nome"]),
                    },
                )
                conn.execute(
                    text(
                        """
                        UPDATE public.fichas_credito
                        SET vendedor_id = :vendedor_id,
                            updated_at = NOW()
                        WHERE lead_id = :lead_id
                        """
                    ),
                    {
                        "vendedor_id": int(novo_vendedor_id),
                        "lead_id": int(lead_data["id"]),
                    },
                )

            if gerou_ficha:
                conn.execute(
                    text(
                        """
                        UPDATE public.leads
                        SET
                            nome_pai = :nome_pai,
                            nome_mae = :nome_mae,
                            rg = :rg,
                            data_expedicao = :data_expedicao,
                            orgao_expeditor = :orgao_expeditor,
                            empresa = :empresa,
                            cnpj = :cnpj,
                            endereco_empresa = :endereco_empresa,
                            bairro_empresa = :bairro_empresa,
                            cidade_empresa = :cidade_empresa,
                            estado_empresa = :estado_empresa,
                            cep_empresa = :cep_empresa,
                            endereco = :endereco,
                            bairro = :bairro,
                            cidade = :cidade,
                            estado = :estado,
                            cep = :cep,
                            email = :email,
                            tempo_carreira = :tempo_carreira,
                            salario = :salario,
                            banco_correntista = :banco_correntista,
                            habilitado = :habilitado,
                            valor_entrada = :valor_entrada
                        WHERE id = :lead_id
                        """
                    ),
                    {
                        "lead_id": lead_data["id"],
                        "nome_pai": vazio_para_none(novo_nome_pai),
                        "nome_mae": vazio_para_none(novo_nome_mae),
                        "rg": vazio_para_none(novo_rg),
                        "data_expedicao": expedicao_formatada,
                        "orgao_expeditor": vazio_para_none(
                            novo_orgao_expeditor
                        ),
                        "empresa": vazio_para_none(nova_empresa),
                        "cnpj": vazio_para_none(novo_cnpj),
                        "endereco_empresa": vazio_para_none(
                            novo_endereco_empresa
                        ),
                        "bairro_empresa": vazio_para_none(
                            novo_bairro_empresa
                        ),
                        "cidade_empresa": vazio_para_none(
                            nova_cidade_empresa
                        ),
                        "estado_empresa": vazio_para_none(
                            novo_estado_empresa
                        ),
                        "cep_empresa": vazio_para_none(novo_cep_empresa),
                        "endereco": vazio_para_none(novo_endereco),
                        "bairro": vazio_para_none(novo_bairro),
                        "cidade": vazio_para_none(nova_cidade),
                        "estado": vazio_para_none(novo_estado),
                        "cep": vazio_para_none(novo_cep),
                        "email": vazio_para_none(novo_email),
                        "tempo_carreira": vazio_para_none(
                            novo_tempo_carreira
                        ),
                        "salario": novo_salario or None,
                        "banco_correntista": vazio_para_none(
                            novo_banco_correntista
                        ),
                        "habilitado": nova_habilitacao,
                        "valor_entrada": nova_entrada,
                    },
                )

                ficha_id = criar_ficha_credito(
                    conn=conn,
                    lead_id=int(lead_data["id"]),
                    vendedor_id=novo_vendedor_id,
                    valor_entrada=float(
                        nova_entrada or 0
                    ),
                    usuario_id=usuario["id"],
                )
                salvar_anexos_ficha(
                    conn,
                    ficha_id,
                    usuario["id"],
                    anexos_ficha,
                )
                conn.execute(
                    text(
                        """
                        UPDATE public.fichas_credito
                        SET valor_entrada = :valor_entrada,
                            atualizado_por_id = :usuario_id,
                            updated_at = NOW()
                        WHERE lead_id = :lead_id
                        """
                    ),
                    {
                        "valor_entrada": nova_entrada,
                        "usuario_id": usuario["id"],
                        "lead_id": lead_data["id"],
                    },
                )

        st.cache_data.clear()
        if anexos_ficha:
            st.session_state[anexos_token_key] += 1
        st.success("Lead atualizado com sucesso.")
        st.rerun()

    except Exception as erro:
        st.error(f"Erro ao salvar alterações: {erro}")


@st.dialog("Excluir Lead")
def deletar_lead_modal(lead_data: pd.Series):
    usuario = st.session_state["usuario_logado"]

    if not pode_deletar_lead(lead_data, usuario):
        st.error("Você não tem permissão para excluir este lead.")
        return

    st.warning(
        f"Tem certeza que deseja apagar o lead "
        f"**{lead_data['nome_lead']}**?"
    )

    col1, col2 = st.columns(2)

    with col1:
        confirmar = st.button(
            "Sim, excluir",
            type="primary",
            use_container_width=True,
        )

    with col2:
        cancelar = st.button(
            "Cancelar",
            use_container_width=True,
        )

    if cancelar:
        st.rerun()

    if confirmar:
        try:
            with engine.begin() as conn:
                conn.execute(
                    text("DELETE FROM public.leads WHERE id = :id"),
                    {"id": lead_data["id"]},
                )
            st.success("Lead excluído.")
            st.rerun()
        except Exception as erro:
            st.error(f"Erro ao excluir lead: {erro}")


# ============================================================
# COMPONENTES DE INTERFACE
# ============================================================

def mostrar_login() -> None:
    st.markdown("<br><br>", unsafe_allow_html=True)
    _, coluna_login, _ = st.columns([1, 1.5, 1])

    with coluna_login:
        with st.container(border=True):
            st.title("Acesso ao sistema")

            abas = ["Entrar"]
            if CADASTRO_ABERTO:
                abas.append("Criar conta")
            tab_entrar, *rest = st.tabs(abas)
            tab_cadastro = rest[0] if rest else None

            with tab_entrar:
                st.caption("Login com usuário local ou e-mail (Supabase Auth).")
                with st.form("form_login"):
                    login = st.text_input("Usuário ou e-mail")
                    senha = st.text_input("Senha", type="password")
                    lembrar = st.checkbox(
                        "Lembrar-me neste dispositivo",
                        value=False,
                        help="Sem marcar: sessão curta (~12h). Marcado: até 14 dias.",
                    )
                    entrar = st.form_submit_button(
                        "Entrar",
                        use_container_width=True,
                        type="primary",
                    )

                if entrar:
                    ok = autenticar(login, senha, lembrar=lembrar)
                    if not ok and "@" in (login or ""):
                        ok = autenticar_via_supabase_email(
                            login, senha, lembrar=lembrar
                        )
                    if ok:
                        st.session_state["logout_pendente"] = False
                        st.success("Login realizado com sucesso.")
                        st.rerun()
                    else:
                        st.error("Usuário ou senha incorretos.")

            if tab_cadastro is not None:
                with tab_cadastro:
                    st.caption(
                        "Cadastro temporário para funcionários. "
                        "Desative com CADASTRO_ABERTO = False no código."
                    )
                    tipos_cadastro = [
                        t for t in (
                            "vendedor", "gerente", "marketing", "elfen_ai",
                            "financeiro", "documentista", "guariba",
                            "mecanico", "admin",
                        )
                        if t in PERMISSIONS
                    ]
                    with st.form("form_cadastro"):
                        nome = st.text_input("Nome completo*")
                        login_c = st.text_input("Login* (sem espaços)")
                        email_c = st.text_input("E-mail*")
                        telefone_c = st.text_input("Telefone*")
                        senha_c = st.text_input("Senha*", type="password")
                        tipo_c = st.selectbox("Perfil / tipo*", tipos_cadastro)
                        loja_c = st.selectbox("Loja*", list(LOJAS_DISPONIVEIS))
                        criar = st.form_submit_button(
                            "Criar conta",
                            use_container_width=True,
                            type="primary",
                        )
                    if criar:
                        ok, msg = cadastrar_usuario_supabase(
                            nome, login_c, email_c, senha_c, tipo_c, loja_c,
                            telefone=telefone_c,
                        )
                        if ok:
                            st.success(msg)
                        else:
                            st.error(msg)


def mostrar_sidebar(usuario: Dict[str, Any]) -> None:
    with st.sidebar:
        st.markdown(
            f"### 👤 Logado como\n**{usuario['nome']}**"
        )
        st.caption(
            f"Perfil: {usuario['tipo'].upper()}  ·  "
            f"Loja: {normalizar_loja(usuario.get('loja', '381'))}"
        )

        if st.button("Sair", use_container_width=True, key="btn_sair_app"):
            limpar_sessao()

        st.markdown("---")
        st.header("Navegação")

        pagina = st.session_state["pagina_atual"]

        if usuario_tem("view_stock"):
            if st.button(
                "Estoque",
                use_container_width=True,
                type="primary" if pagina == "estoque" else "secondary",
            ):
                st.session_state["pagina_atual"] = "estoque"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        if usuario_tem("view_leads") and usuario["tipo"] != "documentista":
            if st.button(
                "Painel de Leads",
                use_container_width=True,
                type="primary" if pagina == "leads" else "secondary",
            ):
                st.session_state["pagina_atual"] = "leads"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        if pagina == "leads" and usuario_tem("create_lead"):
            st.markdown("---")
            if st.button(
                "➕ Adicionar novo lead",
                use_container_width=True,
                key="btn_adicionar_novo_lead",
            ):
                st.session_state["abrir_formulario"] = True
                st.rerun()

        if usuario_tem("view_team"):
            if st.button(
                "Equipe de Vendedores",
                use_container_width=True,
                type="primary" if pagina == "vendedores" else "secondary",
            ):
                st.session_state["pagina_atual"] = "vendedores"
                st.rerun()

        if usuario_tem("use_chat"):
            total_nao_lidas = contar_chat_geral_nao_lidas(
                usuario["id"]
            )
            label_chat = "Central de Chat"
            if total_nao_lidas:
                label_chat += f" 🔴 ({total_nao_lidas})"

            if st.button(
                label_chat,
                use_container_width=True,
                type="primary" if pagina == "chat" else "secondary",
            ):
                st.session_state["pagina_atual"] = "chat"
                st.rerun()

        # Manu Automóveis Suporte (IA)
        if usuario_tem("view_ia_suporte") or usuario_e_gestor() or usuario.get("tipo") in {
            "vendedor", "marketing", "elfen_ai", "financeiro", "documentista",
        }:
            if st.button(
                "Suporte IA",
                use_container_width=True,
                type="primary" if pagina == "suporte_ia" else "secondary",
            ):
                st.session_state["pagina_atual"] = "suporte_ia"
                st.rerun()

        if usuario_tem("view_goals"):
            if st.button(
                "Metas",
                use_container_width=True,
                type="primary" if pagina == "metas" else "secondary",
            ):
                st.session_state["pagina_atual"] = "metas"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        if usuario_tem("view_credit_fichas"):
            notificacoes_fichas = contar_notificacoes_nao_lidas(
                usuario["id"]
            )
            label_fichas = "Fichas de Crédito"
            if notificacoes_fichas:
                label_fichas += f" 🔴 ({notificacoes_fichas})"

            if st.button(
                label_fichas,
                use_container_width=True,
                type="primary" if pagina == "fichas" else "secondary",
            ):
                st.session_state["pagina_atual"] = "fichas"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        if usuario_tem("view_faturamento") or usuario_e_gestor():
            if st.button(
                "Faturamento",
                use_container_width=True,
                type="primary" if pagina == "faturamento" else "secondary",
            ):
                st.session_state["pagina_atual"] = "faturamento"
                st.rerun()

        if usuario_e_gestor() or usuario.get("tipo") == "vendedor":
            if st.button(
                "WhatsApp",
                use_container_width=True,
                type="primary" if pagina == "whatsapp" else "secondary",
            ):
                st.session_state["pagina_atual"] = "whatsapp"
                st.rerun()

        if usuario_tem("view_oficina"):
            if st.button(
                "Oficina",
                use_container_width=True,
                type="primary" if pagina == "oficina" else "secondary",
            ):
                st.session_state["pagina_atual"] = "oficina"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        if usuario_tem("view_tasks"):
            tarefas_nao_lidas = contar_tarefas_nao_visualizadas(
                usuario["id"]
            )
            label_tarefas = "Tarefas"
            if tarefas_nao_lidas:
                label_tarefas += f" 🔴 ({tarefas_nao_lidas})"

            if st.button(
                label_tarefas,
                use_container_width=True,
                type="primary" if pagina == "tarefas" else "secondary",
            ):
                st.session_state["pagina_atual"] = "tarefas"
                st.session_state["abrir_formulario"] = False
                st.rerun()

        # Mantém processos documentais como a última opção da navegação.
        if usuario_tem("view_transferencias"):
            if st.button(
                "Processos de Transferência",
                use_container_width=True,
                type=(
                    "primary"
                    if pagina in {"documentos", "transferencias"}
                    else "secondary"
                ),
            ):
                st.session_state["pagina_atual"] = "transferencias"
                st.session_state["abrir_formulario"] = False
                st.rerun()


def mostrar_formulario_novo_lead(
    usuario: Dict[str, Any],
    df_vendedores: pd.DataFrame,
) -> None:
    if not usuario_tem("create_lead"):
        return

    st.subheader("Novo Lead")

    if df_vendedores.empty:
        st.warning("Nenhum vendedor ativo foi encontrado.")
        return

    # Fora do formulário para que os campos da ficha apareçam imediatamente
    # quando a opção for marcada.
    gerou_ficha = st.checkbox(
        "Gerar ficha de crédito",
        key="gerou_ficha_novo_lead",
    )
    cliente_na_loja = False
    if gerou_ficha:
        cliente_na_loja = st.checkbox(
            "Cliente está na loja",
            key="cliente_na_loja_novo_lead",
            help="Clientes na loja aparecem primeiro para o ElfenAI.",
        )

    with st.form("form_novo_lead", clear_on_submit=False):
        col1, col2 = st.columns(2)

        with col1:
            nome = st.text_input("Nome do lead*")
            telefone = st.text_input("Telefone*")

            if usuario["tipo"] == "gerente":
                vendedor_id = st.selectbox(
                    "Vendedor responsável*",
                    options=df_vendedores["id"].tolist(),
                    format_func=lambda valor: df_vendedores.loc[
                        df_vendedores["id"] == valor, "nome"
                    ].iloc[0],
                )
            else:
                vendedor_id = usuario.get("vendedor_id")
                st.info(f"Vendedor atribuído: **{usuario['nome']}**")

        with col2:
            data_lead = st.date_input("Data que o lead chegou*")
            venda_concluida = st.checkbox("Venda concluída?")

        cpf = None
        data_nascimento = None
        habilitado = None
        valor_entrada = None
        anexos_ficha = []
        nome_completo = ""
        carro_selecionado = ""
        placa_carro = ""
        ano_carro = None
        valor_carro = 0.0
        nome_pai = None
        nome_mae = None
        rg = None
        data_expedicao = None
        orgao_expeditor = None
        empresa = None
        cnpj = None
        endereco_empresa = None
        bairro_empresa = None
        cidade_empresa = None
        estado_empresa = None
        cep_empresa = None
        endereco = None
        bairro = None
        cidade = None
        estado = None
        cep = None
        email = None
        tempo_carreira = None
        salario = None
        banco_correntista = None

        if gerou_ficha:
            st.markdown("### 📝 Dados da ficha")
            col_ficha_1, col_ficha_2 = st.columns(2)

            with col_ficha_1:
                nome_completo = st.text_input(
                    "Nome completo",
                    value=nome,
                )
                cpf = st.text_input("CPF")
                data_nascimento = st.text_input(
                    "Data de nascimento (DD/MM/AAAA)",
                    placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                    help="Sem limite mínimo de ano. Digite a data completa.",
                )
                carro_selecionado = st.text_input(
                    "Carro selecionado",
                    help="Veículo escolhido para esta ficha.",
                )
                placa_carro = st.text_input(
                    "Placa do carro",
                    placeholder="ABC1D23",
                    max_chars=8,
                )

            with col_ficha_2:
                habilitado = st.radio(
                    "O cliente é habilitado?",
                    ["Não", "Sim"],
                    horizontal=True,
                ) == "Sim"
                valor_entrada = st.number_input(
                    "Valor de entrada",
                    min_value=0.0,
                    step=100.0,
                )
                ano_carro = st.number_input(
                    "Ano do carro",
                    min_value=1900,
                    max_value=2100,
                    step=1,
                    value=None,
                    format="%d",
                )
                valor_carro = st.number_input(
                    "Valor do carro",
                    min_value=0.0,
                    step=1000.0,
                    value=None,
                )

            st.markdown("#### Dados pessoais e endereço residencial")
            col_pessoal_1, col_pessoal_2 = st.columns(2)
            with col_pessoal_1:
                nome_pai = st.text_input("Nome do pai")
                rg = st.text_input("RG")
                orgao_expeditor = st.text_input("Órgão expedidor")
                email = st.text_input("E-mail")
                endereco = st.text_input("Endereço residencial")
                bairro = st.text_input("Bairro residencial")
            with col_pessoal_2:
                nome_mae = st.text_input("Nome da mãe")
                data_expedicao = st.text_input(
                    "Data de expedição do RG (DD/MM/AAAA)",
                    placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                )
                cidade = st.text_input("Cidade residencial")
                estado = st.text_input("Estado residencial", max_chars=2)
                cep = st.text_input(
                    "CEP residencial",
                    placeholder="00000-000",
                    max_chars=9,
                )

            st.markdown("#### Dados da empresa (opcional)")
            st.caption(
                "Para cliente autônomo, deixe os campos da empresa em branco."
            )
            col_empresa_1, col_empresa_2 = st.columns(2)
            with col_empresa_1:
                empresa = st.text_input("Nome da empresa")
                cnpj = st.text_input("CNPJ")
                endereco_empresa = st.text_input("Endereço da empresa")
                bairro_empresa = st.text_input("Bairro da empresa")
            with col_empresa_2:
                cidade_empresa = st.text_input("Cidade da empresa")
                estado_empresa = st.text_input(
                    "Estado da empresa",
                    max_chars=2,
                )
                cep_empresa = st.text_input(
                    "CEP da empresa",
                    placeholder="00000-000",
                    max_chars=9,
                )
                tempo_carreira = st.text_input(
                    "Tempo de trabalho na empresa",
                    placeholder="Ex.: 3 anos",
                )

            col_trabalho_1, col_trabalho_2 = st.columns(2)
            with col_trabalho_1:
                salario = st.number_input(
                    "Salário mensal",
                    min_value=0.0,
                    step=100.0,
                )
            with col_trabalho_2:
                banco_correntista = st.text_input("Banco correntista")

            anexos_ficha = st.file_uploader(
                "Documentos da ficha",
                type=[
                    "pdf",
                    "png",
                    "jpg",
                    "jpeg",
                    "webp",
                    "doc",
                    "docx",
                    "xls",
                    "xlsx",
                ],
                accept_multiple_files=True,
                help=(
                    "Você poderá adicionar outros documentos depois. "
                    "Eles ficarão disponíveis para o documentista. "
                    "Com anexo, os dados da ficha podem ficar em branco."
                ),
            )

        observacao = st.text_area("Observações gerais")

        salvar = st.form_submit_button(
            "Gerar ficha e salvar lead" if gerou_ficha else "Salvar lead",
            use_container_width=True,
            type="primary",
        )

    if not salvar:
        return

    if not nome.strip() or not telefone.strip() or not vendedor_id:
        st.warning("Preencha nome, telefone e vendedor.")
        return

    nascimento_convertido = None
    expedicao_formatada = None
    if gerou_ficha:
        nascimento_convertido = converter_data_opcional(data_nascimento)
        if (
            str(data_nascimento or "").strip()
            and nascimento_convertido is None
        ):
            st.error(
                "Data de nascimento inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
            )
            return

        expedicao_convertida = converter_data_opcional(data_expedicao)
        if (
            str(data_expedicao or "").strip()
            and expedicao_convertida is None
        ):
            st.error(
                "Data de expedição inválida. Use DD/MM/AAAA ou DD-MM-AAAA."
            )
            return
        expedicao_formatada = data_para_texto_br(
            expedicao_convertida
        )

    if gerou_ficha and not anexos_ficha and (
        not carro_selecionado.strip()
        or not marca_carro.strip()
        or not cor_carro.strip()
        or not placa_carro.strip()
        or not ano_carro
        or valor_carro is None
        or valor_carro <= 0
    ):
        st.warning(
            "Ao gerar a ficha, informe carro, marca, cor, placa, ano "
            "e valor do carro."
        )
        return

    placa_carro_normalizada = (
        placa_carro.strip().replace("-", "").replace(" ", "").upper()
        if gerou_ficha
        else None
    )

    try:
        query = text(
            """
            INSERT INTO public.leads (
                nome_lead,
                telefone,
                vendedor_id,
                data_lead,
                gerou_ficha,
                cliente_na_loja,
                venda_concluida,
                cpf,
                nome_completo,
                data_nascimento,
                habilitado,
                aprovou_credito,
                produto_interesse,
                carro_selecionado,
                marca_carro,
                cor_carro,
                ano_carro,
                placa_carro,
                valor_carro,
                valor_entrada,
                observacao,
                created_at,
                updated_at
            )
            VALUES (
                :nome,
                :telefone,
                :vendedor_id,
                :data_lead,
                :gerou_ficha,
                :cliente_na_loja,
                :venda_concluida,
                :cpf,
                :nome_completo,
                :data_nascimento,
                :habilitado,
                :aprovou_credito,
                :produto_interesse,
                :carro_selecionado,
                :marca_carro,
                :cor_carro,
                :ano_carro,
                :placa_carro,
                :valor_carro,
                :valor_entrada,
                :observacao,
                NOW(),
                NOW()
            )
            RETURNING id
            """
        )

        with engine.begin() as conn:
            lead_id = conn.execute(
                query,
                {
                    "nome": nome.strip(),
                    "telefone": telefone.strip(),
                    "vendedor_id": vendedor_id,
                    "data_lead": data_lead,
                    "gerou_ficha": gerou_ficha,
                    "cliente_na_loja": (
                        cliente_na_loja if gerou_ficha else False
                    ),
                    "venda_concluida": venda_concluida,
                    "cpf": cpf.strip() if cpf else None,
                    "nome_completo": (
                        nome_completo.strip()
                        if gerou_ficha and nome_completo.strip()
                        else nome.strip()
                    ),
                    "data_nascimento": nascimento_convertido,
                    "habilitado": habilitado,
                    "aprovou_credito": None,
                    "produto_interesse": (
                        carro_selecionado.strip()
                        if gerou_ficha and carro_selecionado
                        else None
                    ),
                    "carro_selecionado": (
                        carro_selecionado.strip()
                        if gerou_ficha
                        else None
                    ),
                    "marca_carro": (
                        marca_carro.strip()
                        if gerou_ficha and marca_carro.strip()
                        else None
                    ),
                    "cor_carro": (
                        cor_carro.strip()
                        if gerou_ficha and cor_carro.strip()
                        else None
                    ),
                    "ano_carro": (
                        int(ano_carro)
                        if gerou_ficha and ano_carro is not None
                        else None
                    ),
                    "placa_carro": placa_carro_normalizada,
                    "valor_carro": (
                        valor_carro
                        if gerou_ficha and valor_carro is not None
                        else None
                    ),
                    "valor_entrada": (
                        valor_entrada
                        if gerou_ficha
                        else None
                    ),
                    "observacao": (
                        observacao.strip()
                        if observacao.strip()
                        else None
                    ),
                },
            ).scalar_one()

            if gerou_ficha:
                conn.execute(
                    text(
                        """
                        UPDATE public.leads
                        SET
                            nome_pai = :nome_pai,
                            nome_mae = :nome_mae,
                            rg = :rg,
                            data_expedicao = :data_expedicao,
                            orgao_expeditor = :orgao_expeditor,
                            empresa = :empresa,
                            cnpj = :cnpj,
                            endereco_empresa = :endereco_empresa,
                            bairro_empresa = :bairro_empresa,
                            cidade_empresa = :cidade_empresa,
                            estado_empresa = :estado_empresa,
                            cep_empresa = :cep_empresa,
                            endereco = :endereco,
                            bairro = :bairro,
                            cidade = :cidade,
                            estado = :estado,
                            cep = :cep,
                            email = :email,
                            tempo_carreira = :tempo_carreira,
                            salario = :salario,
                            banco_correntista = :banco_correntista
                        WHERE id = :lead_id
                        """
                    ),
                    {
                        "lead_id": int(lead_id),
                        "nome_pai": nome_pai.strip() or None,
                        "nome_mae": nome_mae.strip() or None,
                        "rg": rg.strip() or None,
                        "data_expedicao": expedicao_formatada,
                        "orgao_expeditor": orgao_expeditor.strip() or None,
                        "empresa": empresa.strip() or None,
                        "cnpj": cnpj.strip() or None,
                        "endereco_empresa": endereco_empresa.strip() or None,
                        "bairro_empresa": bairro_empresa.strip() or None,
                        "cidade_empresa": cidade_empresa.strip() or None,
                        "estado_empresa": estado_empresa.strip() or None,
                        "cep_empresa": cep_empresa.strip() or None,
                        "endereco": endereco.strip() or None,
                        "bairro": bairro.strip() or None,
                        "cidade": cidade.strip() or None,
                        "estado": estado.strip() or None,
                        "cep": cep.strip() or None,
                        "email": email.strip() or None,
                        "tempo_carreira": tempo_carreira.strip() or None,
                        "salario": salario or None,
                        "banco_correntista": banco_correntista.strip() or None,
                    },
                )

                ficha_id = criar_ficha_credito(
                    conn=conn,
                    lead_id=int(lead_id),
                    vendedor_id=vendedor_id,
                    valor_entrada=float(valor_entrada or 0),
                    usuario_id=usuario["id"],
                )
                salvar_anexos_ficha(
                    conn,
                    ficha_id,
                    usuario["id"],
                    anexos_ficha,
                )

        st.cache_data.clear()
        st.success("Lead inserido com sucesso.")
        st.session_state["abrir_formulario"] = False
        st.rerun()

    except Exception as erro:
        st.error(f"Erro ao inserir lead: {erro}")


def mostrar_card_lead(
    row: pd.Series,
    usuario: Dict[str, Any],
    df_vendedores: pd.DataFrame,
) -> None:
    with st.container(border=True):
        st.markdown(f"### 👤 {row['nome_lead']}")

        venda_realizada = bool(
            row.get("venda_concluida", False)
            or row.get("vendeu", False)
        )

        if venda_realizada:
            st.success("VENDA CONCLUÍDA")

        st.write(
            f"**Vendedor:** "
            f"{row.get('nome_vendedor') or 'Não atribuído'}"
        )
        st.write(f"**Telefone:** {row.get('telefone') or '-'}")
        link_whatsapp = gerar_link_whatsapp(row.get("telefone"))
        if link_whatsapp:
            st.link_button(
                "WhatsApp",
                link_whatsapp,
                icon="💬",
                use_container_width=True,
            )
        st.write(
            f"**Data do lead:** "
            f"{formatar_data_br(row.get('data_lead'))}"
        )
        st.write(
            f"**Carro selecionado:** "
            f"{row.get('carro_selecionado') or row.get('produto_interesse') or '-'}"
        )
        st.write(
            f"**Ano / placa / valor:** "
            f"{row.get('ano_carro') or '-'} / "
            f"{row.get('placa_carro') or '-'} / "
            f"R$ {numero_seguro(row.get('valor_carro')):,.2f}"
        )
        st.write(
            f"**Ficha gerada:** "
            f"{'Sim' if row.get('gerou_ficha') else 'Não'}"
        )
        if row.get("gerou_ficha"):
            st.write(
                f"**Cliente na loja:** "
                f"{'Sim' if row.get('cliente_na_loja') else 'Não'}"
            )

        # Dados pessoais/documentais só aparecem para quem tem essa
        # permissão. O financeiro não recebe CPF na interface.
        if usuario_tem("view_documents") and row.get("gerou_ficha"):
            with st.expander("Ver dados da ficha"):
                st.write(f"**CPF:** {row.get('cpf') or 'Não informado'}")
                st.write(
                    f"**Data de nascimento:** "
                    f"{formatar_data_br(row.get('data_nascimento'), padrao='Não informada')}"
                )
                st.write(
                    f"**Habilitado:** "
                    f"{'Sim' if row.get('habilitado') else 'Não'}"
                )

        if usuario_tem("view_financial") and row.get("gerou_ficha"):
            aprovado = row.get("aprovou_credito")
            if aprovado is True:
                st.success("Crédito: aprovado")
            elif aprovado is False:
                st.error("Crédito: recusado")
            else:
                st.warning("Crédito: em análise")

            st.write(
                f"**Venda concluída:** "
                f"{'Sim' if venda_realizada else 'Não'}"
            )

        if row.get("observacao"):
            st.info(f"**Observações:** {row['observacao']}")

        pode_editar = pode_editar_lead(row, usuario)
        pode_deletar = pode_deletar_lead(row, usuario)

        if pode_editar or pode_deletar:
            st.markdown("---")
            col_editar, col_excluir = st.columns(2)

            with col_editar:
                if pode_editar and st.button(
                    "Editar",
                    key=f"editar_{row['id']}",
                    use_container_width=True,
                ):
                    editar_lead_modal(row, df_vendedores)

            with col_excluir:
                if pode_deletar and st.button(
                    "Excluir",
                    key=f"excluir_{row['id']}",
                    use_container_width=True,
                ):
                    deletar_lead_modal(row)

        atualizado = row.get("updated_at")
        if atualizado:
            st.caption(
                "Atualizado em: "
                f"{formatar_data_br(atualizado, incluir_hora=True)}"
            )

        transferido_em = row.get("ultima_transferencia_em")
        if pd.notna(transferido_em):
            st.caption(
                f"Transferido de "
                f"'{row.get('ultima_transferencia_origem') or 'Sem vendedor'}' "
                f"para "
                f"'{row.get('ultima_transferencia_destino') or 'Sem vendedor'}' "
                f"por: "
                f"'{row.get('ultima_transferencia_por') or 'Gerente'}' "
                f"em: {formatar_data_br(transferido_em, incluir_hora=True)}"
            )


@st.cache_data(ttl=30, show_spinner=False)
def obter_estoque_carros(busca: str = "") -> pd.DataFrame:
    filtros = ["COALESCE(ativo, TRUE) = TRUE"]
    parametros: Dict[str, Any] = {}

    busca_limpa = busca.strip()
    if busca_limpa:
        filtros.append(
            """
            (
                marca ILIKE :busca
                OR carro ILIKE :busca
                OR modelo ILIKE :busca
                OR cor ILIKE :busca
                OR placa ILIKE :busca
                OR CAST(ano AS TEXT) ILIKE :busca
                OR similarity(COALESCE(marca, ''), :busca_raw) > 0.3
                OR similarity(COALESCE(carro, ''), :busca_raw) > 0.3
                OR similarity(COALESCE(modelo, ''), :busca_raw) > 0.25
            )
            """
        )
        parametros["busca"] = f"%{busca_limpa}%"
        parametros["busca_raw"] = busca_limpa

    query = text(
        f"""
        SELECT
            id,
            marca,
            carro,
            modelo,
            preco,
            ano,
            patio,
            cor,
            combustivel,
            placa,
            km,
            leilao,
            status,
            ativo,
            created_at
        FROM public.estoque_carros
        WHERE {" AND ".join(f"({filtro})" for filtro in filtros)}
        ORDER BY
            LOWER(COALESCE(marca, '')),
            LOWER(COALESCE(carro, '')),
            LOWER(COALESCE(modelo, '')),
            id
        """
    )

    with engine.connect() as conn:
        return pd.read_sql_query(query, conn, params=parametros)


def salvar_anexos_estoque(
    conn: Any,
    carro_id: int,
    usuario_id: int,
    arquivos: Any,
) -> None:
    """Anexos do estoque → bucket manu_arquivos (fallback: bytes no DB)."""
    if not arquivos:
        return

    if not isinstance(arquivos, (list, tuple)):
        arquivos = [arquivos]

    for arquivo in arquivos:
        if arquivo is None:
            continue
        conteudo = arquivo.getvalue()
        if not conteudo:
            continue
        nome = getattr(arquivo, "name", None) or "documento"
        mime = getattr(arquivo, "type", None) or "application/octet-stream"
        caminho = caminho_storage_unico(f"estoque/{carro_id}", nome)
        path_ok = upload_para_storage(
            STORAGE_BUCKET_ARQUIVOS, caminho, conteudo, mime
        )
        try:
            conn.execute(
                text(
                    """
                    INSERT INTO public.estoque_carros_anexos (
                        carro_id,
                        nome_arquivo,
                        mime_type,
                        arquivo_bytes,
                        storage_bucket,
                        storage_path,
                        enviado_por_id
                    )
                    VALUES (
                        :carro_id,
                        :nome_arquivo,
                        :mime_type,
                        :arquivo_bytes,
                        :storage_bucket,
                        :storage_path,
                        :usuario_id
                    )
                    """
                ),
                {
                    "carro_id": carro_id,
                    "nome_arquivo": nome,
                    "mime_type": mime,
                    "arquivo_bytes": None if path_ok else conteudo,
                    "storage_bucket": STORAGE_BUCKET_ARQUIVOS if path_ok else None,
                    "storage_path": path_ok,
                    "usuario_id": usuario_id,
                },
            )
        except Exception:
            conn.execute(
                text(
                    """
                    INSERT INTO public.estoque_carros_anexos (
                        carro_id, nome_arquivo, mime_type,
                        arquivo_bytes, enviado_por_id
                    )
                    VALUES (
                        :carro_id, :nome_arquivo, :mime_type,
                        :arquivo_bytes, :usuario_id
                    )
                    """
                ),
                {
                    "carro_id": carro_id,
                    "nome_arquivo": nome,
                    "mime_type": mime,
                    "arquivo_bytes": conteudo,
                    "usuario_id": usuario_id,
                },
            )


@st.cache_data(ttl=60, show_spinner=False)
def obter_anexos_estoque(carro_id: int) -> pd.DataFrame:
    query = text(
        """
        SELECT
            a.id,
            a.nome_arquivo,
            a.mime_type,
            a.arquivo_bytes,
            a.created_at,
            u.nome AS enviado_por
        FROM public.estoque_carros_anexos a
        LEFT JOIN public.usuarios u
            ON u.id = a.enviado_por_id
        WHERE a.carro_id = :carro_id
        ORDER BY a.created_at DESC, a.id DESC
        """
    )
    with engine.connect() as conn:
        return pd.read_sql_query(
            query,
            conn,
            params={"carro_id": carro_id},
        )


@st.cache_data(ttl=60, show_spinner=False)
def obter_contagem_anexos_estoque(
    carro_ids: tuple[int, ...],
) -> Dict[int, int]:
    if not carro_ids:
        return {}

    ids_sql = ",".join(str(int(carro_id)) for carro_id in carro_ids)
    query = text(
        f"""
        SELECT carro_id, COUNT(*) AS total
        FROM public.estoque_carros_anexos
        WHERE carro_id IN ({ids_sql})
        GROUP BY carro_id
        """
    )
    try:
        with engine.connect() as conn:
            resultado = conn.execute(query).mappings().all()
        return {
            int(item["carro_id"]): int(item["total"] or 0)
            for item in resultado
        }
    except Exception:
        return {}


def mostrar_anexos_estoque(
    carro_id: int,
    usuario: Dict[str, Any],
    chave: str,
    expandido: bool = False,
) -> None:
    try:
        anexos = obter_anexos_estoque(carro_id)
    except Exception as erro:
        st.warning(
            "Execute migration_estoque_carros.sql para ativar os anexos. "
            f"Detalhe: {erro}"
        )
        return

    with st.expander(
        f"📎 Arquivos do carro ({len(anexos)})",
        expanded=expandido,
    ):
        if anexos.empty:
            st.caption("Nenhum arquivo anexado.")
        else:
            for _, anexo in anexos.iterrows():
                conteudo = anexo.get("arquivo_bytes")
                if conteudo is None or (
                    isinstance(conteudo, float) and pd.isna(conteudo)
                ):
                    continue
                nome = anexo.get("nome_arquivo") or "documento"
                mime = (
                    anexo.get("mime_type")
                    or "application/octet-stream"
                )
                col_arquivo_1, col_arquivo_2 = st.columns([3, 1])
                col_arquivo_1.write(
                    f"**{nome}** · "
                    f"{formatar_data_br(anexo.get('created_at'), True)}"
                )
                col_arquivo_2.download_button(
                    "Baixar",
                    data=conteudo,
                    file_name=nome,
                    mime=mime,
                    key=f"baixar_estoque_{chave}_{anexo['id']}",
                )
                if usuario_tem("manage_stock") and st.button(
                    "Excluir",
                    key=f"excluir_estoque_anexo_{chave}_{anexo['id']}",
                ):
                    excluir_anexo_estoque_modal(
                        carro_id,
                        int(anexo["id"]),
                        str(nome),
                    )

        if usuario_tem("manage_stock"):
            novos_arquivos = st.file_uploader(
                "Anexar arquivos",
                type=[
                    "pdf",
                    "png",
                    "jpg",
                    "jpeg",
                    "webp",
                    "doc",
                    "docx",
                    "xls",
                    "xlsx",
                ],
                accept_multiple_files=True,
                key=f"upload_estoque_{chave}",
            )
            if st.button(
                "Salvar arquivos",
                key=f"salvar_arquivos_estoque_{chave}",
                disabled=not novos_arquivos,
            ):
                try:
                    with engine.begin() as conn:
                        salvar_anexos_estoque(
                            conn,
                            carro_id,
                            usuario["id"],
                            novos_arquivos,
                        )
                    st.cache_data.clear()
                    st.success("Arquivos anexados ao carro.")
                    st.rerun()
                except Exception as erro:
                    st.error(f"Erro ao anexar arquivos: {erro}")


def excluir_anexo_estoque(
    carro_id: int,
    anexo_id: int,
) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                DELETE FROM public.estoque_carros_anexos
                WHERE id = :anexo_id
                  AND carro_id = :carro_id
                """
            ),
            {
                "anexo_id": anexo_id,
                "carro_id": carro_id,
            },
        )


@st.dialog("Excluir arquivo do estoque")
def excluir_anexo_estoque_modal(
    carro_id: int,
    anexo_id: int,
    nome_arquivo: str,
) -> None:
    if not usuario_tem("manage_stock"):
        st.error("Somente gerente e documentista podem excluir arquivos.")
        return

    st.warning(
        f"O arquivo **{nome_arquivo}** será excluído definitivamente."
    )
    if st.button(
        "Excluir arquivo",
        type="primary",
        use_container_width=True,
    ):
        try:
            excluir_anexo_estoque(carro_id, anexo_id)
            st.cache_data.clear()
            st.success("Arquivo excluído.")
            st.rerun()
        except Exception as erro:
            st.error(f"Erro ao excluir arquivo: {erro}")


@st.dialog("Arquivos do carro")
def abrir_anexos_estoque_modal(
    carro_id: int,
    usuario: Dict[str, Any],
) -> None:
    mostrar_anexos_estoque(
        carro_id,
        usuario,
        f"modal_{carro_id}",
        expandido=True,
    )


@st.dialog("Editar carro do estoque")
def editar_carro_estoque_modal(carro_data: pd.Series) -> None:
    usuario = st.session_state["usuario_logado"]
    if not usuario_tem("manage_stock"):
        st.error("Somente gerente e documentista podem editar carros.")
        return

    with st.form(f"form_editar_estoque_{carro_data['id']}"):
        col1, col2, col3 = st.columns(3)
        marca = col1.text_input(
            "Marca*",
            value=str(carro_data.get("marca") or ""),
        )
        carro = col2.text_input(
            "Carro*",
            value=str(carro_data.get("carro") or ""),
        )
        modelo = col3.text_input(
            "Modelo",
            value=str(carro_data.get("modelo") or ""),
        )

        col4, col5, col6 = st.columns(3)
        preco = col4.number_input(
            "Preço",
            min_value=0.0,
            value=numero_seguro(carro_data.get("preco")),
            step=1000.0,
        )
        ano = col5.text_input(
            "Ano",
            value=str(carro_data.get("ano") or ""),
        )
        patio = col6.text_input(
            "Pátio",
            value=str(carro_data.get("patio") or ""),
        )

        col7, col8, col9 = st.columns(3)
        cor = col7.text_input(
            "Cor",
            value=str(carro_data.get("cor") or ""),
        )
        combustivel = col8.text_input(
            "Combustível",
            value=str(carro_data.get("combustivel") or ""),
        )
        placa = col9.text_input(
            "Placa",
            value=str(carro_data.get("placa") or ""),
        )

        col10, col11, col12 = st.columns(3)
        km = col10.number_input(
            "Km",
            min_value=0,
            value=inteiro_seguro(carro_data.get("km"), 0),
            step=1000,
        )
        status_atual = str(carro_data.get("status") or "disponivel")
        status_opcoes = sorted(
            set(
                [
                    "disponivel",
                    "reservado",
                    "vendido",
                    "manutencao",
                    status_atual,
                ]
            )
        )
        status = col11.selectbox(
            "Status",
            status_opcoes,
            index=status_opcoes.index(status_atual),
        )
        leilao = col12.checkbox(
            "Leilão",
            value=bool(carro_data.get("leilao")),
        )

        salvar = st.form_submit_button(
            "Salvar carro",
            use_container_width=True,
            type="primary",
        )

    if not salvar:
        return
    if not marca.strip() or not carro.strip():
        st.warning("Marca e carro são obrigatórios.")
        return

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE public.estoque_carros
                    SET
                        marca = :marca,
                        carro = :carro,
                        modelo = :modelo,
                        preco = :preco,
                        ano = :ano,
                        patio = :patio,
                        cor = :cor,
                        combustivel = :combustivel,
                        placa = :placa,
                        km = :km,
                        leilao = :leilao,
                        status = :status
                    WHERE id = :id
                    """
                ),
                {
                    "marca": marca.strip(),
                    "carro": carro.strip(),
                    "modelo": modelo.strip() or None,
                    "preco": preco,
                    "ano": ano.strip() or None,
                    "patio": patio.strip() or None,
                    "cor": cor.strip() or None,
                    "combustivel": combustivel.strip() or None,
                    "placa": placa.strip().replace("-", "").upper() or None,
                    "km": km,
                    "leilao": leilao,
                    "status": status,
                    "id": int(carro_data["id"]),
                },
            )
        st.cache_data.clear()
        st.success("Carro atualizado.")
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao editar carro: {erro}")


@st.dialog("Excluir carro do estoque")
def excluir_carro_estoque_modal(carro_data: pd.Series) -> None:
    usuario = st.session_state["usuario_logado"]
    if not usuario_tem("manage_stock"):
        st.error("Somente gerente e documentista podem excluir carros.")
        return

    nome = " ".join(
        str(valor).strip()
        for valor in [
            carro_data.get("marca"),
            carro_data.get("carro"),
            carro_data.get("modelo"),
        ]
        if valor and str(valor).strip()
    )
    st.warning(
        f"O carro **{nome}** será retirado do estoque. "
        "Os anexos e o histórico serão preservados."
    )
    confirmar = st.button(
        "Sim, excluir carro",
        type="primary",
        use_container_width=True,
    )
    cancelar = st.button("Cancelar", use_container_width=True)

    if cancelar:
        st.rerun()
    if confirmar:
        try:
            with engine.begin() as conn:
                conn.execute(
                    text(
                        """
                        UPDATE public.estoque_carros
                        SET ativo = FALSE
                        WHERE id = :id
                        """
                    ),
                    {"id": int(carro_data["id"])},
                )
            st.cache_data.clear()
            st.success("Carro retirado do estoque.")
            st.rerun()
        except Exception as erro:
            st.error(f"Erro ao excluir carro: {erro}")


def mostrar_card_estoque(
    carro_data: pd.Series,
    usuario: Dict[str, Any],
    chave: str,
    quantidade_anexos: int = 0,
) -> None:
    with st.container(border=True):
        titulo = " ".join(
            str(valor).strip()
            for valor in [
                carro_data.get("carro"),
                carro_data.get("modelo"),
            ]
            if valor and str(valor).strip()
        ) or "Carro sem descrição"
        st.subheader(titulo)

        col1, col2, col3 = st.columns(3)
        col1.write(f"**Marca:** {carro_data.get('marca') or '-'}")
        col2.write(f"**Ano:** {carro_data.get('ano') or '-'}")
        col3.write(
            f"**Preço:** R$ {numero_seguro(carro_data.get('preco')):,.2f}"
        )
        col4, col5, col6 = st.columns(3)
        col4.write(f"**Placa:** {carro_data.get('placa') or '-'}")
        col5.write(f"**Cor:** {carro_data.get('cor') or '-'}")
        col6.write(f"**Combustível:** {carro_data.get('combustivel') or '-'}")
        col7, col8, col9 = st.columns(3)
        col7.write(
            f"**Km:** {inteiro_seguro(carro_data.get('km'), 0):,}"
        )
        col8.write(f"**Pátio:** {carro_data.get('patio') or '-'}")
        col9.write(f"**Status:** {carro_data.get('status') or '-'}")

        if carro_data.get("leilao"):
            st.info("Este veículo é de leilão.")

        if st.button(
            f"📎 Arquivos ({quantidade_anexos})",
            key=f"abrir_anexos_estoque_{chave}_{carro_data['id']}",
            use_container_width=True,
        ):
            abrir_anexos_estoque_modal(
                int(carro_data["id"]),
                usuario,
            )

        if usuario_tem("manage_stock"):
            col_editar, col_excluir = st.columns(2)
            with col_editar:
                if st.button(
                    "Editar carro",
                    key=f"editar_estoque_{chave}_{carro_data['id']}",
                    use_container_width=True,
                ):
                    editar_carro_estoque_modal(carro_data)
            with col_excluir:
                if st.button(
                    "Excluir carro",
                    key=f"excluir_estoque_{chave}_{carro_data['id']}",
                    use_container_width=True,
                ):
                    excluir_carro_estoque_modal(carro_data)


def mostrar_lista_estoque(
    estoque: pd.DataFrame,
    usuario: Dict[str, Any],
    chave: str,
) -> None:
    if estoque.empty:
        st.info("Nenhum carro encontrado.")
        return

    ids_carros = tuple(int(valor) for valor in estoque["id"].tolist())
    contagens_anexos = obter_contagem_anexos_estoque(ids_carros)

    grupos: Dict[str, list] = {}
    for _, carro in estoque.iterrows():
        marca = str(carro.get("marca") or "Sem marca").strip()
        grupos.setdefault(marca, []).append(carro)

    for indice, marca in enumerate(
        sorted(grupos, key=lambda valor: valor.casefold())
    ):
        carros = grupos[marca]
        with st.expander(
            f"🚘 {marca} ({len(carros)})",
            expanded=False,
        ):
            for carro in carros:
                mostrar_card_estoque(
                    carro,
                    usuario,
                    chave,
                    contagens_anexos.get(int(carro["id"]), 0),
                )


def pagina_estoque(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("view_stock"):
        st.error("Você não tem permissão para ver o estoque.")
        return

    st.title("Estoque de carros")
    st.caption(
        "Todos podem consultar. Apenas gerente e documentista "
        "podem cadastrar, editar, excluir e anexar arquivos."
    )

    if usuario_tem("manage_stock"):
        with st.expander("➕ Cadastrar carro no estoque"):
            with st.form("form_novo_carro_estoque", clear_on_submit=True):
                col1, col2, col3 = st.columns(3)
                marca = col1.text_input("Marca*")
                carro = col2.text_input("Carro*")
                modelo = col3.text_input("Modelo")

                col4, col5, col6 = st.columns(3)
                preco = col4.number_input(
                    "Preço",
                    min_value=0.0,
                    step=1000.0,
                )
                ano = col5.text_input("Ano")
                patio = col6.text_input("Pátio")

                col7, col8, col9 = st.columns(3)
                cor = col7.text_input("Cor")
                combustivel = col8.text_input("Combustível")
                placa = col9.text_input("Placa")

                col10, col11, col12 = st.columns(3)
                km = col10.number_input("Km", min_value=0, step=1000)
                status = col11.selectbox(
                    "Status",
                    [
                        "disponivel",
                        "reservado",
                        "vendido",
                        "manutencao",
                    ],
                )
                leilao = col12.checkbox("Leilão")
                anexos = st.file_uploader(
                    "Arquivos do carro",
                    type=[
                        "pdf",
                        "png",
                        "jpg",
                        "jpeg",
                        "webp",
                        "doc",
                        "docx",
                        "xls",
                        "xlsx",
                    ],
                    accept_multiple_files=True,
                )
                salvar = st.form_submit_button(
                    "Cadastrar carro",
                    use_container_width=True,
                    type="primary",
                )

            if salvar:
                if not marca.strip() or not carro.strip():
                    st.warning("Marca e carro são obrigatórios.")
                else:
                    try:
                        placa_normalizada = (
                            placa.strip().replace("-", "").upper()
                            or None
                        )
                        with engine.begin() as conn:
                            carro_id = conn.execute(
                                text(
                                    """
                                    INSERT INTO public.estoque_carros (
                                        marca,
                                        carro,
                                        modelo,
                                        preco,
                                        ano,
                                        patio,
                                        cor,
                                        combustivel,
                                        placa,
                                        km,
                                        leilao,
                                        status,
                                        ativo
                                    )
                                    VALUES (
                                        :marca,
                                        :carro,
                                        :modelo,
                                        :preco,
                                        :ano,
                                        :patio,
                                        :cor,
                                        :combustivel,
                                        :placa,
                                        :km,
                                        :leilao,
                                        :status,
                                        TRUE
                                    )
                                    RETURNING id
                                    """
                                ),
                                {
                                    "marca": marca.strip(),
                                    "carro": carro.strip(),
                                    "modelo": modelo.strip() or None,
                                    "preco": preco,
                                    "ano": ano.strip() or None,
                                    "patio": patio.strip() or None,
                                    "cor": cor.strip() or None,
                                    "combustivel": (
                                        combustivel.strip() or None
                                    ),
                                    "placa": placa_normalizada,
                                    "km": km,
                                    "leilao": leilao,
                                    "status": status,
                                },
                            ).scalar_one()
                            salvar_anexos_estoque(
                                conn,
                                int(carro_id),
                                usuario["id"],
                                anexos,
                            )
                        st.cache_data.clear()
                        st.success("Carro cadastrado no estoque.")
                        st.rerun()
                    except Exception as erro:
                        st.error(f"Erro ao cadastrar carro: {erro}")

    aba_estoque, aba_pesquisa = st.tabs(
        ["Estoque por marca", "Pesquisar"]
    )

    with aba_estoque:
        try:
            mostrar_lista_estoque(
                obter_estoque_carros(),
                usuario,
                "estoque",
            )
        except Exception as erro:
            st.error(
                "Não foi possível carregar o estoque. "
                "Confira se a tabela public.estoque_carros existe. "
                f"Detalhe: {erro}"
            )

    with aba_pesquisa:
        with st.form("form_pesquisa_estoque"):
            busca_digitada = st.text_input(
                "Pesquisar no estoque",
                placeholder="Placa, cor, modelo, marca ou ano",
                key="busca_estoque_campo",
            )
            pesquisar_estoque = st.form_submit_button(
                "Pesquisar",
                use_container_width=True,
            )
        if pesquisar_estoque:
            st.session_state["busca_estoque_aplicada"] = busca_digitada
        busca = st.session_state.get("busca_estoque_aplicada", "")
        if not busca.strip():
            st.info("Digite uma placa, cor, modelo, marca ou ano para pesquisar.")
        else:
            try:
                mostrar_lista_estoque(
                    obter_estoque_carros(busca),
                    usuario,
                    "pesquisa_estoque",
                )
            except Exception as erro:
                st.error(f"Erro ao pesquisar estoque: {erro}")


# ============================================================
# PÁGINAS
# ============================================================

def pagina_documentista(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("view_transferencias"):
        st.error("Você não tem permissão para ver transferências.")
        return

    st.title("Processos de Transferência")
    if usuario["tipo"] == "vendedor":
        st.caption(
            "Visualização somente das suas vendas. "
            "Você pode adicionar documentos, mas não alterar o processo."
        )
    elif usuario["tipo"] in {"gerente", "documentista"}:
        st.caption("Você pode acompanhar e atualizar todos os processos.")
    else:
        st.caption("Visualização dos processos de transferência.")

    try:
        fichas = obter_fichas_documentais(usuario)
    except Exception as erro:
        st.error(
            "Execute schema_operacao_v3.sql no Supabase antes de abrir "
            f"esta área. Detalhe: {erro}"
        )
        return

    if fichas.empty:
        st.info("Nenhum cliente vendido encontrado.")
        return

    ids_fichas = tuple(int(valor) for valor in fichas["ficha_id"].tolist())
    contagens_anexos = obter_contagem_anexos_fichas(ids_fichas)

    nomes_status = {
        "nao_iniciado": "Não iniciado",
        "em_andamento": "Em andamento",
        "pronto": "Pronto",
    }
    status_opcoes = list(nomes_status)

    for _, ficha in fichas.iterrows():
        status_atual = ficha.get("transferencia_status") or "nao_iniciado"
        status_label = nomes_status.get(status_atual, status_atual)
        cliente = (
            ficha.get("nome_completo")
            or ficha.get("nome_lead")
            or "Cliente"
        )

        with st.expander(
            f"{'✅' if status_atual == 'pronto' else '⏳'} "
            f"{cliente} — {status_label}",
            expanded=(
                st.session_state.get("transferencia_aberta_id")
                == int(ficha["ficha_id"])
            ),
        ):
            transferencia_selecionada = (
                st.session_state.get("transferencia_aberta_id")
                == int(ficha["ficha_id"])
            )
            if not transferencia_selecionada:
                st.caption(
                    f"Vendedor: {ficha.get('vendedor_nome') or '-'} · "
                    f"Venda: {formatar_data_br(ficha.get('data_compra'))}"
                )
                if st.button(
                    "Abrir processo",
                    key=f"abrir_transferencia_{ficha['ficha_id']}",
                    use_container_width=True,
                ):
                    st.session_state["transferencia_aberta_id"] = int(
                        ficha["ficha_id"]
                    )
                    st.rerun()
                continue

            if st.button(
                "Fechar processo",
                key=f"fechar_transferencia_{ficha['ficha_id']}",
            ):
                st.session_state.pop("transferencia_aberta_id", None)
                st.rerun()

            c1, c2, c3 = st.columns(3)
            c1.write(f"**CPF:** {ficha.get('cpf') or '-'}")
            c2.write(f"**Telefone:** {ficha.get('telefone') or '-'}")
            c3.write(
                f"**Vendedor:** {ficha.get('vendedor_nome') or '-'}"
            )
            c4, c5, c6 = st.columns(3)
            c4.write(
                f"**Nascimento:** "
                f"{formatar_data_br(ficha.get('data_nascimento'))}"
            )
            c5.write(
                f"**Carro:** "
                f"{ficha.get('carro_selecionado') or ficha.get('produto_interesse') or '-'}"
            )
            c6.write(
                f"**Ano / placa:** "
                f"{ficha.get('ano_carro') or '-'} / "
                f"{ficha.get('placa_carro') or '-'}"
            )
            st.write(
                f"**Valor do carro:** "
                f"R$ {numero_seguro(ficha.get('valor_carro')):,.2f}"
            )
            st.caption(
                f"Venda: {formatar_data_br(ficha.get('data_compra'))}"
            )
            mostrar_botao_anexos_ficha(
                int(ficha["ficha_id"]),
                usuario,
                f"documentos_{ficha['ficha_id']}",
                contagens_anexos.get(int(ficha["ficha_id"]), 0),
            )

            if usuario["tipo"] in {"gerente", "documentista"}:
                with st.form(f"form_transferencia_{ficha['ficha_id']}"):
                    novo_status = st.selectbox(
                        "Situação da transferência",
                        status_opcoes,
                        index=(
                            status_opcoes.index(status_atual)
                            if status_atual in status_opcoes
                            else 0
                        ),
                        format_func=lambda valor: nomes_status[valor],
                    )
                    etapa_1, etapa_2, etapa_3 = st.columns(3)
                    reconheceu_firma = etapa_1.checkbox(
                        "Reconheceu firma",
                        value=bool(
                            ficha.get(
                                "transferencia_reconheceu_firma",
                                False,
                            )
                        ),
                    )
                    gravame = etapa_2.checkbox(
                        "Gravame",
                        value=bool(
                            ficha.get("transferencia_gravame", False)
                        ),
                    )
                    documento_pronto = etapa_3.checkbox(
                        "Documento pronto",
                        value=bool(
                            ficha.get(
                                "transferencia_documento_pronto",
                                False,
                            )
                        ),
                    )
                    nova_observacao = st.text_area(
                        "Observação",
                        value=str(
                            ficha.get("transferencia_observacao") or ""
                        ),
                        placeholder=(
                            "Ex.: documento enviado ao despachante, "
                            "aguardando assinatura..."
                        ),
                    )
                    salvar = st.form_submit_button(
                        "Salvar processo",
                        use_container_width=True,
                    )

                if salvar:
                    salvar_processo_transferencia(
                        usuario,
                        ficha,
                        novo_status,
                        nova_observacao,
                        reconheceu_firma,
                        gravame,
                        documento_pronto,
                    )
            else:
                st.info(
                    f"Situação: {status_label}. "
                    "Somente gerente e documentista podem alterar."
                )
                etapa_1, etapa_2, etapa_3 = st.columns(3)
                etapa_1.write(
                    "**Reconheceu firma:** "
                    f"{'Sim' if ficha.get('transferencia_reconheceu_firma') else 'Não'}"
                )
                etapa_2.write(
                    "**Gravame:** "
                    f"{'Sim' if ficha.get('transferencia_gravame') else 'Não'}"
                )
                etapa_3.write(
                    "**Documento pronto:** "
                    f"{'Sim' if ficha.get('transferencia_documento_pronto') else 'Não'}"
                )


def pagina_leads(usuario: Dict[str, Any]) -> None:
    st.title("Painel de Controle")


    # ------------------------------------------------------------------
    # Transferência em massa: admin, gerente e marketing
    # ------------------------------------------------------------------
    if usuario_pode_transferir_leads():
        with st.expander("🔀 Transferir leads entre vendedores", expanded=False):
            df_vend = obter_vendedores()
            if df_vend.empty:
                st.warning("Nenhum vendedor ativo.")
            else:
                mapa_vend = dict(zip(df_vend["id"], df_vend["nome"]))
                ids_vend = df_vend["id"].tolist()
                origem = st.selectbox(
                    "Vendedor de origem",
                    options=ids_vend,
                    format_func=lambda i: mapa_vend.get(i, str(i)),
                    key="transf_massa_origem",
                )
                modo = st.radio(
                    "Destino",
                    ["vendedor_especifico", "aleatorio", "aleatorio_loja"],
                    format_func=lambda v: {
                        "vendedor_especifico": "Vendedor específico (todos os leads → 1 pessoa)",
                        "aleatorio": "Dividir aleatoriamente entre todos os vendedores",
                        "aleatorio_loja": "Dividir aleatoriamente entre vendedores de uma loja",
                    }[v],
                    horizontal=True,
                    key="transf_massa_modo",
                )
                st.caption(
                    "Nos modos aleatórios, **cada lead** vai para um vendedor "
                    "sorteado (os leads são repartidos, não todos para um só)."
                )
                destino_id = None
                loja_destino = None
                if modo == "vendedor_especifico":
                    destino_id = st.selectbox(
                        "Vendedor de destino",
                        options=[i for i in ids_vend if i != origem],
                        format_func=lambda i: mapa_vend.get(i, str(i)),
                        key="transf_massa_destino",
                    )
                elif modo == "aleatorio_loja":
                    loja_destino = st.selectbox(
                        "Loja de destino",
                        options=list(LOJAS_DISPONIVEIS),
                        key="transf_massa_loja",
                    )

                # Preview de quantos leads seriam movidos
                try:
                    with engine.connect() as conn:
                        qtd = conn.execute(
                            text(
                                """
                                SELECT COUNT(*)
                                FROM public.leads
                                WHERE vendedor_id = :origem
                                """
                            ),
                            {"origem": origem},
                        ).scalar() or 0
                    st.caption(f"Leads do vendedor de origem: **{qtd}**")
                except Exception:
                    qtd = 0

                if st.button(
                    "Executar transferência",
                    type="primary",
                    key="btn_transf_massa",
                    use_container_width=True,
                ):
                    try:
                        with engine.begin() as conn:
                            leads = conn.execute(
                                text(
                                    """
                                    SELECT id
                                    FROM public.leads
                                    WHERE vendedor_id = :origem
                                    """
                                ),
                                {"origem": origem},
                            ).fetchall()
                            if not leads:
                                st.warning("Nenhum lead para transferir.")
                            else:
                                import random as _random

                                if modo == "vendedor_especifico":
                                    destinos = [destino_id] * len(leads)
                                elif modo == "aleatorio_loja":
                                    candidatos = df_vend[
                                        df_vend.get("loja", "381")
                                        .astype(str)
                                        .str.upper()
                                        == str(loja_destino).upper()
                                    ]["id"].tolist()
                                    if not candidatos:
                                        # fallback: todos se a coluna loja não filtrar
                                        candidatos = [
                                            i for i in ids_vend if i != origem
                                        ]
                                    if not candidatos:
                                        st.error("Nenhum vendedor na loja escolhida.")
                                        destinos = []
                                    else:
                                        destinos = [
                                            _random.choice(candidatos)
                                            for _ in leads
                                        ]
                                else:
                                    candidatos = [
                                        i for i in ids_vend if i != origem
                                    ]
                                    destinos = [
                                        _random.choice(candidatos)
                                        for _ in leads
                                    ]

                                movidos = 0
                                for (lead_id,), dest in zip(leads, destinos):
                                    if dest is None:
                                        continue
                                    nome_origem = mapa_vend.get(origem, str(origem))
                                    nome_dest = mapa_vend.get(dest, str(dest))
                                    conn.execute(
                                        text(
                                            """
                                            UPDATE public.leads
                                            SET vendedor_id = :destino,
                                                updated_at = NOW()
                                            WHERE id = :lead_id
                                            """
                                        ),
                                        {"destino": dest, "lead_id": lead_id},
                                    )
                                    conn.execute(
                                        text(
                                            """
                                            INSERT INTO public.lead_transferencias (
                                                lead_id,
                                                vendedor_origem_id,
                                                vendedor_origem_nome,
                                                vendedor_destino_id,
                                                vendedor_destino_nome,
                                                transferido_por_id,
                                                transferido_por_nome
                                            )
                                            VALUES (
                                                :lead_id,
                                                :origem_id,
                                                :origem_nome,
                                                :destino_id,
                                                :destino_nome,
                                                :por_id,
                                                :por_nome
                                            )
                                            """
                                        ),
                                        {
                                            "lead_id": lead_id,
                                            "origem_id": origem,
                                            "origem_nome": nome_origem,
                                            "destino_id": dest,
                                            "destino_nome": nome_dest,
                                            "por_id": usuario["id"],
                                            "por_nome": usuario.get("nome") or "",
                                        },
                                    )
                                    # Notifica o vendedor que RECEBEU o lead
                                    dest_user = conn.execute(
                                        text(
                                            """
                                            SELECT id FROM public.usuarios
                                            WHERE vendedor_id = :vid
                                              AND COALESCE(ativo, TRUE) = TRUE
                                            ORDER BY id LIMIT 1
                                            """
                                        ),
                                        {"vid": dest},
                                    ).mappings().first()
                                    if dest_user:
                                        conn.execute(
                                            text(
                                                """
                                                INSERT INTO public.notificacoes (
                                                    usuario_id, tipo, titulo, mensagem
                                                ) VALUES (
                                                    :uid, 'transferencia_lead',
                                                    :titulo, :mensagem
                                                )
                                                """
                                            ),
                                            {
                                                "uid": dest_user["id"],
                                                "titulo": "Lead transferido para você",
                                                "mensagem": (
                                                    f"Você recebeu um lead "
                                                    f"(origem: {nome_origem})."
                                                ),
                                            },
                                        )
                                    movidos += 1
                                st.success(
                                    f"{movidos} lead(s) transferidos por "
                                    f"**{usuario.get('nome')}** "
                                    f"(de origem #{origem}). "
                                    "Cada transferência ficou registrada no histórico."
                                )
                                st.cache_data.clear()
                                st.rerun()
                    except Exception as erro:
                        st.error(f"Erro na transferência em massa: {erro}")

    if usuario_tem("create_lead"):
        if st.button(
            "➕ Adicionar lead",
            key="btn_adicionar_lead_painel",
            type="primary",
            use_container_width=False,
        ):
            st.session_state["abrir_formulario"] = True
            st.rerun()

    filtros = [
        "todos",
        "responderam",
        "nao_responderam",
        "fichas",
        "aprovados",
        "negados",
        "vendidos",
    ]
    filtro_atual = st.session_state["filtro_categoria"]

    filtro = st.radio(
        "Filtro",
        filtros,
        index=filtros.index(filtro_atual)
        if filtro_atual in filtros
        else 0,
        horizontal=True,
        format_func=lambda valor: {
            "todos": "Todos",
            "responderam": "Responderam",
            "nao_responderam": "Não responderam",
            "fichas": "Fichas",
            "aprovados": "Aprovados",
            "negados": "Negados",
            "vendidos": "Vendidos",
        }[valor],
    )
    st.session_state["filtro_categoria"] = filtro

    col_filtro_1, col_filtro_2 = st.columns(2)
    with col_filtro_1:
        # Padrão: este mês. A contagem de leads/métricas usa o mesmo intervalo.
        periodo_opcoes = [
            "mes_atual",
            "mes_anterior",
            "personalizado",
            "todos",
        ]
        if "leads_periodo" not in st.session_state:
            st.session_state["leads_periodo"] = "mes_atual"
        periodo = st.selectbox(
            "Período da data do lead",
            periodo_opcoes,
            index=periodo_opcoes.index(
                st.session_state.get("leads_periodo", "mes_atual")
            )
            if st.session_state.get("leads_periodo", "mes_atual") in periodo_opcoes
            else 0,
            format_func=lambda valor: {
                "todos": "Todas as datas",
                "mes_atual": "Este mês",
                "mes_anterior": "Mês anterior",
                "personalizado": "Escolher período",
            }[valor],
            key="leads_periodo",
        )

    data_inicio = None
    data_fim = None
    hoje = date.today()
    primeiro_mes_atual = hoje.replace(day=1)
    if periodo == "mes_atual":
        data_inicio = primeiro_mes_atual
        if primeiro_mes_atual.month == 12:
            data_fim = primeiro_mes_atual.replace(
                year=primeiro_mes_atual.year + 1,
                month=1,
            ) - timedelta(days=1)
        else:
            data_fim = primeiro_mes_atual.replace(
                month=primeiro_mes_atual.month + 1
            ) - timedelta(days=1)
    elif periodo == "mes_anterior":
        data_fim = primeiro_mes_atual - timedelta(days=1)
        data_inicio = data_fim.replace(day=1)
    elif periodo == "personalizado":
        with col_filtro_2:
            datas = st.date_input(
                "Data inicial e final",
                value=(primeiro_mes_atual, hoje),
            )
        if isinstance(datas, (tuple, list)) and len(datas) == 2:
            data_inicio, data_fim = datas
        else:
            st.info("Escolha a data inicial e a data final.")

    try:
        df_vendedores = obter_vendedores()
    except Exception as erro:
        st.error(f"Erro ao carregar vendedores: {erro}")
        return

    vendedor_filtro = None
    if usuario["tipo"] != "vendedor" and not df_vendedores.empty:
        ids_vendedores = [None] + df_vendedores["id"].tolist()
        nomes_vendedores = {None: "Todos os vendedores"}
        nomes_vendedores.update(
            dict(zip(df_vendedores["id"], df_vendedores["nome"]))
        )
        filtro_salvo = st.session_state.get("filtro_vendedor_id")
        if filtro_salvo not in ids_vendedores:
            filtro_salvo = None
        vendedor_filtro = st.selectbox(
            "Vendedor",
            options=ids_vendedores,
            index=ids_vendedores.index(filtro_salvo),
            format_func=lambda valor: nomes_vendedores[valor],
        )
        st.session_state["filtro_vendedor_id"] = vendedor_filtro

    metricas = obter_metricas(
        usuario,
        vendedor_filtro=vendedor_filtro,
        data_inicio=data_inicio,
        data_fim=data_fim,
    )
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total de leads", metricas["total_leads"])
    c2.metric("Responderam", metricas["total_responderam"])
    c3.metric("Fichas geradas", metricas["total_fichas"])
    c4.metric("Aprovados", metricas["total_aprovados"])
    c5.metric("Vendidos", metricas["total_vendidos"])

    if st.session_state.get("abrir_formulario"):
        mostrar_formulario_novo_lead(
            usuario,
            obter_vendedores(),
        )

    st.markdown("---")

    with st.form("form_busca_leads"):
        busca_digitada = st.text_input(
            "Buscar lead",
            placeholder="Nome, CPF, telefone ou observação",
            key="busca_lead_campo",
        )
        pesquisar_leads = st.form_submit_button(
            "Buscar",
            use_container_width=True,
        )
    if pesquisar_leads:
        st.session_state["busca_lead_aplicada"] = busca_digitada
    busca = st.session_state.get("busca_lead_aplicada", "")

    filtro_chave = (
        usuario["id"],
        filtro,
        busca.strip(),
        vendedor_filtro,
        data_inicio,
        data_fim,
    )
    if st.session_state.get("leads_filtro_chave") != filtro_chave:
        st.session_state["leads_filtro_chave"] = filtro_chave
        st.session_state["leads_limite"] = 24

    limite_leads = st.session_state.get("leads_limite", 24)
    try:
        df = buscar_leads(
            usuario,
            filtro,
            busca,
            vendedor_filtro=vendedor_filtro,
            data_inicio=data_inicio,
            data_fim=data_fim,
            limite=limite_leads,
        )
    except Exception as erro:
        st.error(f"Erro ao carregar leads: {erro}")
        return

    st.subheader("Leads cadastrados")

    if df.empty:
        st.info("Nenhum lead encontrado para este perfil e filtro.")
        return

    total_leads = int(df["total_registros"].iloc[0] or len(df))
    st.caption(
        f"Exibindo {len(df)} de {total_leads} leads. "
        "Use a busca e os filtros para encontrar um registro mais rápido."
    )

    colunas = st.columns(3)
    for indice, (_, row) in enumerate(df.iterrows()):
        with colunas[indice % 3]:
            mostrar_card_lead(row, usuario, df_vendedores)

    if len(df) < total_leads and limite_leads < 200:
        if st.button(
            "Carregar mais 24 leads",
            key="carregar_mais_leads",
            use_container_width=True,
        ):
            st.session_state["leads_limite"] = min(
                limite_leads + 24,
                200,
            )
            st.rerun()


def pagina_vendedores(usuario: Dict[str, Any]) -> None:
    """
    Equipe de vendedores em cards (mesmo estilo visual dos leads).
    - admin: vê todas as lojas
    - gerente: vê ranking geral, mas leads operacionais já estão filtrados por loja
    """
    if not usuario_tem("view_team"):
        st.error("Você não tem permissão para ver a equipe.")
        return

    st.title("Equipe de Vendedores")
    st.caption(
        "Ranking: lead = 100 pts · ficha = 50 · aprovação = 150 · venda = 300. "
        "Admin vê todas as lojas; gerente opera na sua loja."
    )

    query = text(
        """
        SELECT
            v.id,
            v.nome,
            COALESCE(v.loja, '381') AS loja,
            COUNT(l.id) AS total_leads,
            COUNT(l.id) FILTER (
                WHERE l.gerou_ficha = TRUE
            ) AS total_fichas,
            COUNT(l.id) FILTER (
                WHERE l.aprovou_credito = TRUE
            ) AS total_aprovados,
            COUNT(l.id) FILTER (
                WHERE l.venda_concluida = TRUE OR l.vendeu = TRUE
            ) AS total_vendas,
            SUM(
                CASE WHEN l.id IS NOT NULL THEN 100 ELSE 0 END
                + CASE
                    WHEN COALESCE(l.gerou_ficha, FALSE) = TRUE
                    THEN 50 ELSE 0
                  END
                + CASE
                    WHEN COALESCE(l.aprovou_credito, FALSE) = TRUE
                    THEN 150 ELSE 0
                  END
                + CASE
                    WHEN COALESCE(l.venda_concluida, FALSE) = TRUE
                      OR COALESCE(l.vendeu, FALSE) = TRUE
                    THEN 300 ELSE 0
                  END
            ) AS pontos
        FROM public.vendedores v
        LEFT JOIN public.leads l
            ON l.vendedor_id = v.id
        WHERE COALESCE(v.ativo, TRUE) = TRUE
        GROUP BY v.id, v.nome, v.loja
        ORDER BY pontos DESC, total_vendas DESC, total_aprovados DESC, v.nome
        """
    )

    try:
        with engine.connect() as conn:
            df = pd.read_sql_query(query, conn)
    except Exception as erro:
        # fallback sem coluna loja
        try:
            with engine.connect() as conn:
                df = pd.read_sql_query(
                    text(
                        """
                        SELECT
                            v.id,
                            v.nome,
                            COUNT(l.id) AS total_leads,
                            COUNT(l.id) FILTER (WHERE l.gerou_ficha = TRUE) AS total_fichas,
                            COUNT(l.id) FILTER (WHERE l.aprovou_credito = TRUE) AS total_aprovados,
                            COUNT(l.id) FILTER (
                                WHERE l.venda_concluida = TRUE OR l.vendeu = TRUE
                            ) AS total_vendas,
                            0 AS pontos
                        FROM public.vendedores v
                        LEFT JOIN public.leads l ON l.vendedor_id = v.id
                        WHERE COALESCE(v.ativo, TRUE) = TRUE
                        GROUP BY v.id, v.nome
                        ORDER BY v.nome
                        """
                    ),
                    conn,
                )
            df["loja"] = "381"
            df["pontos"] = (
                df["total_leads"] * 100
                + df["total_fichas"] * 50
                + df["total_aprovados"] * 150
                + df["total_vendas"] * 300
            )
        except Exception as erro2:
            st.error(f"Erro ao carregar equipe: {erro2}")
            return

    if df.empty:
        st.info("Nenhum vendedor encontrado.")
        return

    # Filtro visual por loja (admin vê seletor; gerente vê a sua em destaque)
    lojas = sorted({str(x).upper() for x in df["loja"].dropna().tolist()})
    if usuario_e_admin() and len(lojas) > 1:
        loja_filtro = st.selectbox(
            "Filtrar por loja",
            options=["TODAS"] + lojas,
            index=0,
        )
        if loja_filtro != "TODAS":
            df = df[df["loja"].astype(str).str.upper() == loja_filtro]

    # Cards em grade (3 por linha)
    cols_por_linha = 3
    rows = list(df.iterrows())
    for i in range(0, len(rows), cols_por_linha):
        cols = st.columns(cols_por_linha)
        for j, col in enumerate(cols):
            if i + j >= len(rows):
                break
            _, row = rows[i + j]
            with col:
                st.markdown(
                    f"""
                    <div class="vendedor-card">
                      <h4>{row.get('nome') or '-'}</h4>
                      <div class="muted">Loja {row.get('loja') or '-'} · {int(row.get('pontos') or 0)} pts</div>
                      <div style="margin-top:10px;display:flex;gap:12px;flex-wrap:wrap;">
                        <span>Leads <b>{int(row.get('total_leads') or 0)}</b></span>
                        <span>Fichas <b>{int(row.get('total_fichas') or 0)}</b></span>
                        <span>Aprov. <b>{int(row.get('total_aprovados') or 0)}</b></span>
                        <span>Vendas <b>{int(row.get('total_vendas') or 0)}</b></span>
                      </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )


def pagina_fichas(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("view_credit_fichas"):
        st.error("Você não tem permissão para acessar fichas de crédito.")
        return

    st.title("Fichas de Crédito")
    if usuario["tipo"] == "elfen_ai":
        st.caption(
            "Dados cadastrais, status da ficha e propostas bancárias."
        )
    elif usuario["tipo"] in {"financeiro", "gerente"}:
        st.caption(
            "Análise por banco, compras, valores recebidos e boletos."
        )
    else:
        st.caption("Dados cadastrais, status da ficha e propostas bancárias.")

    notificacoes = contar_notificacoes_nao_lidas(usuario["id"])
    if notificacoes:
        st.warning(
            f"Você tem {notificacoes} atualização(ões) de ficha não lida(s)."
        )
        marcar_notificacoes_como_lidas(usuario["id"])

    # ---- Filtro de período (mesmo padrão do painel de leads) ----
    # Padrão: este mês. Contagens e métricas acompanham o intervalo.
    col_p1, col_p2 = st.columns(2)
    with col_p1:
        periodo_opcoes_f = [
            "mes_atual",
            "mes_anterior",
            "personalizado",
            "todos",
        ]
        if "fichas_periodo" not in st.session_state:
            st.session_state["fichas_periodo"] = "mes_atual"
        periodo_f = st.selectbox(
            "Período das fichas",
            periodo_opcoes_f,
            index=periodo_opcoes_f.index(
                st.session_state.get("fichas_periodo", "mes_atual")
            )
            if st.session_state.get("fichas_periodo", "mes_atual") in periodo_opcoes_f
            else 0,
            format_func=lambda valor: {
                "todos": "Todas as datas",
                "mes_atual": "Este mês",
                "mes_anterior": "Mês anterior",
                "personalizado": "Escolher período",
            }[valor],
            key="fichas_periodo",
        )
    data_inicio_f = None
    data_fim_f = None
    hoje_f = date.today()
    primeiro_f = hoje_f.replace(day=1)
    if periodo_f == "mes_atual":
        data_inicio_f = primeiro_f
        if primeiro_f.month == 12:
            data_fim_f = primeiro_f.replace(year=primeiro_f.year + 1, month=1) - timedelta(days=1)
        else:
            data_fim_f = primeiro_f.replace(month=primeiro_f.month + 1) - timedelta(days=1)
    elif periodo_f == "mes_anterior":
        data_fim_f = primeiro_f - timedelta(days=1)
        data_inicio_f = data_fim_f.replace(day=1)
    elif periodo_f == "personalizado":
        with col_p2:
            datas_f = st.date_input(
                "Data inicial e final (fichas)",
                value=(primeiro_f, hoje_f),
                key="fichas_periodo_datas",
            )
        if isinstance(datas_f, (tuple, list)) and len(datas_f) == 2:
            data_inicio_f, data_fim_f = datas_f

    # Guarda no session_state para as queries de listagem usarem
    st.session_state["fichas_data_inicio"] = data_inicio_f
    st.session_state["fichas_data_fim"] = data_fim_f

    # Métricas $ completas: admin e gerente.
    # Marketing: só lista de clientes pendentes (sem totais/bancos).
    if usuario_e_gestor():
        try:
            por_banco, geral = obter_metricas_credito(
                st.session_state.get("fichas_data_inicio"),
                st.session_state.get("fichas_data_fim"),
            )
            st.subheader("Métricas financeiras")
            metricas = st.columns(6)
            metricas[0].metric(
                "Fichas",
                int(geral.get("total_fichas") or 0),
            )
            metricas[1].metric(
                "Aprovadas",
                int(geral.get("fichas_aprovadas") or 0),
            )
            metricas[2].metric(
                "Negadas",
                int(geral.get("fichas_negadas") or 0),
            )
            metricas[3].metric(
                "Pendentes",
                int(geral.get("fichas_pendentes") or 0),
            )
            metricas[4].metric(
                "Compras",
                int(geral.get("total_compras") or 0),
            )
            metricas[5].metric(
                "Clientes com pendência",
                int(geral.get("clientes_com_valor_pendente") or 0),
            )

            if not por_banco.empty:
                st.markdown(
                    "#### Aprovação por banco — clique para abrir as fichas"
                )
                colunas_bancos = st.columns(4)
                for indice, (_, linha_banco) in enumerate(
                    por_banco.iterrows()
                ):
                    banco_nome = linha_banco["banco"]
                    with colunas_bancos[indice % 4]:
                        if st.button(
                            (
                                f"{banco_nome} • "
                                f"{int(linha_banco['fichas_analisadas'])} fichas • "
                                f"{int(linha_banco['total_aprovados'])} aprovadas"
                            ),
                            key=f"filtro_banco_{banco_nome}",
                            use_container_width=True,
                            type=(
                                "primary"
                                if st.session_state.get("banco_filtro")
                                == banco_nome
                                else "secondary"
                            ),
                        ):
                            st.session_state["banco_filtro"] = banco_nome
                            st.rerun()

                if st.session_state.get("banco_filtro"):
                    banco_selecionado = st.session_state["banco_filtro"]
                    if st.button(
                        "Mostrar todos os bancos",
                        key="limpar_filtro_banco",
                    ):
                        st.session_state["banco_filtro"] = None
                        st.rerun()
                    st.info(
                        f"Mostrando fichas do banco: {banco_selecionado}"
                    )

                # Sem "fichas distintas" nem "pendentes" por banco
                # (pendentes globais já estão no topo das métricas)
                df_bancos = por_banco[
                    [c for c in (
                        "banco", "total_aprovados", "total_negados", "taxa_aprovacao"
                    ) if c in por_banco.columns]
                ].rename(columns={
                    "total_aprovados": "aprovadas",
                    "total_negados": "negadas",
                    "taxa_aprovacao": "taxa (%)",
                })
                st.dataframe(
                    df_bancos,
                    use_container_width=True,
                    hide_index=True,
                )

            (
                c_fin_1,
                c_fin_2,
                c_fin_3,
                c_fin_4,
                c_fin_5,
                c_fin_6,
            ) = st.columns(6)
            c_fin_1.metric(
                "Valor bruto das vendas",
                f"R$ {numero_seguro(geral.get('valor_vendas_bruto')):,.2f}",
            )
            c_fin_2.metric(
                "Valor liberado",
                f"R$ {numero_seguro(geral.get('valor_liberado')):,.2f}",
            )
            c_fin_3.metric(
                "Entrada já paga",
                f"R$ {numero_seguro(geral.get('entrada_paga')):,.2f}",
            )
            c_fin_4.metric(
                "Total em boletos",
                f"R$ {numero_seguro(geral.get('valor_boletos')):,.2f}",
            )
            c_fin_5.metric(
                "Valor pendente",
                f"R$ {numero_seguro(geral.get('valor_pendente')):,.2f}",
            )
            c_fin_6.metric(
                "Clientes com boleto",
                int(geral.get("total_boletos") or 0),
            )

            st.caption(
                "Valor bruto das vendas = valor liberado pelo banco + "
                "entrada já paga pelo cliente. Isso representa venda bruta, "
                "não lucro líquido."
            )

            try:
                pendentes = obter_fichas_com_valor_pendente()
                with st.expander(
                    "💰 Valor pendente — clientes com boleto",
                    expanded=True,
                ):
                    if pendentes.empty:
                        st.info("Nenhum cliente com valor pendente.")
                    else:
                        st.dataframe(
                            pendentes.assign(
                                data_nascimento=pendentes[
                                    "data_nascimento"
                                ].map(formatar_data_br),
                                data_compra=pendentes[
                                    "data_compra"
                                ].map(formatar_data_br),
                            ).rename(
                                columns={
                                    "nome_completo": "cliente",
                                    "telefone": "telefone",
                                    "data_nascimento": "nascimento",
                                    "habilitado": "habilitado",
                                    "produto_interesse": "carro",
                                    "vendedor_nome": "vendedor",
                                    "data_compra": "data compra",
                                    "valor_veiculo": "valor veículo",
                                    "banco_contratado": "banco",
                                    "valor_liberado": "liberado",
                                    "entrada_total": "entrada total",
                                    "entrada_paga": "entrada paga",
                                    "valor_pendente": "valor pendente",
                                    "boleto_valor": "parcela boleto",
                                    "boleto_meses": "meses",
                                    "boleto_total": "total boletos",
                                }
                            ),
                            use_container_width=True,
                            hide_index=True,
                        )
            except Exception as erro:
                st.warning(f"Não foi possível carregar pendências: {erro}")
        except Exception as erro:
            st.warning(
                "As métricas ainda não estão disponíveis. "
                f"Detalhe: {erro}"
            )

        st.markdown("---")

    elif usuario_e_marketing() or usuario_tem("view_pending_clients"):
        # Marketing: vê clientes pendentes, sem totais financeiros / bancos
        st.subheader("Clientes com valor pendente")
        try:
            pendentes = obter_fichas_com_valor_pendente()
            if pendentes.empty:
                st.info("Nenhum cliente com valor pendente.")
            else:
                st.dataframe(
                    pendentes.assign(
                        data_nascimento=pendentes["data_nascimento"].map(
                            formatar_data_br
                        ),
                        data_compra=pendentes["data_compra"].map(
                            formatar_data_br
                        ),
                    ),
                    use_container_width=True,
                    hide_index=True,
                )
        except Exception as erro:
            st.warning(f"Não foi possível carregar pendências: {erro}")
        st.markdown("---")

    status_opcoes = [
        "todas",
        "pendente",
        "aprovada",
        "negada",
    ]
    status = st.radio(
        "Filtrar fichas",
        status_opcoes,
        horizontal=True,
        format_func=lambda valor: {
            "todas": "Todas",
            "pendente": "Pendentes",
            "aprovada": "Aprovadas",
            "negada": "Negadas",
        }[valor],
    )
    with st.form("form_busca_fichas"):
        busca_digitada = st.text_input(
            "Buscar ficha",
            placeholder="Nome, CPF, telefone ou vendedor",
            key="busca_ficha_campo",
        )
        pesquisar_fichas = st.form_submit_button(
            "Buscar",
            use_container_width=True,
        )
    if pesquisar_fichas:
        st.session_state["busca_ficha_aplicada"] = busca_digitada
    busca = st.session_state.get("busca_ficha_aplicada", "")

    filtro_fichas_chave = (
        usuario["id"],
        status,
        busca.strip(),
        st.session_state.get("banco_filtro"),
    )
    if st.session_state.get("fichas_filtro_chave") != filtro_fichas_chave:
        st.session_state["fichas_filtro_chave"] = filtro_fichas_chave
        st.session_state["fichas_limite"] = 24

    try:
        fichas = obter_fichas_credito(
            usuario,
            status,
            busca,
            st.session_state.get("banco_filtro"),
            limite=st.session_state.get("fichas_limite", 24),
            data_inicio=st.session_state.get("fichas_data_inicio"),
            data_fim=st.session_state.get("fichas_data_fim"),
        )
    except Exception as erro:
        st.error(
            "Não foi possível carregar as fichas. "
            "Execute schema_fichas_credito.sql no Supabase. "
            f"Detalhe: {erro}"
        )
        return

    if fichas.empty:
        st.info("Nenhuma ficha encontrada.")
        return

    total_fichas = int(
        fichas["total_registros"].iloc[0] or len(fichas)
    )
    st.caption(
        f"Exibindo {len(fichas)} de {total_fichas} fichas. "
        "Use o status, banco e busca para reduzir a lista."
    )

    ids_fichas = tuple(int(valor) for valor in fichas["id"].tolist())
    contagens_anexos = obter_contagem_anexos_fichas(ids_fichas)

    grupo_anterior = None
    for _, ficha in fichas.iterrows():
        esta_na_loja = ficha.get("cliente_na_loja")
        esta_na_loja = (
            bool(esta_na_loja) if pd.notna(esta_na_loja) else False
        )
        if ficha.get("status_geral") != "pendente":
            grupo = "Analisadas — aprovadas ou negadas"
        elif esta_na_loja:
            grupo = "Pendentes — cliente na loja 🏪"
        else:
            grupo = "Pendentes — cliente fora da loja"

        if grupo != grupo_anterior:
            st.subheader(grupo)
            grupo_anterior = grupo

        status_label = {
            "pendente": "⏳ Pendente",
            "aprovada": "✅ Aprovada",
            "negada": "❌ Negada",
        }.get(ficha["status_geral"], ficha["status_geral"])

        nome_cliente = (
            ficha.get("nome_completo")
            or ficha.get("nome_lead")
            or "Cliente sem nome"
        )
        badge_loja = "  🏪 Na loja" if esta_na_loja else ""

        with st.expander(
            f"{status_label}{badge_loja}  |  {nome_cliente}",
            expanded=(
                st.session_state.get("ficha_detalhe_id")
                == int(ficha["id"])
            ),
        ):
            ficha_selecionada = (
                st.session_state.get("ficha_detalhe_id")
                == int(ficha["id"])
            )
            if ficha_selecionada:
                if st.button(
                    "Fechar ficha",
                    key=f"fechar_ficha_{ficha['id']}",
                ):
                    st.session_state.pop("ficha_detalhe_id", None)
                    st.rerun()
            else:
                st.caption(
                    f"Vendedor: {ficha.get('vendedor_nome') or '-'} · "
                    f"Atualizada em: "
                    f"{formatar_data_br(ficha.get('updated_at'), True)}"
                )
                if st.button(
                    "Abrir ficha completa",
                    key=f"abrir_ficha_{ficha['id']}",
                    use_container_width=True,
                ):
                    st.session_state["ficha_detalhe_id"] = int(
                        ficha["id"]
                    )
                    st.rerun()
                continue

            col_cliente_1, col_cliente_2, col_cliente_3 = st.columns(3)
            col_cliente_1.write(f"**Vendedor:** {ficha.get('vendedor_nome') or '-'}")
            col_cliente_2.write(f"**CPF:** {ficha.get('cpf') or '-'}")
            col_cliente_3.write(
                f"**Carro selecionado:** "
                f"{ficha.get('carro_selecionado') or ficha.get('produto_interesse') or '-'}"
            )

            col_cliente_4, col_cliente_5, col_cliente_6 = st.columns(3)
            col_cliente_4.write(
                f"**Data de nascimento:** "
                f"{formatar_data_br(ficha.get('data_nascimento'))}"
            )
            col_cliente_5.write(
                f"**Habilitado:** "
                f"{'Sim' if ficha.get('habilitado') else 'Não'}"
            )
            if usuario["tipo"] in {"financeiro", "gerente"}:
                col_cliente_6.write(
                    f"**Entrada solicitada:** "
                    f"R$ {numero_seguro(ficha.get('valor_entrada')):,.2f}"
                )

            col_veiculo_1, col_veiculo_2, col_veiculo_3 = st.columns(3)
            col_veiculo_1.write(
                f"**Ano do carro:** {ficha.get('ano_carro') or '-'}"
            )
            col_veiculo_2.write(
                f"**Placa:** {ficha.get('placa_carro') or '-'}"
            )
            col_veiculo_3.write(
                f"**Valor do carro:** "
                f"R$ {numero_seguro(ficha.get('valor_carro')):,.2f}"
            )

            def texto_cadastro(campo: str) -> str:
                valor = ficha.get(campo)
                if valor is None or pd.isna(valor) or not str(valor).strip():
                    return "-"
                return str(valor).strip()

            st.markdown("#### Contato e dados pessoais")
            col_contato_1, col_contato_2, col_contato_3 = st.columns(3)
            col_contato_1.write(
                f"**Telefone:** {texto_cadastro('telefone')}"
            )
            col_contato_2.write(f"**E-mail:** {texto_cadastro('email')}")
            col_contato_3.write(f"**RG:** {texto_cadastro('rg')}")
            col_familia_1, col_familia_2, col_familia_3 = st.columns(3)
            col_familia_1.write(
                f"**Nome do pai:** {texto_cadastro('nome_pai')}"
            )
            col_familia_2.write(
                f"**Nome da mãe:** {texto_cadastro('nome_mae')}"
            )
            col_familia_3.write(
                f"**Órgão expedidor:** "
                f"{texto_cadastro('orgao_expeditor')}"
            )
            st.write(
                f"**Expedição do RG:** "
                f"{texto_cadastro('data_expedicao')}"
            )

            st.markdown("#### Endereço residencial")
            st.write(
                f"**Endereço:** {texto_cadastro('endereco')} · "
                f"**Bairro:** {texto_cadastro('bairro')} · "
                f"**Cidade/UF:** {texto_cadastro('cidade')}/"
                f"{texto_cadastro('estado')} · "
                f"**CEP:** {texto_cadastro('cep')}"
            )

            st.markdown("#### Trabalho e dados da empresa")
            col_empresa_1, col_empresa_2, col_empresa_3 = st.columns(3)
            col_empresa_1.write(
                f"**Empresa:** {texto_cadastro('empresa')}"
            )
            col_empresa_2.write(f"**CNPJ:** {texto_cadastro('cnpj')}")
            col_empresa_3.write(
                f"**Banco correntista:** "
                f"{texto_cadastro('banco_correntista')}"
            )
            st.write(
                f"**Endereço da empresa:** "
                f"{texto_cadastro('endereco_empresa')} · "
                f"**Bairro:** {texto_cadastro('bairro_empresa')} · "
                f"**Cidade/UF:** {texto_cadastro('cidade_empresa')}/"
                f"{texto_cadastro('estado_empresa')} · "
                f"**CEP:** {texto_cadastro('cep_empresa')}"
            )
            col_trabalho_1, col_trabalho_2 = st.columns(2)
            col_trabalho_1.write(
                f"**Tempo de trabalho:** "
                f"{texto_cadastro('tempo_carreira')}"
            )
            col_trabalho_2.write(
                f"**Salário mensal:** "
                f"R$ {numero_seguro(ficha.get('salario')):,.2f}"
            )

            pode_editar_dados = (
                usuario["tipo"] in {"gerente", "elfen_ai"}
                or (
                    usuario_tem("edit_own_credit_data")
                    and ficha.get("vendedor_id")
                    == usuario.get("vendedor_id")
                )
            )

            if pode_editar_dados:
                with st.expander("Editar dados da ficha"):
                    def valor_edicao(campo: str) -> str:
                        valor = ficha.get(campo)
                        if valor is None or pd.isna(valor):
                            return ""
                        return str(valor)

                    with st.form(f"form_dados_ficha_{ficha['id']}"):
                        d1, d2 = st.columns(2)
                        novo_nome_completo = d1.text_input(
                            "Nome completo",
                            value=str(ficha.get("nome_completo") or ""),
                        )
                        novo_cpf = d2.text_input(
                            "CPF",
                            value=str(ficha.get("cpf") or ""),
                        )
                        d3, d4 = st.columns(2)
                        nova_data_nascimento = d3.text_input(
                            "Data de nascimento (DD/MM/AAAA)",
                            value=(
                                data_para_texto_br(
                                    ficha.get("data_nascimento")
                                )
                                or ""
                            ),
                            placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                            help=(
                                "Sem limite mínimo de ano. Digite a data "
                                "completa."
                            ),
                        )
                        novo_carro = d4.text_input(
                            "Carro selecionado",
                            value=str(
                                ficha.get("carro_selecionado")
                                or ficha.get("produto_interesse")
                                or ""
                            ),
                        )

                        st.markdown("#### Dados pessoais e endereço")
                        e1, e2 = st.columns(2)
                        with e1:
                            novo_nome_pai = st.text_input(
                                "Nome do pai",
                                value=valor_edicao("nome_pai"),
                            )
                            novo_rg = st.text_input(
                                "RG",
                                value=valor_edicao("rg"),
                            )
                            novo_orgao_expeditor = st.text_input(
                                "Órgão expedidor",
                                value=valor_edicao("orgao_expeditor"),
                            )
                            novo_email = st.text_input(
                                "E-mail",
                                value=valor_edicao("email"),
                            )
                            novo_endereco = st.text_input(
                                "Endereço residencial",
                                value=valor_edicao("endereco"),
                            )
                            novo_bairro = st.text_input(
                                "Bairro residencial",
                                value=valor_edicao("bairro"),
                            )
                            nova_cidade = st.text_input(
                                "Cidade residencial",
                                value=valor_edicao("cidade"),
                            )
                            novo_estado = st.text_input(
                                "Estado residencial",
                                value=valor_edicao("estado"),
                                max_chars=2,
                            )
                            novo_cep = st.text_input(
                                "CEP residencial",
                                value=valor_edicao("cep"),
                                max_chars=9,
                            )
                        with e2:
                            novo_nome_mae = st.text_input(
                                "Nome da mãe",
                                value=valor_edicao("nome_mae"),
                            )
                            nova_data_expedicao = st.text_input(
                                "Data de expedição do RG (DD/MM/AAAA)",
                                value=(
                                    data_para_texto_br(
                                        valor_edicao("data_expedicao")
                                    )
                                    or ""
                                ),
                                placeholder="DD/MM/AAAA ou DD-MM-AAAA",
                            )
                            st.markdown(
                                "#### Dados da empresa (opcional)"
                            )
                            st.caption(
                                "Para cliente autônomo, deixe os campos "
                                "da empresa em branco."
                            )
                            nova_empresa = st.text_input(
                                "Nome da empresa",
                                value=valor_edicao("empresa"),
                            )
                            novo_cnpj = st.text_input(
                                "CNPJ",
                                value=valor_edicao("cnpj"),
                            )
                            novo_endereco_empresa = st.text_input(
                                "Endereço da empresa",
                                value=valor_edicao("endereco_empresa"),
                            )
                            novo_bairro_empresa = st.text_input(
                                "Bairro da empresa",
                                value=valor_edicao("bairro_empresa"),
                            )
                            nova_cidade_empresa = st.text_input(
                                "Cidade da empresa",
                                value=valor_edicao("cidade_empresa"),
                            )
                            novo_estado_empresa = st.text_input(
                                "Estado da empresa",
                                value=valor_edicao("estado_empresa"),
                                max_chars=2,
                            )
                            novo_cep_empresa = st.text_input(
                                "CEP da empresa",
                                value=valor_edicao("cep_empresa"),
                                max_chars=9,
                            )

                        st.markdown("#### Trabalho e banco")
                        t1, t2 = st.columns(2)
                        novo_tempo_carreira = t1.text_input(
                            "Tempo de trabalho na empresa",
                            value=valor_edicao("tempo_carreira"),
                        )
                        novo_salario = t2.number_input(
                            "Salário mensal",
                            min_value=0.0,
                            value=numero_seguro(ficha.get("salario")),
                            step=100.0,
                        )
                        novo_banco_correntista = st.text_input(
                            "Banco correntista",
                            value=valor_edicao("banco_correntista"),
                        )

                        novo_habilitado = st.checkbox(
                            "Cliente habilitado",
                            value=bool(ficha.get("habilitado")),
                        )
                        nova_entrada_ficha = None
                        if usuario["tipo"] in {"financeiro", "gerente"}:
                            nova_entrada_ficha = st.number_input(
                                "Valor de entrada",
                                min_value=0.0,
                                value=numero_seguro(
                                    ficha.get("valor_entrada")
                                ),
                                step=100.0,
                            )
                        salvar_cadastro = st.form_submit_button(
                            "Salvar dados da ficha",
                            use_container_width=True,
                        )

                    if salvar_cadastro:
                        dados_adicionais = {
                            "nome_pai": novo_nome_pai.strip() or None,
                            "nome_mae": novo_nome_mae.strip() or None,
                            "rg": novo_rg.strip() or None,
                            "data_expedicao": (
                                nova_data_expedicao.strip() or None
                            ),
                            "orgao_expeditor": (
                                novo_orgao_expeditor.strip() or None
                            ),
                            "empresa": nova_empresa.strip() or None,
                            "cnpj": novo_cnpj.strip() or None,
                            "endereco_empresa": (
                                novo_endereco_empresa.strip() or None
                            ),
                            "bairro_empresa": (
                                novo_bairro_empresa.strip() or None
                            ),
                            "cidade_empresa": (
                                nova_cidade_empresa.strip() or None
                            ),
                            "estado_empresa": (
                                novo_estado_empresa.strip() or None
                            ),
                            "cep_empresa": (
                                novo_cep_empresa.strip() or None
                            ),
                            "endereco": novo_endereco.strip() or None,
                            "bairro": novo_bairro.strip() or None,
                            "cidade": nova_cidade.strip() or None,
                            "estado": novo_estado.strip() or None,
                            "cep": novo_cep.strip() or None,
                            "email": novo_email.strip() or None,
                            "tempo_carreira": (
                                novo_tempo_carreira.strip() or None
                            ),
                            "salario": novo_salario or None,
                            "banco_correntista": (
                                novo_banco_correntista.strip() or None
                            ),
                        }
                        salvar_dados_cadastrais_ficha(
                            usuario,
                            ficha,
                            novo_nome_completo,
                            novo_cpf,
                            nova_data_nascimento,
                            novo_habilitado,
                            novo_carro,
                            nova_entrada_ficha,
                            dados_adicionais,
                        )

            mostrar_botao_anexos_ficha(
                int(ficha["id"]),
                usuario,
                f"ficha_{ficha['id']}",
                contagens_anexos.get(int(ficha["id"]), 0),
            )

            st.markdown("### Resultado nos bancos")
            try:
                bancos_todos = obter_analises_banco(int(ficha["id"]))
            except Exception as erro:
                st.error(f"Erro ao carregar bancos: {erro}")
                bancos_todos = pd.DataFrame()

            bancos = bancos_todos
            banco_filtro_atual = st.session_state.get("banco_filtro")
            if banco_filtro_atual and not bancos.empty:
                bancos = bancos[
                    bancos["banco"] == banco_filtro_atual
                ]

            if bancos.empty and not banco_filtro_atual and usuario_tem("edit_bank_results"):
                if st.button(
                    "Inicializar bancos desta ficha",
                    key=f"init_bancos_{ficha['id']}",
                    use_container_width=True,
                ):
                    try:
                        with engine.begin() as conn:
                            for banco_nome in BANCOS_CREDITO:
                                conn.execute(
                                    text(
                                        """
                                        INSERT INTO public.ficha_bancos (ficha_id, banco)
                                        VALUES (:ficha_id, :banco)
                                        ON CONFLICT (ficha_id, banco) DO NOTHING
                                        """
                                    ),
                                    {
                                        "ficha_id": int(ficha["id"]),
                                        "banco": banco_nome,
                                    },
                                )
                        st.success("Bancos inicializados.")
                        st.cache_data.clear()
                        st.rerun()
                    except Exception as erro:
                        st.error(f"Erro ao inicializar bancos: {erro}")

            if bancos.empty:
                st.warning(
                    "Esta ficha não possui análise para o banco selecionado."
                    if banco_filtro_atual
                    else "Esta ficha ainda não possui bancos cadastrados."
                )
            else:
                for _, banco in bancos.iterrows():
                    status_banco = banco.get("status") or "pendente"
                    label_banco = {
                        "pendente": "⏳",
                        "aprovado": "✅",
                        "negado": "❌",
                    }.get(status_banco, "•")

                    with st.expander(
                        f"{label_banco} {banco['banco']} · "
                        f"{status_banco.capitalize()}",
                        expanded=(
                            st.session_state.get("banco_detalhe_id")
                            == int(banco["id"])
                        ),
                    ):

                        if usuario_tem("edit_bank_results"):
                            status_lista = [
                                "pendente",
                                "aprovado",
                                "negado",
                            ]
                            indice_status = (
                                status_lista.index(status_banco)
                                if status_banco in status_lista
                                else 0
                            )

                            def numero_banco(nome_coluna: str) -> float:
                                valor = banco.get(nome_coluna)
                                return (
                                    float(valor)
                                    if pd.notna(valor)
                                    else 0.0
                                )

                            with st.form(
                                f"form_banco_{ficha['id']}_{banco['id']}"
                            ):
                                novo_status = st.selectbox(
                                    "Status",
                                    status_lista,
                                    index=indice_status,
                                    format_func=lambda valor: {
                                        "pendente": "Pendente",
                                        "aprovado": "Aprovado",
                                        "negado": "Negado",
                                    }[valor],
                                )
                                st.caption(
                                    "Os valores abaixo só são gravados "
                                    "quando o banco estiver aprovado."
                                )
                                b1, b2, b3, b4 = st.columns(4)
                                novo_valor_financiado = b1.number_input(
                                    "Valor financiado",
                                    min_value=0.0,
                                    value=numero_banco(
                                        "valor_financiado"
                                    ),
                                    step=100.0,
                                )
                                nova_entrada = b2.number_input(
                                    "Entrada",
                                    min_value=0.0,
                                    value=numero_banco("valor_entrada"),
                                    step=100.0,
                                )
                                nova_parcela_48 = b3.number_input(
                                    "Parcela em 48x",
                                    min_value=0.0,
                                    value=numero_banco("parcela_48"),
                                    step=10.0,
                                )
                                nova_parcela_60 = b4.number_input(
                                    "Parcela em 60x",
                                    min_value=0.0,
                                    value=numero_banco("parcela_60"),
                                    step=10.0,
                                )
                                nova_observacao = st.text_area(
                                    "Observação do banco",
                                    value=str(
                                        banco.get("observacao") or ""
                                    ),
                                )
                                salvar_banco = st.form_submit_button(
                                    "Salvar resultado",
                                    use_container_width=True,
                                )

                            if salvar_banco:
                                st.session_state["banco_detalhe_id"] = int(
                                    banco["id"]
                                )
                                valor_financiado_final = (
                                    novo_valor_financiado
                                    if novo_status == "aprovado"
                                    else None
                                )
                                salvar_analise_banco(
                                    usuario,
                                    ficha,
                                    int(banco["id"]),
                                    banco["banco"],
                                    novo_status,
                                    valor_financiado_final,
                                    nova_entrada,
                                    nova_parcela_48,
                                    nova_parcela_60,
                                    nova_observacao,
                                )
                        else:
                            st.write(f"**Status:** {status_banco}")
                            if status_banco == "aprovado":
                                a1, a2, a3, a4 = st.columns(4)
                                a1.metric(
                                    "Financiado",
                                    f"R$ {float(banco.get('valor_financiado') or 0):,.2f}",
                                )
                                a2.metric(
                                    "Entrada",
                                    f"R$ {float(banco.get('valor_entrada') or 0):,.2f}",
                                )
                                a3.metric(
                                    "48x",
                                    f"R$ {float(banco.get('parcela_48') or 0):,.2f}",
                                )
                                a4.metric(
                                    "60x",
                                    f"R$ {float(banco.get('parcela_60') or 0):,.2f}",
                                )
                            if banco.get("observacao"):
                                st.caption(banco["observacao"])

            pode_ver_financeiro = (
                usuario["tipo"] in {"financeiro", "gerente", "elfen_ai"}
                or usuario_tem("view_financial")
                or usuario_tem("edit_sales_boleto")
            )
            pode_financeiro = usuario_tem("edit_sales_boleto")

            if pode_ver_financeiro:
                st.markdown("### Compra e boleto")
            if pode_financeiro:
                # Checkbox FORA do form → desbloqueia os campos na hora (Streamlit)
                key_comprou = f"comprou_check_{ficha['id']}"
                if key_comprou not in st.session_state:
                    st.session_state[key_comprou] = bool(ficha.get("comprou"))
                comprou = st.checkbox(
                    "Cliente comprou?",
                    key=key_comprou,
                )
                with st.form(f"form_financeiro_ficha_{ficha['id']}"):
                    analises_aprovadas = (
                        bancos_todos[
                            bancos_todos["status"] == "aprovado"
                        ]["banco"].tolist()
                        if not bancos_todos.empty
                        else []
                    )
                    bancos_financeiro = [None] + analises_aprovadas
                    banco_atual = ficha.get("banco_contratado")
                    if pd.isna(banco_atual):
                        banco_atual = None
                    if banco_atual not in bancos_financeiro:
                        banco_atual = None
                    banco_contratado = st.selectbox(
                        "Banco contratado",
                        options=bancos_financeiro,
                        index=bancos_financeiro.index(banco_atual),
                        format_func=lambda valor: (
                            "Selecione o banco"
                            if valor is None
                            else valor
                        ),
                        disabled=not comprou,
                    )
                    f1, f2, f3 = st.columns(3)
                    data_compra = f1.date_input(
                        "Data da compra",
                        value=converter_data(ficha.get("data_compra")),
                        disabled=not comprou,
                    )
                    valor_veiculo = f2.number_input(
                        "Valor do veículo",
                        min_value=0.0,
                        value=numero_seguro(ficha.get("valor_veiculo")),
                        step=100.0,
                        disabled=not comprou,
                    )
                    valor_liberado = f3.number_input(
                        "Valor liberado pelo banco",
                        min_value=0.0,
                        value=numero_seguro(
                            ficha.get(
                                "valor_liberado",
                                ficha.get("valor_financiado"),
                            )
                        ),
                        step=100.0,
                        disabled=not comprou,
                    )
                    e1, e2 = st.columns(2)
                    entrada_total = e1.number_input(
                        "Entrada total exigida",
                        min_value=0.0,
                        value=numero_seguro(
                            ficha.get(
                                "entrada_total",
                                ficha.get("valor_entrada"),
                            )
                        ),
                        step=100.0,
                        disabled=not comprou,
                    )
                    entrada_paga = e2.number_input(
                        "Entrada já paga pelo cliente",
                        min_value=0.0,
                        value=numero_seguro(
                            ficha.get("entrada_paga")
                        ),
                        step=100.0,
                        disabled=not comprou,
                    )
                    st.caption(
                        "Valor pendente calculado: "
                        f"R$ {max(entrada_total - entrada_paga, 0):,.2f}"
                    )

                    # Financiamento contratado (separado de boleto de entrada)
                    st.caption("Financiamento no banco (parcelas do contrato)")
                    fm1, fm2 = st.columns(2)
                    opcoes_meses = [0, 24, 36, 48, 60]
                    fin_meses_atual = inteiro_seguro(ficha.get("fin_meses"), 0)
                    if fin_meses_atual not in opcoes_meses:
                        opcoes_meses = sorted(set(opcoes_meses + [fin_meses_atual]))
                    fin_meses = fm1.selectbox(
                        "Meses do financiamento",
                        options=opcoes_meses,
                        index=opcoes_meses.index(fin_meses_atual)
                        if fin_meses_atual in opcoes_meses
                        else 0,
                        format_func=lambda m: (
                            "Selecione" if m == 0 else f"{m}x"
                        ),
                        disabled=not comprou,
                        help="24x, 36x, 48x ou 60x — não é quantidade de boletos.",
                    )
                    fin_valor_parcela = fm2.number_input(
                        "Valor da parcela do financiamento R$",
                        min_value=0.0,
                        value=numero_seguro(ficha.get("fin_valor_parcela")),
                        step=50.0,
                        disabled=not comprou,
                        help="Parcela mensal do contrato no banco.",
                    )

                    gerou_boleto = st.checkbox(
                        "Gerou boleto? (entrada / complemento)",
                        value=bool(ficha.get("gerou_boleto")),
                        disabled=not comprou,
                    )
                    b1, b2 = st.columns(2)
                    boleto_valor = b1.number_input(
                        "Valor do boleto",
                        min_value=0.0,
                        value=numero_seguro(ficha.get("boleto_valor")),
                        step=10.0,
                        disabled=not gerou_boleto or not comprou,
                    )
                    boleto_meses = b2.number_input(
                        "Quantidade de meses",
                        min_value=1,
                        value=inteiro_seguro(
                            ficha.get("boleto_meses")
                        ),
                        step=1,
                        disabled=not gerou_boleto or not comprou,
                    )
                    if gerou_boleto and comprou:
                        st.caption(
                            "Total previsto em boletos: "
                            f"R$ {boleto_valor * boleto_meses:,.2f}"
                        )
                    salvar_financeiro = st.form_submit_button(
                        "Salvar compra e boleto",
                        use_container_width=True,
                    )

                if salvar_financeiro:
                    salvar_dados_financeiros_ficha(
                        usuario,
                        ficha,
                        comprou,
                        data_compra if comprou else None,
                        valor_veiculo if comprou else None,
                        banco_contratado if comprou else None,
                        valor_liberado if comprou else None,
                        entrada_total if comprou else None,
                        entrada_paga if comprou else None,
                        gerou_boleto,
                        boleto_valor if gerou_boleto else None,
                        boleto_meses if gerou_boleto else None,
                        fin_meses=fin_meses if comprou and fin_meses else None,
                        fin_valor_parcela=(
                            fin_valor_parcela if comprou else None
                        ),
                    )
            elif pode_ver_financeiro:
                st.write(
                    f"**Comprou:** {'Sim' if ficha.get('comprou') else 'Não'}"
                )
                st.write(
                    f"**Valor liberado:** "
                    f"R$ {numero_seguro(ficha.get('valor_liberado')):,.2f}"
                )
                st.write(
                    f"**Entrada paga:** "
                    f"R$ {numero_seguro(ficha.get('entrada_paga')):,.2f}"
                )
                st.write(
                    f"**Valor pendente:** "
                    f"R$ {numero_seguro(ficha.get('valor_pendente')):,.2f}"
                )
                st.write(
                    f"**Boleto:** "
                    f"{'Sim' if ficha.get('gerou_boleto') else 'Não'}"
                )
                if ficha.get("gerou_boleto"):
                    st.write(
                        f"R$ {numero_seguro(ficha.get('boleto_valor')):,.2f} "
                        f"por {inteiro_seguro(ficha.get('boleto_meses'), 0)} meses"
                    )

    limite_fichas = st.session_state.get("fichas_limite", 24)
    if len(fichas) < total_fichas and limite_fichas < 100:
        if st.button(
            "Carregar mais 24 fichas",
            key="carregar_mais_fichas",
            use_container_width=True,
        ):
            st.session_state["fichas_limite"] = min(
                limite_fichas + 24,
                100,
            )
            st.rerun()


@st.cache_data(ttl=20, show_spinner=False)
def contar_chat_geral_nao_lidas(usuario_id: int) -> int:
    query = text(
        """
        SELECT COUNT(*)
        FROM public.chat_geral_mensagens m
        WHERE m.remetente_id <> :usuario_id
          AND NOT EXISTS (
              SELECT 1
              FROM public.chat_geral_leituras l
              WHERE l.mensagem_id = m.id
                AND l.usuario_id = :usuario_id
          )
        """
    )
    try:
        with engine.connect() as conn:
            return int(
                conn.execute(query, {"usuario_id": usuario_id}).scalar()
                or 0
            )
    except Exception:
        return 0


def marcar_chat_geral_como_lido(usuario_id: int) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO public.chat_geral_leituras (
                    mensagem_id,
                    usuario_id
                )
                SELECT m.id, :usuario_id
                FROM public.chat_geral_mensagens m
                WHERE m.remetente_id <> :usuario_id
                ON CONFLICT (mensagem_id, usuario_id) DO NOTHING
                """
            ),
            {"usuario_id": usuario_id},
        )


# Reações disponíveis no chat geral (adicione/remova emojis aqui).
CHAT_REACOES = ("👍", "❤️", "😂", "😮", "😢", "🔥", "👏")


def obter_chat_geral() -> pd.DataFrame:
    # Conta cada tipo de reação em colunas reacao_👍, reacao_❤️, ...
    filtros_reacao = ",\n".join(
        f"""            COUNT(r.id) FILTER (WHERE r.reacao = '{emoji}')
                AS "reacao_{emoji}" """
        for emoji in CHAT_REACOES
    )
    query = text(
        f"""
        SELECT
            m.id,
            m.remetente_id,
            m.mensagem,
            m.tipo,
            m.arquivo_nome,
            m.arquivo_mime,
            (m.arquivo_bytes IS NOT NULL) AS tem_anexo,
            m.created_at,
            u.nome AS nome_remetente,
{filtros_reacao}
        FROM public.chat_geral_mensagens m
        JOIN public.usuarios u
            ON u.id = m.remetente_id
        LEFT JOIN public.chat_geral_reacoes r
            ON r.mensagem_id = m.id
        GROUP BY
            m.id,
            u.nome
        ORDER BY m.created_at DESC
        LIMIT 100
        """
    )
    with engine.connect() as conn:
        mensagens = pd.read_sql_query(query, conn)
    if mensagens.empty:
        return mensagens
    return mensagens.sort_values(
        "created_at",
        ascending=True,
    ).reset_index(drop=True)


def obter_anexo_chat(mensagem_id: int) -> Optional[Dict[str, Any]]:
    query = text(
        """
        SELECT
            id,
            remetente_id,
            mensagem,
            arquivo_nome,
            arquivo_mime,
            arquivo_bytes
        FROM public.chat_geral_mensagens
        WHERE id = :mensagem_id
          AND arquivo_bytes IS NOT NULL
        """
    )
    with engine.connect() as conn:
        resultado = conn.execute(
            query,
            {"mensagem_id": mensagem_id},
        ).mappings().first()
    return dict(resultado) if resultado else None


@st.dialog("Anexo do chat")
def abrir_anexo_chat_modal(
    mensagem_id: int,
    nome_arquivo: str,
) -> None:
    try:
        anexo = obter_anexo_chat(mensagem_id)
    except Exception as erro:
        st.error(f"Erro ao carregar anexo: {erro}")
        return

    if not anexo:
        st.info("Este anexo não está mais disponível.")
        return

    conteudo = anexo["arquivo_bytes"]
    mime = anexo.get("arquivo_mime") or "application/octet-stream"
    if str(mime).startswith("image/"):
        st.image(conteudo)
    elif str(mime).startswith("audio/"):
        st.audio(conteudo, format=mime)
    st.download_button(
        "Baixar anexo",
        data=conteudo,
        file_name=nome_arquivo or "anexo",
        mime=mime,
        key=f"download_chat_modal_{mensagem_id}",
        use_container_width=True,
    )


def alternar_reacao_chat(
    mensagem_id: int,
    usuario_id: int,
    reacao: str = "👍",
) -> None:
    with engine.begin() as conn:
        existe = conn.execute(
            text(
                """
                SELECT 1
                FROM public.chat_geral_reacoes
                WHERE mensagem_id = :mensagem_id
                  AND usuario_id = :usuario_id
                  AND reacao = :reacao
                """
            ),
            {
                "mensagem_id": mensagem_id,
                "usuario_id": usuario_id,
                "reacao": reacao,
            },
        ).scalar()

        if existe:
            conn.execute(
                text(
                    """
                    DELETE FROM public.chat_geral_reacoes
                    WHERE mensagem_id = :mensagem_id
                      AND usuario_id = :usuario_id
                      AND reacao = :reacao
                    """
                ),
                {
                    "mensagem_id": mensagem_id,
                    "usuario_id": usuario_id,
                    "reacao": reacao,
                },
            )
        else:
            conn.execute(
                text(
                    """
                    INSERT INTO public.chat_geral_reacoes (
                        mensagem_id,
                        usuario_id,
                        reacao
                    )
                    VALUES (:mensagem_id, :usuario_id, :reacao)
                    ON CONFLICT DO NOTHING
                    """
                ),
                {
                    "mensagem_id": mensagem_id,
                    "usuario_id": usuario_id,
                    "reacao": reacao,
                },
            )


def salvar_mensagem_chat_geral(
    usuario_id: int,
    texto: str,
    arquivo: Any = None,
    audio: Any = None,
) -> None:
    arquivo_recebido = audio or arquivo
    mensagem = texto.strip() if texto else ""
    tipo = "texto"
    arquivo_nome = None
    arquivo_mime = None
    arquivo_bytes = None

    if arquivo_recebido is not None:
        arquivo_nome = getattr(
            arquivo_recebido,
            "name",
            "anexo",
        )
        arquivo_mime = getattr(
            arquivo_recebido,
            "type",
            "application/octet-stream",
        )
        arquivo_bytes = arquivo_recebido.getvalue()
        if str(arquivo_mime).startswith("audio/"):
            tipo = "audio"
        elif str(arquivo_mime).startswith("image/"):
            tipo = "imagem"
        else:
            tipo = "arquivo"

    if not mensagem and not arquivo_bytes:
        return

    storage_path = None
    storage_bucket = None
    bytes_db = arquivo_bytes
    if arquivo_bytes:
        caminho = caminho_storage_unico(f"chat/{usuario_id}", arquivo_nome or "anexo")
        path_ok = upload_para_storage(
            STORAGE_BUCKET_CHAT, caminho, arquivo_bytes, arquivo_mime or "application/octet-stream"
        )
        if path_ok:
            storage_path = path_ok
            storage_bucket = STORAGE_BUCKET_CHAT
            bytes_db = None  # não guarda binário no Postgres

    with engine.begin() as conn:
        try:
            conn.execute(
                text(
                    """
                    INSERT INTO public.chat_geral_mensagens (
                        remetente_id,
                        mensagem,
                        tipo,
                        arquivo_nome,
                        arquivo_mime,
                        arquivo_bytes,
                        storage_bucket,
                        storage_path
                    )
                    VALUES (
                        :usuario_id,
                        :mensagem,
                        :tipo,
                        :arquivo_nome,
                        :arquivo_mime,
                        :arquivo_bytes,
                        :storage_bucket,
                        :storage_path
                    )
                    """
                ),
                {
                    "usuario_id": usuario_id,
                    "mensagem": mensagem or None,
                    "tipo": tipo,
                    "arquivo_nome": arquivo_nome,
                    "arquivo_mime": arquivo_mime,
                    "arquivo_bytes": bytes_db,
                    "storage_bucket": storage_bucket,
                    "storage_path": storage_path,
                },
            )
        except Exception:
            # fallback se colunas storage_* ainda não existem
            conn.execute(
                text(
                    """
                    INSERT INTO public.chat_geral_mensagens (
                        remetente_id,
                        mensagem,
                        tipo,
                        arquivo_nome,
                        arquivo_mime,
                        arquivo_bytes
                    )
                    VALUES (
                        :usuario_id,
                        :mensagem,
                        :tipo,
                        :arquivo_nome,
                        :arquivo_mime,
                        :arquivo_bytes
                    )
                    """
                ),
                {
                    "usuario_id": usuario_id,
                    "mensagem": mensagem or None,
                    "tipo": tipo,
                    "arquivo_nome": arquivo_nome,
                    "arquivo_mime": arquivo_mime,
                    "arquivo_bytes": arquivo_bytes,
                },
            )


def excluir_anexo_chat(
    mensagem_id: int,
) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                UPDATE public.chat_geral_mensagens
                SET arquivo_nome = NULL,
                    arquivo_mime = NULL,
                    arquivo_bytes = NULL,
                    tipo = CASE
                        WHEN mensagem IS NULL THEN 'texto'
                        ELSE 'texto'
                    END
                WHERE id = :mensagem_id
                """
            ),
            {"mensagem_id": mensagem_id},
        )


@st.dialog("Excluir anexo do chat")
def excluir_anexo_chat_modal(
    mensagem_id: int,
    remetente_id: int,
    nome_arquivo: str,
) -> None:
    usuario = st.session_state["usuario_logado"]
    pode_excluir = (
        int(usuario["id"]) == int(remetente_id)
        or usuario_tem("view_documents")
    )
    if not pode_excluir:
        st.error("Você só pode excluir anexos enviados por você.")
        return

    st.warning(
        f"O anexo **{nome_arquivo}** será removido definitivamente. "
        "A mensagem de texto, se existir, será preservada."
    )
    if st.button(
        "Excluir anexo",
        type="primary",
        use_container_width=True,
    ):
        try:
            excluir_anexo_chat(mensagem_id)
            st.success("Anexo removido.")
            st.rerun()
        except Exception as erro:
            st.error(f"Erro ao excluir anexo: {erro}")


def pagina_chat(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("use_chat"):
        st.error("Você não tem permissão para acessar o chat.")
        return

    usuario_id = usuario["id"]
    st.title("Central de Chat")

    try:
        marcar_chat_geral_como_lido(usuario_id)
        df_chat = obter_chat_geral()
    except Exception as erro:
        st.error(
            "Execute schema_operacao_v3.sql no Supabase para ativar o "
            f"chat geral. Detalhe: {erro}"
        )
        return

    with st.container(height=450):
        if df_chat.empty:
            st.caption("Nenhuma mensagem ainda.")
        else:
            for _, mensagem in df_chat.iterrows():
                sou_eu = int(mensagem["remetente_id"]) == int(usuario_id)
                horario = formatar_data_br(
                    mensagem["created_at"],
                    incluir_hora=True,
                )
                with st.chat_message("user" if sou_eu else "assistant"):
                    st.caption(
                        f"**{mensagem['nome_remetente']}** • {horario}"
                    )
                    if mensagem.get("mensagem"):
                        st.write(mensagem["mensagem"])

                    if mensagem.get("tem_anexo"):
                        nome_anexo = (
                            mensagem.get("arquivo_nome") or "anexo"
                        )
                        if st.button(
                            f"📎 Abrir {nome_anexo}",
                            key=f"abrir_chat_{mensagem['id']}",
                        ):
                            abrir_anexo_chat_modal(
                                int(mensagem["id"]),
                                str(nome_anexo),
                            )
                        if (
                            int(mensagem["remetente_id"])
                            == int(usuario_id)
                            or usuario_tem("view_documents")
                        ) and st.button(
                            "Excluir anexo",
                            key=f"excluir_chat_{mensagem['id']}",
                        ):
                            excluir_anexo_chat_modal(
                                int(mensagem["id"]),
                                int(mensagem["remetente_id"]),
                                str(
                                    mensagem.get("arquivo_nome")
                                    or "anexo"
                                ),
                            )

                    # Resumo compacto das reações (só chips com contagem > 0).
                    chips = []
                    for emoji in CHAT_REACOES:
                        qtd = int(mensagem.get(f"reacao_{emoji}") or 0)
                        if qtd:
                            chips.append(f"{emoji} {qtd}")
                    if chips:
                        st.markdown(
                            '<div class="chat-reacao-resumo">'
                            + "".join(
                                f'<span class="chat-reacao-chip">{c}</span>'
                                for c in chips
                            )
                            + "</div>",
                            unsafe_allow_html=True,
                        )
                    # Seletor discreto: abre só quando clica em "Reagir"
                    with st.expander("Reagir", expanded=False):
                        cols_reacao = st.columns(len(CHAT_REACOES))
                        for idx_r, emoji in enumerate(CHAT_REACOES):
                            qtd = int(mensagem.get(f"reacao_{emoji}") or 0)
                            label = f"{emoji}" + (f" {qtd}" if qtd else "")
                            with cols_reacao[idx_r]:
                                if st.button(
                                    label,
                                    key=f"reagir_chat_{mensagem['id']}_{emoji}",
                                ):
                                    alternar_reacao_chat(
                                        int(mensagem["id"]),
                                        usuario_id,
                                        reacao=emoji,
                                    )
                                    st.rerun()

    entrada_chat = None
    chat_com_anexos = True
    try:
        # Nas versões recentes, o próprio st.chat_input exibe o botão
        # de anexos ao lado do campo e mantém o envio em uma única ação.
        entrada_chat = st.chat_input(
            "Digite sua mensagem ou anexe um documento...",
            accept_file="multiple",
            accept_audio=True,
            file_type=[
                "png",
                "jpg",
                "jpeg",
                "webp",
                "pdf",
                "doc",
                "docx",
                "xls",
                "xlsx",
            ],
        )
    except TypeError:
        # Compatibilidade com uma versão antiga do Streamlit.
        chat_com_anexos = False

    if chat_com_anexos and entrada_chat:
        texto_chat = getattr(entrada_chat, "text", None)
        if texto_chat is None and isinstance(entrada_chat, str):
            texto_chat = entrada_chat
        arquivos_chat = list(
            getattr(entrada_chat, "files", None) or []
        )

        if arquivos_chat:
            for indice, arquivo_chat in enumerate(arquivos_chat):
                salvar_mensagem_chat_geral(
                    usuario_id,
                    texto_chat if indice == 0 else "",
                    arquivo=arquivo_chat,
                )
        elif texto_chat and texto_chat.strip():
            salvar_mensagem_chat_geral(usuario_id, texto_chat)
        st.rerun()

    if not chat_com_anexos:
        arquivo = st.file_uploader(
            "Anexar arquivo ou imagem",
            type=[
                "png",
                "jpg",
                "jpeg",
                "webp",
                "pdf",
                "doc",
                "docx",
            ],
            key="chat_arquivo_geral",
        )
        enviar_anexo = st.button(
            "Enviar anexo",
            disabled=arquivo is None,
        )
        if enviar_anexo:
            salvar_mensagem_chat_geral(
                usuario_id,
                "",
                arquivo=arquivo,
            )
            st.rerun()


def pagina_tarefas(usuario: Dict[str, Any]) -> None:
    """
    Tarefas:
    - o gerente cria, altera, exclui e realoca;
    - cada usuário vê apenas as tarefas destinadas a si;
    - o gerente vê todas;
    - o destinatário responde Sim/Não e escreve uma observação;
    - visualizada_at alimenta a notificação de não visualizada.
    """
    if not usuario_tem("view_tasks"):
        st.error("Você não tem permissão para acessar tarefas.")
        return

    st.title("Tarefas")

    tarefas_nao_lidas = contar_tarefas_nao_visualizadas(usuario["id"])
    if tarefas_nao_lidas:
        st.warning(
            f"Você tem {tarefas_nao_lidas} tarefa(s) ainda não visualizada(s)."
        )
        # Abrir a aba representa a visualização das tarefas.
        marcar_tarefas_como_visualizadas(usuario["id"])

    if usuario_pode_gerir_tarefas():
        usuarios = obter_usuarios_ativos()
        ids_usuarios = usuarios["id"].tolist()

        with st.expander("➕ Criar nova tarefa", expanded=True):
            with st.form("form_criar_tarefa"):
                titulo = st.text_input("Título da tarefa*")
                descricao = st.text_area("Descrição / instruções")
                modo_alvo = st.radio(
                    "Atribuir para",
                    ["pessoa", "tipo", "loja"],
                    horizontal=True,
                    format_func=lambda m: {
                        "pessoa": "Pessoa específica",
                        "tipo": "Perfil / tipo (ex.: todos vendedores)",
                        "loja": "Todos de uma loja",
                    }[m],
                )
                destinatario_id = None
                tipo_alvo = None
                loja_alvo = None
                if modo_alvo == "pessoa":
                    destinatario_id = st.selectbox(
                        "Pessoa*",
                        options=ids_usuarios,
                        format_func=lambda valor: usuarios.loc[
                            usuarios["id"] == valor, "nome"
                        ].iloc[0],
                    )
                elif modo_alvo == "tipo":
                    tipos_opt = sorted(
                        set(usuarios["tipo"].dropna().astype(str).tolist())
                        | set(PERMISSIONS.keys())
                    )
                    tipo_alvo = st.selectbox("Tipo / perfil*", tipos_opt)
                else:
                    loja_alvo = st.selectbox(
                        "Loja*", list(LOJAS_DISPONIVEIS)
                    )

                criar = st.form_submit_button(
                    "Criar tarefa",
                    use_container_width=True,
                    type="primary",
                )

            if criar:
                if not titulo.strip():
                    st.warning("Informe um título para a tarefa.")
                else:
                    # Resolve lista de destinatários
                    dests = []
                    if modo_alvo == "pessoa" and destinatario_id:
                        dests = [int(destinatario_id)]
                    elif modo_alvo == "tipo" and tipo_alvo:
                        dests = usuarios[
                            usuarios["tipo"].astype(str).str.lower()
                            == str(tipo_alvo).lower()
                        ]["id"].astype(int).tolist()
                    elif modo_alvo == "loja" and loja_alvo:
                        if "loja" in usuarios.columns:
                            dests = usuarios[
                                usuarios["loja"].astype(str).str.upper()
                                == str(loja_alvo).upper()
                            ]["id"].astype(int).tolist()
                        else:
                            dests = []
                    if not dests:
                        st.warning("Nenhum destinatário encontrado para o alvo.")
                    else:
                        try:
                            with engine.begin() as conn:
                                for did in dests:
                                    conn.execute(
                                        text(
                                            """
                                            INSERT INTO public.tarefas (
                                                titulo,
                                                descricao,
                                                destinatario_id,
                                                criado_por_id,
                                                alvo_tipo,
                                                alvo_loja
                                            )
                                            VALUES (
                                                :titulo,
                                                :descricao,
                                                :destinatario_id,
                                                :criado_por_id,
                                                :alvo_tipo,
                                                :alvo_loja
                                            )
                                            """
                                        ),
                                        {
                                            "titulo": titulo.strip(),
                                            "descricao": (
                                                descricao.strip()
                                                if descricao.strip()
                                                else None
                                            ),
                                            "destinatario_id": did,
                                            "criado_por_id": usuario["id"],
                                            "alvo_tipo": tipo_alvo,
                                            "alvo_loja": loja_alvo,
                                        },
                                    )
                            st.success(
                                f"Tarefa criada para {len(dests)} destinatário(s). "
                                f"(por: {usuario.get('nome')})"
                            )
                            st.rerun()
                        except Exception as erro:
                            st.error(
                                f"Erro ao criar tarefa: {erro}. "
                                "Rode o schema (colunas alvo_tipo/alvo_loja)."
                            )

    try:
        tarefas = obter_tarefas(usuario)
    except Exception as erro:
        st.error(
            "Não foi possível carregar tarefas. "
            "Execute primeiro o arquivo schema_metas_tarefas.sql "
            f"no Supabase. Detalhe: {erro}"
        )
        return

    if tarefas.empty:
        st.info("Nenhuma tarefa encontrada.")
        return

    st.subheader(f"{len(tarefas)} tarefa(s)")

    usuarios = (
        obter_usuarios_ativos()
        if usuario_pode_gerir_tarefas()
        else pd.DataFrame()
    )

    for _, tarefa in tarefas.iterrows():
        resposta = tarefa.get("resposta")
        if pd.isna(resposta):
            status = "⏳ Aguardando resposta"
        elif bool(resposta):
            status = "✅ Concluída / Sim"
        else:
            status = "❌ Não realizada"

        with st.expander(
            f"{status}  |  {tarefa['titulo']}",
            expanded=(pd.isna(resposta)),
        ):
            st.write(tarefa.get("descricao") or "Sem descrição.")
            st.caption(
                f"Destinatário: {tarefa['destinatario_nome']}  •  "
                f"Criada por: {tarefa['criador_nome']}  •  "
                f"Em: {formatar_data_br(tarefa['created_at'], True)}"
            )

            if tarefa.get("observacao"):
                st.info(f"**Observação da resposta:** {tarefa['observacao']}")

            # O destinatário pode responder. O gerente também pode
            # responder quando a tarefa foi atribuída a ele próprio.
            eh_destinatario = tarefa["destinatario_id"] == usuario["id"]
            if eh_destinatario and usuario_tem("respond_tasks"):
                opcoes_resposta = [
                    "Ainda não respondi",
                    "Sim",
                    "Não",
                ]

                if pd.isna(resposta):
                    indice_resposta = 0
                else:
                    indice_resposta = 1 if bool(resposta) else 2

                with st.form(f"form_resposta_tarefa_{tarefa['id']}"):
                    resposta_escolhida = st.radio(
                        "Você realizou esta tarefa?",
                        opcoes_resposta,
                        index=indice_resposta,
                        horizontal=True,
                    )
                    observacao = st.text_area(
                        "Observação",
                        value=str(tarefa.get("observacao") or ""),
                    )
                    salvar_resposta = st.form_submit_button(
                        "Salvar minha resposta",
                        use_container_width=True,
                    )

                if salvar_resposta:
                    nova_resposta = None
                    if resposta_escolhida == "Sim":
                        nova_resposta = True
                    elif resposta_escolhida == "Não":
                        nova_resposta = False

                    try:
                        with engine.begin() as conn:
                            conn.execute(
                                text(
                                    """
                                    UPDATE public.tarefas
                                    SET
                                        resposta = :resposta,
                                        observacao = :observacao,
                                        respondida_at = CASE
                                            WHEN :resposta IS NULL
                                            THEN NULL
                                            ELSE NOW()
                                        END,
                                        updated_at = NOW()
                                    WHERE id = :id
                                      AND destinatario_id = :usuario_id
                                    """
                                ),
                                {
                                    "resposta": nova_resposta,
                                    "observacao": (
                                        observacao.strip()
                                        if observacao.strip()
                                        else None
                                    ),
                                    "id": tarefa["id"],
                                    "usuario_id": usuario["id"],
                                },
                            )
                        st.success("Resposta salva.")
                        st.rerun()
                    except Exception as erro:
                        st.error(f"Erro ao responder tarefa: {erro}")

            # Admin / gerente / marketing administram a tarefa.
            if usuario_pode_gerir_tarefas():
                st.markdown("---")
                st.markdown("**Administração da tarefa**")

                ids_usuarios = usuarios["id"].tolist()
                indice_destinatario = (
                    ids_usuarios.index(tarefa["destinatario_id"])
                    if tarefa["destinatario_id"] in ids_usuarios
                    else 0
                )

                with st.form(f"form_editar_tarefa_{tarefa['id']}"):
                    novo_titulo = st.text_input(
                        "Título",
                        value=str(tarefa["titulo"]),
                    )
                    nova_descricao = st.text_area(
                        "Descrição",
                        value=str(tarefa.get("descricao") or ""),
                    )
                    novo_destinatario = st.selectbox(
                        "Realocar para",
                        options=ids_usuarios,
                        index=indice_destinatario,
                        format_func=lambda valor: usuarios.loc[
                            usuarios["id"] == valor, "nome"
                        ].iloc[0],
                    )
                    salvar_alteracao = st.form_submit_button(
                        "Salvar alteração / realocação",
                        use_container_width=True,
                    )

                if salvar_alteracao:
                    if not novo_titulo.strip():
                        st.warning("O título não pode ficar vazio.")
                    else:
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        UPDATE public.tarefas
                                        SET
                                            titulo = :titulo,
                                            descricao = :descricao,
                                            destinatario_id = :destinatario_id,
                                            updated_at = NOW()
                                        WHERE id = :id
                                        """
                                    ),
                                    {
                                        "titulo": novo_titulo.strip(),
                                        "descricao": (
                                            nova_descricao.strip()
                                            if nova_descricao.strip()
                                            else None
                                        ),
                                        "destinatario_id": novo_destinatario,
                                        "id": tarefa["id"],
                                    },
                                )
                            st.success("Tarefa atualizada.")
                            st.rerun()
                        except Exception as erro:
                            st.error(
                                f"Erro ao atualizar tarefa: {erro}"
                            )

                if st.button(
                    "🗑️ Remover tarefa",
                    key=f"remover_tarefa_{tarefa['id']}",
                    type="secondary",
                ):
                    try:
                        with engine.begin() as conn:
                            conn.execute(
                                text(
                                    """
                                    DELETE FROM public.tarefas
                                    WHERE id = :id
                                    """
                                ),
                                {"id": tarefa["id"]},
                            )
                        st.success("Tarefa removida.")
                        st.rerun()
                    except Exception as erro:
                        st.error(f"Erro ao remover tarefa: {erro}")


def pagina_metas(usuario: Dict[str, Any]) -> None:
    """
    Metas:
    - somente gerente/admin cria, edita, remove e marca concluída;
    - destinatário pode ser: usuário específico, tipo (perfil) ou loja;
    - cada usuário só vê metas relacionadas a ele (ou gerais).
    """
    if not usuario_tem("view_goals"):
        st.error("Você não tem permissão para acessar metas.")
        return

    st.title("Metas")

    usuarios = obter_usuarios_ativos()
    tipos_disponiveis = sorted(
        {
            normalizar_tipo(t)
            for t in usuarios.get("tipo", pd.Series(dtype=str)).dropna().tolist()
        }
        | set(PERMISSIONS.keys())
    )
    lojas = list(LOJAS_DISPONIVEIS)

    if usuario_e_gestor():
        ids_usuarios = [None] + usuarios["id"].tolist()
        nomes_usuarios = {None: "— nenhum usuário específico —"}
        nomes_usuarios.update(
            dict(zip(usuarios["id"], usuarios["nome"]))
        )

        with st.expander("➕ Criar nova meta", expanded=True):
            with st.form("form_criar_meta"):
                titulo = st.text_input("Nome da meta*")
                descricao = st.text_area("Descrição")
                unidade = st.text_input(
                    "Unidade",
                    value="vendas",
                    help="Ex.: vendas, leads, fichas ou reais.",
                )
                valor_objetivo = st.number_input(
                    "Valor objetivo",
                    min_value=0.0,
                    step=1.0,
                )
                periodo_inicio = st.date_input(
                    "Início do período",
                    value=date.today(),
                )
                periodo_fim = st.date_input(
                    "Fim do período",
                    value=date.today(),
                )
                # Destino: usuário OU tipo OU loja (prioridade nessa ordem na exibição)
                st.markdown("**Destino da meta** (escolha um ou deixe todos vazios = geral)")
                destinatario_id = st.selectbox(
                    "Usuário específico",
                    options=ids_usuarios,
                    format_func=lambda valor: nomes_usuarios[valor],
                )
                destinatario_tipo = st.selectbox(
                    "Perfil / tipo de usuário",
                    options=[None] + tipos_disponiveis,
                    format_func=lambda v: "— nenhum —" if v is None else v,
                )
                destinatario_loja = st.selectbox(
                    "Loja",
                    options=[None] + lojas,
                    format_func=lambda v: "— nenhuma —" if v is None else v,
                )
                criar = st.form_submit_button(
                    "Criar meta",
                    use_container_width=True,
                    type="primary",
                )

            if criar:
                if not titulo.strip():
                    st.warning("Informe o nome da meta.")
                elif periodo_fim < periodo_inicio:
                    st.warning(
                        "O fim do período não pode ser anterior ao início."
                    )
                else:
                    try:
                        with engine.begin() as conn:
                            conn.execute(
                                text(
                                    """
                                    INSERT INTO public.metas (
                                        titulo,
                                        descricao,
                                        unidade,
                                        valor_objetivo,
                                        periodo_inicio,
                                        periodo_fim,
                                        destinatario_id,
                                        destinatario_tipo,
                                        destinatario_loja,
                                        criado_por_id
                                    )
                                    VALUES (
                                        :titulo,
                                        :descricao,
                                        :unidade,
                                        :valor_objetivo,
                                        :periodo_inicio,
                                        :periodo_fim,
                                        :destinatario_id,
                                        :destinatario_tipo,
                                        :destinatario_loja,
                                        :criado_por_id
                                    )
                                    """
                                ),
                                {
                                    "titulo": titulo.strip(),
                                    "descricao": (
                                        descricao.strip()
                                        if descricao.strip()
                                        else None
                                    ),
                                    "unidade": unidade.strip() or "unidade",
                                    "valor_objetivo": valor_objetivo,
                                    "periodo_inicio": periodo_inicio,
                                    "periodo_fim": periodo_fim,
                                    "destinatario_id": destinatario_id,
                                    "destinatario_tipo": destinatario_tipo,
                                    "destinatario_loja": destinatario_loja,
                                    "criado_por_id": usuario["id"],
                                },
                            )
                        st.success("Meta criada.")
                        st.rerun()
                    except Exception as erro:
                        # Fallback sem colunas novas
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        INSERT INTO public.metas (
                                            titulo,
                                            descricao,
                                            unidade,
                                            valor_objetivo,
                                            periodo_inicio,
                                            periodo_fim,
                                            destinatario_id,
                                            criado_por_id
                                        )
                                        VALUES (
                                            :titulo,
                                            :descricao,
                                            :unidade,
                                            :valor_objetivo,
                                            :periodo_inicio,
                                            :periodo_fim,
                                            :destinatario_id,
                                            :criado_por_id
                                        )
                                        """
                                    ),
                                    {
                                        "titulo": titulo.strip(),
                                        "descricao": (
                                            descricao.strip()
                                            if descricao.strip()
                                            else None
                                        ),
                                        "unidade": unidade.strip() or "unidade",
                                        "valor_objetivo": valor_objetivo,
                                        "periodo_inicio": periodo_inicio,
                                        "periodo_fim": periodo_fim,
                                        "destinatario_id": destinatario_id,
                                        "criado_por_id": usuario["id"],
                                    },
                                )
                            st.success(
                                "Meta criada (sem tipo/loja — rode schema_metas_v2.sql)."
                            )
                            st.rerun()
                        except Exception as erro2:
                            st.error(f"Erro ao criar meta: {erro2}")

    try:
        metas = obter_metas(usuario)
    except Exception as erro:
        st.error(
            "Não foi possível carregar metas. "
            "Execute schema_metas_tarefas.sql / schema_metas_v2.sql. "
            f"Detalhe: {erro}"
        )
        return

    if metas.empty:
        st.info("Nenhuma meta encontrada.")
        return

    for _, meta in metas.iterrows():
        partes_destino = []
        if meta.get("destinatario_nome"):
            partes_destino.append(str(meta["destinatario_nome"]))
        if meta.get("destinatario_tipo"):
            partes_destino.append(f"tipo:{meta['destinatario_tipo']}")
        if meta.get("destinatario_loja"):
            partes_destino.append(f"loja:{meta['destinatario_loja']}")
        destino = " · ".join(partes_destino) if partes_destino else "Geral"

        concluida = meta.get("concluida")
        if concluida is True:
            status_meta = "✅ Concluída"
        elif concluida is False:
            status_meta = "❌ Não concluída"
        else:
            status_meta = "⏳ Em aberto"

        periodo = (
            f"{formatar_data_br(meta.get('periodo_inicio'))} até "
            f"{formatar_data_br(meta.get('periodo_fim'))}"
        )

        with st.expander(
            f"{status_meta}  ·  {meta['titulo']}  |  {destino}",
            expanded=True,
        ):
            st.write(meta.get("descricao") or "Sem descrição.")
            c1, c2, c3 = st.columns(3)
            c1.metric(
                f"Objetivo ({meta.get('unidade') or 'unidade'})",
                meta.get("valor_objetivo") or 0,
            )
            c2.write("**Período**")
            c2.write(periodo)
            c3.write("**Criada por**")
            c3.write(meta.get("criador_nome") or "-")

            # Somente gerente/admin edita, marca conclusão e remove.
            if usuario_e_gestor():
                st.markdown("---")
                st.markdown("**Administração da meta**")

                # Marcar conclusão fora do form de edição completa
                col_c1, col_c2, col_c3 = st.columns(3)
                with col_c1:
                    if st.button(
                        "✅ Marcar concluída",
                        key=f"meta_ok_{meta['id']}",
                        use_container_width=True,
                    ):
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        UPDATE public.metas
                                        SET concluida = TRUE,
                                            updated_at = NOW()
                                        WHERE id = :id
                                        """
                                    ),
                                    {"id": meta["id"]},
                                )
                            st.success("Meta marcada como concluída.")
                            st.rerun()
                        except Exception as erro:
                            st.error(f"Erro: {erro}")
                with col_c2:
                    if st.button(
                        "❌ Marcar não concluída",
                        key=f"meta_nok_{meta['id']}",
                        use_container_width=True,
                    ):
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        UPDATE public.metas
                                        SET concluida = FALSE,
                                            updated_at = NOW()
                                        WHERE id = :id
                                        """
                                    ),
                                    {"id": meta["id"]},
                                )
                            st.success("Meta marcada como não concluída.")
                            st.rerun()
                        except Exception as erro:
                            st.error(f"Erro: {erro}")
                with col_c3:
                    if st.button(
                        "⏳ Limpar status",
                        key=f"meta_clear_{meta['id']}",
                        use_container_width=True,
                    ):
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        UPDATE public.metas
                                        SET concluida = NULL,
                                            updated_at = NOW()
                                        WHERE id = :id
                                        """
                                    ),
                                    {"id": meta["id"]},
                                )
                            st.success("Status limpo.")
                            st.rerun()
                        except Exception as erro:
                            st.error(f"Erro: {erro}")

                ids_usuarios = [None] + usuarios["id"].tolist()
                nomes_usuarios = {None: "— nenhum usuário específico —"}
                nomes_usuarios.update(
                    dict(zip(usuarios["id"], usuarios["nome"]))
                )
                destinatario_atual = meta.get("destinatario_id")
                if pd.isna(destinatario_atual):
                    destinatario_atual = None
                indice_destinatario = (
                    ids_usuarios.index(destinatario_atual)
                    if destinatario_atual in ids_usuarios
                    else 0
                )

                with st.form(f"form_editar_meta_{meta['id']}"):
                    novo_titulo = st.text_input(
                        "Nome",
                        value=str(meta["titulo"]),
                    )
                    nova_descricao = st.text_area(
                        "Descrição",
                        value=str(meta.get("descricao") or ""),
                    )
                    nova_unidade = st.text_input(
                        "Unidade",
                        value=str(meta.get("unidade") or "unidade"),
                    )
                    novo_valor = st.number_input(
                        "Valor objetivo",
                        min_value=0.0,
                        value=float(meta.get("valor_objetivo") or 0),
                        step=1.0,
                    )
                    novo_inicio = st.date_input(
                        "Início",
                        value=converter_data(meta.get("periodo_inicio")),
                    )
                    novo_fim = st.date_input(
                        "Fim",
                        value=converter_data(meta.get("periodo_fim")),
                    )
                    novo_destinatario = st.selectbox(
                        "Usuário",
                        options=ids_usuarios,
                        index=indice_destinatario,
                        format_func=lambda valor: nomes_usuarios[valor],
                    )
                    tipo_atual = meta.get("destinatario_tipo")
                    if pd.isna(tipo_atual) or not tipo_atual:
                        tipo_atual = None
                    idx_tipo = (
                        ([None] + tipos_disponiveis).index(tipo_atual)
                        if tipo_atual in ([None] + tipos_disponiveis)
                        else 0
                    )
                    novo_tipo = st.selectbox(
                        "Perfil / tipo",
                        options=[None] + tipos_disponiveis,
                        index=idx_tipo,
                        format_func=lambda v: "— nenhum —" if v is None else v,
                    )
                    loja_atual = meta.get("destinatario_loja")
                    if pd.isna(loja_atual) or not loja_atual:
                        loja_atual = None
                    idx_loja = (
                        ([None] + lojas).index(loja_atual)
                        if loja_atual in ([None] + lojas)
                        else 0
                    )
                    nova_loja = st.selectbox(
                        "Loja",
                        options=[None] + lojas,
                        index=idx_loja,
                        format_func=lambda v: "— nenhuma —" if v is None else v,
                    )
                    salvar_meta = st.form_submit_button(
                        "Salvar alteração",
                        use_container_width=True,
                    )

                if salvar_meta:
                    if not novo_titulo.strip():
                        st.warning("O nome da meta não pode ficar vazio.")
                    elif novo_fim < novo_inicio:
                        st.warning(
                            "O fim do período não pode ser anterior ao início."
                        )
                    else:
                        try:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        UPDATE public.metas
                                        SET
                                            titulo = :titulo,
                                            descricao = :descricao,
                                            unidade = :unidade,
                                            valor_objetivo = :valor_objetivo,
                                            periodo_inicio = :periodo_inicio,
                                            periodo_fim = :periodo_fim,
                                            destinatario_id = :destinatario_id,
                                            destinatario_tipo = :destinatario_tipo,
                                            destinatario_loja = :destinatario_loja,
                                            updated_at = NOW()
                                        WHERE id = :id
                                        """
                                    ),
                                    {
                                        "titulo": novo_titulo.strip(),
                                        "descricao": (
                                            nova_descricao.strip()
                                            if nova_descricao.strip()
                                            else None
                                        ),
                                        "unidade": (
                                            nova_unidade.strip()
                                            or "unidade"
                                        ),
                                        "valor_objetivo": novo_valor,
                                        "periodo_inicio": novo_inicio,
                                        "periodo_fim": novo_fim,
                                        "destinatario_id": novo_destinatario,
                                        "destinatario_tipo": novo_tipo,
                                        "destinatario_loja": nova_loja,
                                        "id": meta["id"],
                                    },
                                )
                            st.success("Meta atualizada.")
                            st.rerun()
                        except Exception as erro:
                            st.error(f"Erro ao atualizar meta: {erro}")

                if st.button(
                    "🗑️ Remover meta",
                    key=f"remover_meta_{meta['id']}",
                ):
                    try:
                        with engine.begin() as conn:
                            conn.execute(
                                text(
                                    """
                                    UPDATE public.metas
                                    SET ativo = FALSE,
                                        updated_at = NOW()
                                    WHERE id = :id
                                    """
                                ),
                                {"id": meta["id"]},
                            )
                        st.success("Meta removida.")
                        st.rerun()
                    except Exception as erro:
                        st.error(f"Erro ao remover meta: {erro}")





# ============================================================
# OFICINA
# ============================================================

def normalizar_placa(placa: Any) -> str:
    return (
        str(placa or "")
        .strip()
        .replace("-", "")
        .replace(" ", "")
        .upper()
    )


def usuario_pode_editar_oficina() -> bool:
    return usuario_tem("edit_oficina") or usuario_tem("manage_oficina")


def usuario_pode_ver_oficina_detalhes() -> bool:
    """Mecânica, lataria e valor final: só oficina + gerente/admin."""
    return usuario_pode_editar_oficina() or usuario_e_gerente()


@st.cache_data(ttl=20, show_spinner=False)
def obter_oficina_carros(busca: str = "") -> pd.DataFrame:
    termo = (busca or "").strip()
    if termo:
        query = text(
            """
            SELECT
                o.id,
                o.marca,
                o.modelo,
                o.ano_modelo,
                o.placa,
                o.cor,
                o.onde_esta,
                o.pronto,
                o.observacao,
                o.mecanica,
                o.lataria,
                o.valor_final,
                o.estoque_carro_id,
                o.created_at,
                o.updated_at,
                o.atualizado_por_id,
                u.nome AS atualizado_por_nome
            FROM public.oficina_carros o
            LEFT JOIN public.usuarios u ON u.id = o.atualizado_por_id
            WHERE
                o.marca ILIKE :busca
                OR o.modelo ILIKE :busca
                OR o.ano_modelo ILIKE :busca
                OR o.placa ILIKE :busca
                OR o.cor ILIKE :busca
                OR o.onde_esta ILIKE :busca
                OR similarity(COALESCE(o.marca, ''), :busca_raw) > 0.3
                OR similarity(COALESCE(o.modelo, ''), :busca_raw) > 0.3
            ORDER BY o.updated_at DESC NULLS LAST, o.id DESC
            """
        )
        parametros = {"busca": f"%{termo}%", "busca_raw": termo}
    else:
        query = text(
            """
            SELECT
                o.id,
                o.marca,
                o.modelo,
                o.ano_modelo,
                o.placa,
                o.cor,
                o.onde_esta,
                o.pronto,
                o.observacao,
                o.mecanica,
                o.lataria,
                o.valor_final,
                o.estoque_carro_id,
                o.created_at,
                o.updated_at,
                o.atualizado_por_id,
                u.nome AS atualizado_por_nome
            FROM public.oficina_carros o
            LEFT JOIN public.usuarios u ON u.id = o.atualizado_por_id
            ORDER BY o.updated_at DESC NULLS LAST, o.id DESC
            """
        )
        parametros = {}

    with engine.connect() as conn:
        return pd.read_sql_query(query, conn, params=parametros)


def notificar_usuarios_oficina(
    conn: Any,
    titulo: str,
    mensagem: str,
    placa: Optional[str] = None,
    somente_gerentes: bool = False,
) -> None:
    """
    Notifica gerentes/admins sempre.
    Se houver placa e vendedores ligados a leads vendidos com essa placa,
    também notifica esses vendedores (via usuarios.vendedor_id).
    """
    placa_norm = normalizar_placa(placa) if placa else None

    if somente_gerentes:
        filtro_extra = "FALSE"
        params = {"titulo": titulo, "mensagem": mensagem}
    elif placa_norm:
        filtro_extra = """
            u.vendedor_id IN (
                SELECT DISTINCT l.vendedor_id
                FROM public.leads l
                WHERE REPLACE(REPLACE(UPPER(COALESCE(l.placa_carro, '')), '-', ''), ' ', '') = :placa
                  AND (
                    COALESCE(l.venda_concluida, FALSE) = TRUE
                    OR COALESCE(l.vendeu, FALSE) = TRUE
                  )
                  AND l.vendedor_id IS NOT NULL
            )
        """
        params = {
            "titulo": titulo,
            "mensagem": mensagem,
            "placa": placa_norm,
        }
    else:
        # Carro novo / sem vínculo de venda: notifica todos os ativos
        # (exceto quem já entra pelo grupo gerente/oficina abaixo).
        filtro_extra = "TRUE"
        params = {"titulo": titulo, "mensagem": mensagem}

    conn.execute(
        text(
            f"""
            INSERT INTO public.notificacoes (
                usuario_id,
                tipo,
                titulo,
                mensagem
            )
            SELECT
                u.id,
                'oficina',
                :titulo,
                :mensagem
            FROM public.usuarios u
            WHERE COALESCE(u.ativo, TRUE) = TRUE
              AND (
                    REGEXP_REPLACE(
                        LOWER(COALESCE(u.tipo, '')),
                        '[^a-z0-9]',
                        '',
                        'g'
                    ) IN (
                        'gerente',
                        'admin',
                        'administrador',
                        'dono',
                        'owner',
                        'proprietario',
                        'marketing',
                        'guariba',
                        'mecanico',
                        'mecânico'
                    )
                    OR ({filtro_extra})
              )
            """
        ),
        params,
    )


def cadastrar_carro_oficina(
    usuario: Dict[str, Any],
    marca: str,
    modelo: str,
    ano_modelo: str,
    placa: str,
    cor: str = "",
) -> None:
    if not usuario_tem("manage_oficina") and not usuario_e_gerente():
        st.error("Você não pode cadastrar carros na oficina.")
        return

    marca = (marca or "").strip()
    modelo = (modelo or "").strip()
    ano_modelo = (ano_modelo or "").strip()
    placa_norm = normalizar_placa(placa)
    cor = (cor or "").strip() or None

    if not marca or not modelo or not ano_modelo or not placa_norm:
        st.error("Informe marca, modelo, ano/modelo e placa.")
        return

    try:
        with engine.begin() as conn:
            existente = conn.execute(
                text(
                    """
                    SELECT id
                    FROM public.oficina_carros
                    WHERE REPLACE(REPLACE(UPPER(placa), '-', ''), ' ', '') = :placa
                    LIMIT 1
                    """
                ),
                {"placa": placa_norm},
            ).scalar()

            estoque_id = conn.execute(
                text(
                    """
                    SELECT id
                    FROM public.estoque_carros
                    WHERE REPLACE(REPLACE(UPPER(COALESCE(placa, '')), '-', ''), ' ', '') = :placa
                    LIMIT 1
                    """
                ),
                {"placa": placa_norm},
            ).scalar()

            if existente:
                st.warning("Já existe um carro na oficina com essa placa.")
                return

            carro_id = conn.execute(
                text(
                    """
                    INSERT INTO public.oficina_carros (
                        marca,
                        modelo,
                        ano_modelo,
                        placa,
                        cor,
                        estoque_carro_id,
                        atualizado_por_id
                    )
                    VALUES (
                        :marca,
                        :modelo,
                        :ano_modelo,
                        :placa,
                        :cor,
                        :estoque_carro_id,
                        :usuario_id
                    )
                    RETURNING id
                    """
                ),
                {
                    "marca": marca,
                    "modelo": modelo,
                    "ano_modelo": ano_modelo,
                    "placa": placa_norm,
                    "cor": cor,
                    "estoque_carro_id": int(estoque_id) if estoque_id else None,
                    "usuario_id": usuario["id"],
                },
            ).scalar_one()

            # Placa nova (não estava na oficina): notifica todos.
            notificar_usuarios_oficina(
                conn,
                titulo="Novo carro na oficina",
                mensagem=(
                    f"{marca} {modelo} ({ano_modelo}) placa {placa_norm} "
                    "entrou na oficina."
                ),
                placa=None,
            )

            if estoque_id:
                notificar_usuarios_oficina(
                    conn,
                    titulo="Carro do estoque na oficina",
                    mensagem=(
                        f"O carro placa {placa_norm} (já no estoque) "
                        "foi adicionado à oficina."
                    ),
                    placa=None,
                )

        st.success("Carro cadastrado na oficina.")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao cadastrar carro na oficina: {erro}")


def salvar_oficina_carro(
    usuario: Dict[str, Any],
    carro_id: int,
    placa: str,
    onde_esta: str,
    pronto: bool,
    observacao: str,
    mecanica: str,
    lataria: str,
    valor_final: str,
    cor: str,
) -> None:
    """
    Atualiza a oficina e espelha 'onde_esta' no campo 'patio' do estoque
    quando existir carro com a mesma placa.
    """
    if not usuario_pode_editar_oficina():
        st.error("Você não pode alterar dados da oficina.")
        return

    onde_limpo = (onde_esta or "").strip() or None
    placa_norm = normalizar_placa(placa)

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    UPDATE public.oficina_carros
                    SET
                        onde_esta = :onde_esta,
                        pronto = :pronto,
                        observacao = :observacao,
                        mecanica = :mecanica,
                        lataria = :lataria,
                        valor_final = :valor_final,
                        cor = :cor,
                        atualizado_por_id = :usuario_id,
                        updated_at = NOW()
                    WHERE id = :id
                    """
                ),
                {
                    "onde_esta": onde_limpo,
                    "pronto": bool(pronto),
                    "observacao": (observacao or "").strip() or None,
                    "mecanica": (mecanica or "").strip() or None,
                    "lataria": (lataria or "").strip() or None,
                    "valor_final": (valor_final or "").strip() or None,
                    "cor": (cor or "").strip() or None,
                    "usuario_id": usuario["id"],
                    "id": carro_id,
                },
            )

            # Espelha localização no estoque (coluna patio).
            if placa_norm:
                conn.execute(
                    text(
                        """
                        UPDATE public.estoque_carros
                        SET patio = :patio
                        WHERE REPLACE(
                            REPLACE(UPPER(COALESCE(placa, '')), '-', ''),
                            ' ',
                            ''
                        ) = :placa
                        """
                    ),
                    {"patio": onde_limpo, "placa": placa_norm},
                )

            notificar_usuarios_oficina(
                conn,
                titulo="Atualização na oficina",
                mensagem=(
                    f"Carro placa {placa_norm} atualizado "
                    f"por {usuario.get('nome') or 'usuário'}. "
                    f"Onde está: {onde_limpo or '-'}. "
                    f"Pronto: {'sim' if pronto else 'não'}."
                ),
                placa=placa,
            )

        st.success("Dados da oficina salvos (pátio do estoque sincronizado).")
        st.cache_data.clear()
        st.rerun()
    except Exception as erro:
        st.error(f"Erro ao salvar oficina: {erro}")



def importar_carros_estoque_para_oficina(usuario: Dict[str, Any]) -> None:
    """
    Empurra para a oficina todos os carros do estoque que ainda não
    estão cadastrados lá (comparação por placa normalizada).
    """
    if not usuario_tem("manage_oficina") and not usuario_e_gerente():
        st.error("Sem permissão para importar do estoque.")
        return

    try:
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    """
                    INSERT INTO public.oficina_carros (
                        marca,
                        modelo,
                        ano_modelo,
                        placa,
                        cor,
                        onde_esta,
                        estoque_carro_id,
                        atualizado_por_id
                    )
                    SELECT
                        COALESCE(e.marca, 'Sem marca'),
                        COALESCE(e.carro, e.modelo, 'Sem modelo'),
                        COALESCE(e.ano, '-'),
                        REPLACE(REPLACE(UPPER(COALESCE(e.placa, '')), '-', ''), ' ', ''),
                        e.cor,
                        e.patio,
                        e.id,
                        :usuario_id
                    FROM public.estoque_carros e
                    WHERE COALESCE(e.placa, '') <> ''
                      AND NOT EXISTS (
                          SELECT 1
                          FROM public.oficina_carros o
                          WHERE REPLACE(
                              REPLACE(UPPER(o.placa), '-', ''),
                              ' ',
                              ''
                          ) = REPLACE(
                              REPLACE(UPPER(COALESCE(e.placa, '')), '-', ''),
                              ' ',
                              ''
                          )
                      )
                    RETURNING id
                    """
                ),
                {"usuario_id": usuario["id"]},
            )
            ids = result.fetchall()
            qtd = len(ids)
            if qtd:
                notificar_usuarios_oficina(
                    conn,
                    titulo="Importação estoque → oficina",
                    mensagem=f"{qtd} carro(s) do estoque entraram na oficina.",
                    placa=None,
                )
        if qtd:
            st.success(f"{qtd} carro(s) importados do estoque para a oficina.")
            st.cache_data.clear()
            st.rerun()
        else:
            st.info("Nenhum carro novo do estoque para importar.")
    except Exception as erro:
        st.error(f"Erro ao importar estoque: {erro}")


def pagina_oficina(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("view_oficina"):
        st.error("Você não tem permissão para acessar a oficina.")
        return

    st.title("Oficina")
    st.caption(
        "Todos podem consultar e pesquisar. "
        "Gerente, admin, guariba e mecânico editam status, mecânica, "
        "lataria e valor final. "
        "'Onde está' sincroniza com o pátio do estoque."
    )

    pode_editar = usuario_pode_editar_oficina()
    pode_ver_detalhes = usuario_pode_ver_oficina_detalhes()

    if usuario_tem("manage_oficina") or usuario_e_gerente():
        if st.button(
            "📥 Importar carros do estoque",
            use_container_width=True,
            help="Copia para a oficina os carros do estoque ainda não cadastrados.",
        ):
            importar_carros_estoque_para_oficina(usuario)

        with st.expander("➕ Cadastrar carro na oficina", expanded=False):
            with st.form("form_novo_carro_oficina", clear_on_submit=True):
                c1, c2 = st.columns(2)
                marca = c1.text_input("Marca*")
                modelo = c2.text_input("Modelo*")
                c3, c4 = st.columns(2)
                ano_modelo = c3.text_input("Ano/modelo*")
                placa = c4.text_input("Placa*")
                cor = st.text_input("Cor")
                salvar = st.form_submit_button(
                    "Cadastrar",
                    use_container_width=True,
                    type="primary",
                )
            if salvar:
                cadastrar_carro_oficina(
                    usuario,
                    marca,
                    modelo,
                    ano_modelo,
                    placa,
                    cor,
                )

    aba_lista, aba_pesquisa = st.tabs(["Carros", "Pesquisar"])

    def render_lista(df: pd.DataFrame, chave: str) -> None:
        if df.empty:
            st.info("Nenhum carro encontrado na oficina.")
            return

        for _, carro in df.iterrows():
            status = "✅ Pronto" if bool(carro.get("pronto")) else "🔧 Em andamento"
            titulo = (
                f"{status} · {carro.get('marca') or '-'} "
                f"{carro.get('modelo') or '-'} "
                f"({carro.get('ano_modelo') or '-'}) · "
                f"Placa {carro.get('placa') or '-'}"
            )
            with st.expander(titulo, expanded=False):
                col_a, col_b, col_c = st.columns(3)
                col_a.write(f"**Marca:** {carro.get('marca') or '-'}")
                col_b.write(f"**Modelo:** {carro.get('modelo') or '-'}")
                col_c.write(f"**Ano/modelo:** {carro.get('ano_modelo') or '-'}")
                col_a.write(f"**Placa:** {carro.get('placa') or '-'}")
                col_b.write(f"**Cor:** {carro.get('cor') or '-'}")
                col_c.write(
                    f"**Onde está:** {carro.get('onde_esta') or '-'}"
                )
                st.write(
                    f"**Observação:** {carro.get('observacao') or '-'}"
                )
                if pode_ver_detalhes:
                    st.markdown("---")
                    st.write(
                        f"**Mecânica:** {carro.get('mecanica') or '-'}"
                    )
                    st.write(
                        f"**Lataria:** {carro.get('lataria') or '-'}"
                    )
                    st.write(
                        f"**Valor final:** {carro.get('valor_final') or '-'}"
                    )
                st.caption(
                    f"**Responsável:** {carro.get('atualizado_por_nome') or '—'} "
                    f"· Atualizado em "
                    f"{formatar_data_br(carro.get('updated_at'), True)}"
                )

                if pode_editar:
                    with st.form(f"form_oficina_{chave}_{carro['id']}"):
                        onde_esta = st.text_input(
                            "Onde está",
                            value=str(carro.get("onde_esta") or ""),
                        )
                        pronto = st.checkbox(
                            "Pronto",
                            value=bool(carro.get("pronto")),
                        )
                        observacao = st.text_area(
                            "Observação",
                            value=str(carro.get("observacao") or ""),
                        )
                        mecanica = st.text_area(
                            "Mecânica",
                            value=str(carro.get("mecanica") or ""),
                        )
                        lataria = st.text_area(
                            "Lataria",
                            value=str(carro.get("lataria") or ""),
                        )
                        valor_final = st.text_input(
                            "Valor final",
                            value=str(carro.get("valor_final") or ""),
                        )
                        cor_edit = st.text_input(
                            "Cor",
                            value=str(carro.get("cor") or ""),
                        )
                        gravar = st.form_submit_button(
                            "Salvar alterações",
                            use_container_width=True,
                            type="primary",
                        )
                    if gravar:
                        salvar_oficina_carro(
                            usuario,
                            int(carro["id"]),
                            str(carro.get("placa") or ""),
                            onde_esta,
                            pronto,
                            observacao,
                            mecanica,
                            lataria,
                            valor_final,
                            cor_edit,
                        )

    with aba_lista:
        try:
            render_lista(obter_oficina_carros(), "lista")
        except Exception as erro:
            st.error(
                "Não foi possível carregar a oficina. "
                "Execute schema_oficina.sql no Supabase. "
                f"Detalhe: {erro}"
            )

    with aba_pesquisa:
        with st.form("form_pesquisa_oficina"):
            busca_digitada = st.text_input(
                "Pesquisar na oficina",
                placeholder="Placa, marca, modelo, ano ou cor",
                key="busca_oficina_campo",
            )
            pesquisar = st.form_submit_button(
                "Pesquisar",
                use_container_width=True,
            )
        if pesquisar:
            st.session_state["busca_oficina_aplicada"] = busca_digitada
        busca = st.session_state.get("busca_oficina_aplicada", "")
        if not busca.strip():
            st.info(
                "Digite placa, marca, modelo, ano ou cor para pesquisar."
            )
        else:
            try:
                render_lista(
                    obter_oficina_carros(busca),
                    "pesquisa",
                )
            except Exception as erro:
                st.error(f"Erro ao pesquisar oficina: {erro}")




# ============================================================
# WHATSAPP EM MASSA (fase de teste)
# ============================================================
#
# COMO FUNCIONA (duas camadas):
#
# 1) Python / Streamlit (esta página)
#    - Filtra leads por status (aprovados / negados / vendidos) + período
#    - Monta a mensagem com placeholders {nome}, {carro}, {vendedor}
#    - Gera links wa.me (funciona no celular sem QR)
#    - Opcionalmente enfileira envio via serviço Node (whatsapp-web.js)
#
# 2) Node / whatsapp-web.js (serviço separado — veja whatsapp_service/)
#    - Cada usuário do sistema tem uma sessão própria (pasta sessions/{user_id})
#    - Gera QR Code na primeira conexão (desktop)
#    - No celular o fluxo normal do WhatsApp Web já autentica
#    - Endpoint HTTP local: POST /send  { session, phones[], message }
#
# Para ativar o envio real via Node:
#   1. cd whatsapp_service && npm install && node server.js
#   2. Defina em secrets: [whatsapp] base_url = "http://localhost:3100"
#   3. Descomente o bloco "ENVIO REAL" abaixo
#
# ---------------------------------------------------------------------------

def pagina_whatsapp(usuario: Dict[str, Any]) -> None:
    """Disparo de mensagens em massa (teste) para leads filtrados."""
    if not usuario_e_gestor() and usuario["tipo"] != "vendedor":
        st.error("Sem permissão para o módulo WhatsApp.")
        return

    st.title("WhatsApp em massa")
    st.caption(
        "Fase de teste. No celular os links abrem o app direto. "
        "No desktop, conecte a sessão (QR) pelo serviço Node quando ativado."
    )

    # ---- Sessão WhatsApp (QR) ----
    with st.expander("📱 Minha sessão WhatsApp (QR Code)", expanded=False):
        st.markdown(
            """
            **Desktop:** suba o serviço `whatsapp_service` e clique em
            *Gerar QR*. Escaneie com o WhatsApp do celular.

            **Celular:** não precisa de QR — use os botões *Abrir no WhatsApp*
            que geram `wa.me` e abrem o app nativo.
            """
        )
        # Placeholder visual — o QR real vem do serviço Node
        st.info(
            f"Sessão deste usuário: `user_{usuario['id']}`. "
            "Quando o serviço Node estiver online, o QR aparece aqui."
        )
        # ENVIO REAL (descomente quando o Node estiver rodando):
        # try:
        #     import requests
        #     base = st.secrets.get("whatsapp", {}).get("base_url", "http://localhost:3100")
        #     r = requests.get(f"{base}/qr/{usuario['id']}", timeout=5)
        #     if r.ok and r.json().get("qr"):
        #         st.image(r.json()["qr"])
        #     else:
        #         st.caption(r.json().get("status", "Aguardando QR…"))
        # except Exception as erro:
        #     st.warning(f"Serviço WhatsApp offline: {erro}")

    # ---- Filtros de destinatários ----
    st.subheader("Destinatários")
    # default em session_state evita o placeholder "Choose options" vazio
    if "wa_status_alvo" not in st.session_state:
        st.session_state["wa_status_alvo"] = ["aprovados"]
    status_alvo = st.multiselect(
        "Status dos leads",
        options=["aprovados", "negados", "vendidos"],
        key="wa_status_alvo",
        format_func=lambda v: {
            "aprovados": "Aprovados",
            "negados": "Negados / recusados",
            "vendidos": "Vendidos",
        }.get(v, v),
    )
    if not status_alvo:
        st.info("Selecione ao menos um status (aprovados, negados ou vendidos).")
        status_alvo = ["aprovados"]  # evita travar a tela

    periodo_wa = st.selectbox(
        "Período",
        ["mes_atual", "mes_anterior", "todos", "personalizado"],
        format_func=lambda v: {
            "mes_atual": "Este mês",
            "mes_anterior": "Mês anterior",
            "todos": "Todo o período",
            "personalizado": "Personalizado",
        }[v],
    )
    di, df_ = None, None
    hoje = date.today()
    prim = hoje.replace(day=1)
    if periodo_wa == "mes_atual":
        di, df_ = prim, hoje
    elif periodo_wa == "mes_anterior":
        df_ = prim - timedelta(days=1)
        di = df_.replace(day=1)
    elif periodo_wa == "personalizado":
        rng = st.date_input("Intervalo", value=(prim, hoje), key="wa_periodo")
        if isinstance(rng, (tuple, list)) and len(rng) == 2:
            di, df_ = rng

    # Monta condições SQL a partir dos status escolhidos
    conds = []
    if "aprovados" in status_alvo:
        conds.append("COALESCE(l.aprovou_credito, FALSE) = TRUE")
    if "negados" in status_alvo:
        conds.append(
            "(l.gerou_ficha = TRUE AND COALESCE(l.aprovou_credito, TRUE) = FALSE)"
        )
    if "vendidos" in status_alvo:
        conds.append(
            "(COALESCE(l.venda_concluida, FALSE) = TRUE OR COALESCE(l.vendeu, FALSE) = TRUE)"
        )
    if not conds:
        conds = ["COALESCE(l.aprovou_credito, FALSE) = TRUE"]

    escopo, params = escopo_leads(usuario)
    params = dict(params)
    filtros = [escopo, "(" + " OR ".join(conds) + ")"]
    if di is not None:
        filtros.append("l.data_lead >= :wa_di")
        params["wa_di"] = di
    if df_ is not None:
        filtros.append("l.data_lead < :wa_df")
        params["wa_df"] = df_ + timedelta(days=1)

    query = text(
        f"""
        SELECT l.id, l.nome_lead, l.telefone, l.carro_selecionado,
               v.nome AS nome_vendedor
        FROM public.leads l
        LEFT JOIN public.vendedores v ON v.id = l.vendedor_id
        WHERE {" AND ".join(f"({f})" for f in filtros)}
          AND l.telefone IS NOT NULL
        ORDER BY l.updated_at DESC NULLS LAST
        LIMIT 500
        """
    )
    try:
        with engine.connect() as conn:
            df_dest = pd.read_sql_query(query, conn, params=params)
    except Exception as erro:
        st.error(f"Erro ao buscar destinatários: {erro}")
        return

    st.caption(f"{len(df_dest)} destinatário(s) encontrados.")
    if not df_dest.empty:
        st.dataframe(
            df_dest[["nome_lead", "telefone", "carro_selecionado", "nome_vendedor"]],
            use_container_width=True,
            hide_index=True,
        )

    st.subheader("Mensagem")
    st.caption("Placeholders: {nome} {carro} {vendedor}")
    modelo = st.text_area(
        "Texto",
        value=(
            "Olá {nome}! Aqui é da Manu Automóveis. "
            "Sobre o {carro}: podemos conversar?"
        ),
        height=120,
    )

    if st.button("Gerar links wa.me", type="primary", use_container_width=True):
        if df_dest.empty:
            st.warning("Nenhum destinatário.")
        else:
            st.markdown("### Links (abra no celular ou clique)")
            for _, row in df_dest.iterrows():
                link = gerar_link_whatsapp(row.get("telefone"))
                if not link:
                    continue
                msg = (
                    modelo.replace("{nome}", str(row.get("nome_lead") or ""))
                    .replace("{carro}", str(row.get("carro_selecionado") or "veículo"))
                    .replace("{vendedor}", str(row.get("nome_vendedor") or ""))
                )
                from urllib.parse import quote
                url = f"{link}?text={quote(msg)}"
                st.markdown(f"- **{row.get('nome_lead')}**: [Abrir WhatsApp]({url})")

    # ENVIO REAL via Node (descomente para ativar):
    # if st.button("Enviar via sessão WhatsApp Web"):
    #     import requests
    #     base = st.secrets.get("whatsapp", {}).get("base_url", "http://localhost:3100")
    #     payload = {
    #         "session": f"user_{usuario['id']}",
    #         "messages": [
    #             {
    #                 "phone": str(row["telefone"]),
    #                 "text": modelo.replace("{nome}", str(row.get("nome_lead") or ""))
    #                         .replace("{carro}", str(row.get("carro_selecionado") or ""))
    #                         .replace("{vendedor}", str(row.get("nome_vendedor") or "")),
    #             }
    #             for _, row in df_dest.iterrows()
    #         ],
    #     }
    #     try:
    #         r = requests.post(f"{base}/send", json=payload, timeout=60)
    #         st.success(r.json())
    #     except Exception as erro:
    #         st.error(f"Falha no envio: {erro}")




# ============================================================
# FATURAMENTO (Autorização de Faturamento — impressão)
# ============================================================
#
# Gera formulário alinhado ao PDF oficial.
# Campos de data/assinatura/KM final ficam em branco para caneta.
# PDF/HTML salvo no Storage (bucket manu_arquivos).
# Veículo na troca: só texto por enquanto (sem tabela de estoque de troca).
# ============================================================


def carregar_venda_para_faturamento(ficha_id: int) -> dict:
    """
    Faturamento puxa de FICHAS VENDIDAS (comprou = true), não de lead solto.
    Ano/modelo, banco, financiado, boletos e entrada_total vêm da ficha/lead.
    """
    query = text(
        """
        SELECT
            f.id AS ficha_id,
            f.lead_id,
            f.vendedor_id,
            COALESCE(l.nome_completo, l.nome_lead) AS nome,
            l.cpf AS cpf_cnpj,
            l.endereco, l.bairro, l.cidade, l.cep, l.email, l.telefone,
            l.carro_selecionado AS modelo,
            l.ano_carro AS ano_modelo,
            l.placa_carro AS placa,
            l.marca_carro AS marca,
            l.cor_carro AS cor,
            l.valor_carro,
            f.valor_veiculo,
            f.valor_financiado,
            f.valor_liberado,
            f.banco_contratado AS fin_banco,
            f.entrada_total,
            f.entrada_paga,
            f.valor_pendente,
            f.gerou_boleto,
            f.boleto_valor,
            f.boleto_meses,
            f.boleto_total,
            f.fin_meses,
            f.fin_valor_parcela,
            f.valor_entrada AS valor_entrada_ficha,
            v.nome AS vendedor_nome
        FROM public.fichas_credito f
        JOIN public.leads l ON l.id = f.lead_id
        LEFT JOIN public.vendedores v ON v.id = f.vendedor_id
        WHERE f.id = :id
          AND COALESCE(f.comprou, FALSE) = TRUE
        """
    )
    with engine.connect() as conn:
        row = conn.execute(query, {"id": ficha_id}).mappings().first()
    if not row:
        return {}
    dados = dict(row)

    # Boleto da venda → campo "Boleto (entrada) R$" + texto em observações
    # (NÃO vai para Qtd. parcelas / Valor parcela do financiamento)
    obs_boleto = ""
    if dados.get("gerou_boleto") and dados.get("boleto_meses"):
        try:
            bv = float(dados.get("boleto_valor") or 0)  # valor da parcela do boleto
            bm = int(dados.get("boleto_meses") or 0)
            bt = float(dados.get("boleto_total") or (bv * bm))  # TOTAL
            obs_boleto = (
                f"Observação: boleto de R$ {bt:,.2f}. "
                f"{bm}x de R$ {bv:,.2f}."
            ).replace(",", "X").replace(".", ",").replace("X", ".")
            # Campo "Boleto (entrada)" usa o TOTAL (parcela x meses)
            dados["entrada_boleto_sugerida"] = bt
            dados["boleto_parcela"] = bv
            dados["boleto_qtd"] = bm
        except Exception:
            obs_boleto = ""
            dados["entrada_boleto_sugerida"] = 0.0
    else:
        dados["entrada_boleto_sugerida"] = 0.0

    dados["observacoes"] = obs_boleto

    # Financiamento vem de "Cliente comprou" (fin_meses / fin_valor_parcela)
    # — NÃO de boleto e NÃO de ficha_bancos.
    dados["fin_parcelas"] = (
        int(dados["fin_meses"]) if dados.get("fin_meses") else None
    )
    try:
        dados["fin_valor_parcela"] = (
            float(dados["fin_valor_parcela"])
            if dados.get("fin_valor_parcela") is not None
            else None
        )
    except Exception:
        dados["fin_valor_parcela"] = None

    return dados


def listar_vendas_para_faturamento() -> pd.DataFrame:
    query = text(
        """
        SELECT
            f.id AS ficha_id,
            COALESCE(l.nome_completo, l.nome_lead) AS nome,
            l.placa_carro AS placa,
            l.carro_selecionado AS carro,
            l.ano_carro AS ano_modelo,
            v.nome AS vendedor_nome,
            f.data_compra,
            f.entrada_total,
            f.banco_contratado
        FROM public.fichas_credito f
        JOIN public.leads l ON l.id = f.lead_id
        LEFT JOIN public.vendedores v ON v.id = f.vendedor_id
        WHERE COALESCE(f.comprou, FALSE) = TRUE
        ORDER BY f.data_compra DESC NULLS LAST, f.id DESC
        LIMIT 300
        """
    )
    with engine.connect() as conn:
        return pd.read_sql_query(query, conn)


def html_autorizacao_faturamento(dados: dict) -> str:
    def v(chave, padrao=""):
        val = dados.get(chave)
        if val is None or (isinstance(val, float) and str(val) == "nan"):
            return padrao
        return str(val)

    def money(chave):
        try:
            n = float(dados.get(chave) or 0)
            return f"{n:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        except Exception:
            return "0,00"

    return f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"/>
<title>Autorização de Faturamento</title>
<style>
  @page {{ size: A4; margin: 12mm; }}
  body {{ font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #111; }}
  table {{ width: 100%; border-collapse: collapse; }}
  td, th {{ border: 1px solid #333; padding: 4px 6px; vertical-align: top; }}
  .noborder td {{ border: none; }}
  .titulo {{ text-align: center; font-size: 16px; font-weight: bold; letter-spacing: 1px; }}
  .secao {{ background: #eee; font-weight: bold; text-align: center; }}
  .assinaturas {{ margin-top: 28px; }}
  .assinaturas td {{ border: none; text-align: center; padding-top: 36px; }}
  @media print {{ .no-print {{ display: none !important; }} }}
</style>
</head>
<body>
<table class="noborder" style="margin-bottom:8px">
  <tr>
    <td style="width:30%"><strong>manu automóveis</strong><br/>RLINE AUTOMÓVEIS LTDA</td>
    <td class="titulo">AUTORIZAÇÃO DE FATURAMENTO</td>
    <td style="width:30%; font-size:10px; text-align:right">
      EST. INTENDENTE MAGALHÃES, 381<br/>OSWALDO CRUZ - 21310-790<br/>
      CNPJ: 59.548.124/0001-59<br/>TEL: (21) 3283-7207
    </td>
  </tr>
</table>
<table>
  <tr>
    <td colspan="3"><b>NOME:</b> {v('nome')}</td>
    <td colspan="2"><b>CPF/CNPJ:</b> {v('cpf_cnpj')}</td>
  </tr>
  <tr>
    <td colspan="3"><b>ENDEREÇO:</b> {v('endereco')}</td>
    <td colspan="2"><b>BAIRRO:</b> {v('bairro')}</td>
  </tr>
  <tr>
    <td><b>CIDADE:</b> {v('cidade')}</td>
    <td><b>CEP:</b> {v('cep')}</td>
    <td><b>EMAIL:</b> {v('email')}</td>
    <td colspan="2"><b>TELEFONE:</b> {v('telefone')}</td>
  </tr>
  <tr>
    <td><b>MARCA</b><br/>{v('marca')}</td>
    <td><b>MODELO</b><br/>{v('modelo')}</td>
    <td><b>ANO/MODELO</b><br/>{v('ano_modelo')}</td>
    <td><b>PLACA</b><br/>{v('placa')}</td>
    <td><b>COR</b><br/>{v('cor')}</td>
  </tr>
  <tr>
    <td colspan="5"><b>KILOMETRAGEM:</b> {v('kilometragem')}
      &nbsp;&nbsp; <i>(completar a caneta se necessário)</i></td>
  </tr>
</table>
<br/>
<table>
  <tr><td colspan="2" class="secao">I. NEGOCIAÇÃO</td></tr>
  <tr>
    <td style="width:50%">
      <b>ENTRADA</b><br/>
      DINHEIRO R$ {money('entrada_dinheiro')}<br/>
      CARTÃO DE DÉBITO R$ {money('entrada_debito')}<br/>
      CARTÃO DE CRÉDITO R$ {money('entrada_credito')}<br/>
      TRANSFERÊNCIA/PIX/DEPÓSITO R$ {money('entrada_transferencia')}<br/>
      BOLETO R$ {money('entrada_boleto')}<br/>
      <b>TOTAL DA ENTRADA R$ {money('entrada_total')}</b>
    </td>
    <td style="width:50%">
      <b>EM CASO DE VEÍCULO NA TROCA</b><br/>
      MARCA/MODELO: {v('troca_marca_modelo')}<br/>
      ANO/MODELO: {v('troca_ano_modelo')}<br/>
      PLACA: {v('troca_placa')}<br/>
      COR: {v('troca_cor')}<br/>
      KM: {v('troca_km')}
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <b>FINANCIAMENTO</b> —
      BANCO: {v('fin_banco')} &nbsp;
      QUANT. DE PARCELAS: {v('fin_parcelas')} &nbsp;
      VALOR DA PARCELA R$: {money('fin_valor_parcela')}
      &nbsp;|&nbsp; VALOR FINANCIADO/LIBERADO R$: {money('valor_liberado')}
    </td>
  </tr>
</table>
<br/>
<table>
  <tr><td class="secao">II. OUTRAS OBSERVAÇÕES</td></tr>
  <tr><td>
    IPVA 2026 POR CONTA DA {"LOJA" if dados.get("ipva_conta_loja") else "CLIENTE"}<br/>
    TRANSFERÊNCIA POR CONTA DO {"LOJA" if dados.get("transferencia_conta_loja") else "CLIENTE"}<br/>
    GARANTIA DE MOTOR E CAIXA DE MARCHA POR 90 DIAS OU 3 MIL KM RODADOS
    (KM A PARTIR DA SAÍDA DA LOJA)<br/>
    FOI CEDIDO UM DESCONTO NO VALOR DE R$ {money('desconto_valor')}<br/>
    {v('observacoes')}
  </td></tr>
</table>
<p style="font-size:9px; margin-top:10px">
Pelo presente instrumento a empresa declara as condições de garantia do motor e caixa de marcha...
</p>
<p><b>Rio de Janeiro,</b> ____ / ____ / ________ &nbsp; <i>(a caneta)</i></p>
<table class="assinaturas">
  <tr>
    <td>_________________________<br/>VENDEDOR<br/>{v('vendedor_nome')}</td>
    <td>_________________________<br/>GERENTE</td>
    <td>_________________________<br/>CLIENTE</td>
  </tr>
</table>
</body>
</html>
"""




def baixar_bytes_storage(bucket: str, path: str) -> Optional[bytes]:
    """Baixa arquivo do Storage (service_role)."""
    import urllib.request
    base_url, key = _supabase_config()
    if not base_url or not key or not path:
        return None
    url = (
        f"{base_url.rstrip('/')}/storage/v1/object/{bucket}/{path.lstrip('/')}"
    )
    req = urllib.request.Request(
        url,
        headers={"Authorization": f"Bearer {key}", "apikey": key},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read()
    except Exception:
        return None


def anexos_html_para_impressao(faturamento_id: int) -> str:
    """
    Monta seção HTML dos anexos (imagens embutidas em base64; PDFs com link).
    """
    import base64
    try:
        with engine.connect() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT storage_bucket, storage_path, nome_arquivo
                    FROM public.faturamento_anexos
                    WHERE faturamento_id = :id
                    ORDER BY id
                    """
                ),
                {"id": faturamento_id},
            ).mappings().all()
    except Exception:
        return ""
    if not rows:
        return ""

    partes = [
        '<div class="anexos-print" style="page-break-before: always;">',
        "<h3>Anexos / comprovantes</h3>",
    ]
    for r in rows:
        bucket = r.get("storage_bucket") or STORAGE_BUCKET_ARQUIVOS
        path = r.get("storage_path") or ""
        nome = r.get("nome_arquivo") or path.split("/")[-1]
        data = baixar_bytes_storage(bucket, path)
        lower = nome.lower()
        if data and any(lower.endswith(ext) for ext in (
            ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"
        )):
            # detect mime
            mime = "image/jpeg"
            if lower.endswith(".png"):
                mime = "image/png"
            elif lower.endswith(".webp"):
                mime = "image/webp"
            elif lower.endswith(".gif"):
                mime = "image/gif"
            b64 = base64.b64encode(data).decode("ascii")
            partes.append(
                f'<p><b>{nome}</b></p>'
                f'<img src="data:{mime};base64,{b64}" '
                f'style="max-width:100%; max-height:900px;"/>'
            )
        elif data and lower.endswith(".pdf"):
            b64 = base64.b64encode(data).decode("ascii")
            partes.append(
                f'<p><b>{nome}</b> (PDF — abra o arquivo baixado para imprimir)</p>'
                f'<embed src="data:application/pdf;base64,{b64}" '
                f'type="application/pdf" width="100%" height="500px"/>'
            )
        else:
            partes.append(f"<p>Anexo: {nome} (baixe separadamente se necessário)</p>")
    partes.append("</div>")
    return "\n".join(partes)


def html_completo_faturamento(faturamento_id: int, dados: Optional[dict] = None) -> str:
    """HTML do formulário + anexos embutidos para impressão/download."""
    if dados is None:
        with engine.connect() as conn:
            row = conn.execute(
                text("SELECT * FROM public.faturamentos WHERE id = :id"),
                {"id": faturamento_id},
            ).mappings().first()
        if not row:
            return ""
        dados = dict(row)
        dados["fin_parcelas"] = dados.get("fin_parcelas")
    base = html_autorizacao_faturamento(dados)
    # injeta anexos antes de </body>
    anexos = anexos_html_para_impressao(faturamento_id)
    if anexos and "</body>" in base:
        base = base.replace("</body>", anexos + "\n</body>")
    return base


def salvar_faturamento_db(usuario: dict, dados: dict) -> int:
    with engine.begin() as conn:
        fid = conn.execute(
            text(
                """
                INSERT INTO public.faturamentos (
                    lead_id, ficha_id, criado_por_id, loja,
                    nome, cpf_cnpj, endereco, bairro, cidade, cep, email, telefone,
                    marca, modelo, ano_modelo, placa, cor, kilometragem,
                    entrada_dinheiro, entrada_debito, entrada_credito,
                    entrada_transferencia, entrada_boleto, entrada_total,
                    troca_marca_modelo, troca_ano_modelo, troca_placa, troca_cor, troca_km,
                    fin_banco, fin_parcelas, fin_valor_parcela,
                    ipva_conta_loja, transferencia_conta_loja,
                    desconto_valor, observacoes, obs_editada_uma_vez,
                    vendedor_nome, status
                ) VALUES (
                    :lead_id, :ficha_id, :criado_por_id, :loja,
                    :nome, :cpf_cnpj, :endereco, :bairro, :cidade, :cep, :email, :telefone,
                    :marca, :modelo, :ano_modelo, :placa, :cor, :kilometragem,
                    :entrada_dinheiro, :entrada_debito, :entrada_credito,
                    :entrada_transferencia, :entrada_boleto, :entrada_total,
                    :troca_marca_modelo, :troca_ano_modelo, :troca_placa, :troca_cor, :troca_km,
                    :fin_banco, :fin_parcelas, :fin_valor_parcela,
                    :ipva_conta_loja, :transferencia_conta_loja,
                    :desconto_valor, :observacoes, FALSE,
                    :vendedor_nome, 'emitido'
                )
                RETURNING id
                """
            ),
            {
                "lead_id": dados.get("lead_id"),
                "ficha_id": dados.get("ficha_id"),
                "criado_por_id": usuario["id"],
                "loja": normalizar_loja(usuario.get("loja", "381")),
                "nome": dados.get("nome"),
                "cpf_cnpj": dados.get("cpf_cnpj"),
                "endereco": dados.get("endereco"),
                "bairro": dados.get("bairro"),
                "cidade": dados.get("cidade"),
                "cep": dados.get("cep"),
                "email": dados.get("email"),
                "telefone": dados.get("telefone"),
                "marca": dados.get("marca"),
                "modelo": dados.get("modelo"),
                "ano_modelo": dados.get("ano_modelo"),
                "placa": dados.get("placa"),
                "cor": dados.get("cor"),
                "kilometragem": dados.get("kilometragem"),
                "entrada_dinheiro": float(dados.get("entrada_dinheiro") or 0),
                "entrada_debito": float(dados.get("entrada_debito") or 0),
                "entrada_credito": float(dados.get("entrada_credito") or 0),
                "entrada_transferencia": float(dados.get("entrada_transferencia") or 0),
                "entrada_boleto": float(dados.get("entrada_boleto") or 0),
                "entrada_total": float(dados.get("entrada_total") or 0),
                "troca_marca_modelo": dados.get("troca_marca_modelo"),
                "troca_ano_modelo": dados.get("troca_ano_modelo"),
                "troca_placa": dados.get("troca_placa"),
                "troca_cor": dados.get("troca_cor"),
                "troca_km": dados.get("troca_km"),
                "fin_banco": dados.get("fin_banco"),
                "fin_parcelas": int(dados.get("fin_parcelas") or 0) or None,
                "fin_valor_parcela": float(dados.get("fin_valor_parcela") or 0) or None,
                "ipva_conta_loja": bool(dados.get("ipva_conta_loja", True)),
                "transferencia_conta_loja": bool(dados.get("transferencia_conta_loja", True)),
                "desconto_valor": float(dados.get("desconto_valor") or 0) or None,
                "observacoes": dados.get("observacoes"),
                "vendedor_nome": dados.get("vendedor_nome"),
            },
        ).scalar_one()
    return int(fid)


def pagina_faturamento(usuario: Dict[str, Any]) -> None:
    if not usuario_tem("view_faturamento") and not usuario_e_gestor():
        st.error("Sem permissão para faturamento.")
        return

    st.title("Faturamento")
    st.caption(
        "Puxa de **vendas** (ficha com cliente comprou). "
        "Ano/modelo, banco, parcelas e total de entrada vêm da ficha. "
        "Detalhe da entrada (dinheiro/pix/cartão) é preenchido na hora. "
        "Data, assinatura e KM final: a caneta na impressão."
    )

    try:
        vendas = listar_vendas_para_faturamento()
    except Exception as erro:
        st.error(f"Não foi possível listar vendas. Detalhe: {erro}")
        vendas = pd.DataFrame()

    pre: dict = {}
    ficha_sel = None

    # Prefill vindo de notificação / query string interna
    prefill_id = st.session_state.pop("faturamento_ficha_prefill", None)

    # Vendas do vendedor ainda sem faturamento (atalhos)
    if usuario.get("tipo") == "vendedor" and usuario.get("vendedor_id") and not vendas.empty:
        try:
            with engine.connect() as conn:
                pend = pd.read_sql_query(
                    text(
                        """
                        SELECT f.id AS ficha_id,
                               COALESCE(l.nome_completo, l.nome_lead) AS nome
                        FROM public.fichas_credito f
                        JOIN public.leads l ON l.id = f.lead_id
                        WHERE COALESCE(f.comprou, FALSE) = TRUE
                          AND f.vendedor_id = :vid
                          AND NOT EXISTS (
                              SELECT 1 FROM public.faturamentos ft
                              WHERE ft.ficha_id = f.id
                          )
                        ORDER BY f.data_compra DESC NULLS LAST
                        LIMIT 10
                        """
                    ),
                    conn,
                    params={"vid": int(usuario["vendedor_id"])},
                )
            if not pend.empty:
                st.info(
                    "Vendas confirmadas aguardando faturamento — clique para pré-preencher:"
                )
                cols = st.columns(min(len(pend), 4))
                for i, row in pend.iterrows():
                    with cols[i % len(cols)]:
                        if st.button(
                            f"#{int(row['ficha_id'])} {row['nome'][:18]}",
                            key=f"fat_pend_{int(row['ficha_id'])}",
                            use_container_width=True,
                        ):
                            st.session_state["faturamento_ficha_prefill"] = int(row["ficha_id"])
                            st.rerun()
        except Exception:
            pass

    if not vendas.empty:
        opcoes = [None] + vendas["ficha_id"].tolist()
        nomes = {None: "— escolha uma venda (ou à vista manual) —"}
        for _, r in vendas.iterrows():
            nomes[r["ficha_id"]] = (
                f"#{r['ficha_id']} {r['nome']} · {r.get('placa') or '-'} · "
                f"{r.get('carro') or ''} {r.get('ano_modelo') or ''} · "
                f"{r.get('vendedor_nome') or ''}"
            )
        default_ix = 0
        if prefill_id and prefill_id in opcoes:
            default_ix = opcoes.index(prefill_id)
        ficha_sel = st.selectbox(
            "Puxar dados de uma venda (ficha comprou)",
            options=opcoes,
            index=default_ix,
            format_func=lambda i: nomes.get(i, str(i)),
        )
        if ficha_sel:
            pre = carregar_venda_para_faturamento(int(ficha_sel))
            if not pre:
                st.warning("Venda não encontrada ou ainda não marcada como comprou.")
    else:
        st.info(
            "Nenhuma venda (comprou=true) no sistema. "
            "Para venda à vista sem ficha, peça ao admin para marcar a compra na ficha "
            "ou cadastre a venda antes."
        )

    # total entrada fixo da venda (não recalcula a partir dos pedaços até o usuário editar)
    entrada_total_venda = float(pre.get("entrada_total") or 0)

    with st.form("form_faturamento"):
        st.subheader("Cliente *")
        c1, c2 = st.columns(2)
        nome = c1.text_input("Nome*", value=str(pre.get("nome") or ""))
        cpf = c2.text_input("CPF/CNPJ*", value=str(pre.get("cpf_cnpj") or ""))
        endereco = st.text_input("Endereço*", value=str(pre.get("endereco") or ""))
        b1, b2, b3 = st.columns(3)
        bairro = b1.text_input("Bairro*", value=str(pre.get("bairro") or ""))
        cidade = b2.text_input("Cidade*", value=str(pre.get("cidade") or ""))
        cep = b3.text_input("CEP*", value=str(pre.get("cep") or ""))
        e1, e2 = st.columns(2)
        email = e1.text_input("E-mail*", value=str(pre.get("email") or ""))
        telefone = e2.text_input("Telefone*", value=str(pre.get("telefone") or ""))

        st.subheader("Veículo *")
        v1, v2, v3 = st.columns(3)
        marca = v1.text_input("Marca*", value=str(pre.get("marca") or ""))
        modelo = v2.text_input("Modelo*", value=str(pre.get("modelo") or ""))
        # ANO/MODELO exatamente como na ficha/lead
        ano_modelo = v3.text_input(
            "Ano/modelo*",
            value=str(pre.get("ano_modelo") or ""),
            help="Exatamente como cadastrado (ex.: 2023/2024).",
        )
        v4, v5, v6 = st.columns(3)
        placa = v4.text_input("Placa*", value=str(pre.get("placa") or ""))
        cor = v5.text_input("Cor*", value=str(pre.get("cor") or ""))
        km = v6.text_input(
            "Kilometragem (opcional)",
            value=str(pre.get("kilometragem") or ""),
            help="Pode ser preenchido a caneta na impressão.",
        )

        st.subheader("I. Negociação — Entrada (detalhe manual)")
        st.caption(
            f"Total da entrada na venda: **R$ {entrada_total_venda:,.2f}**. "
            "Preencha como o cliente pagou (dinheiro, pix, cartão…). "
            "A soma dos campos deve bater com o total."
        )
        n1, n2, n3 = st.columns(3)
        ent_din = n1.number_input("Dinheiro R$", min_value=0.0, step=100.0, value=0.0)
        ent_deb = n2.number_input("Débito R$", min_value=0.0, step=100.0, value=0.0)
        ent_cred = n3.number_input("Crédito R$", min_value=0.0, step=100.0, value=0.0)
        n4, n5, n6 = st.columns(3)
        ent_pix = n4.number_input("PIX/Transferência R$", min_value=0.0, step=100.0, value=0.0)
        ent_bol = n5.number_input(
            "Boleto (entrada) R$",
            min_value=0.0,
            step=100.0,
            value=float(pre.get("entrada_boleto_sugerida") or 0),
            help="Total do boleto (parcela × meses). Ex.: 10×500 = R$ 5.000.",
        )
        n6.metric("Total entrada (venda)", f"R$ {entrada_total_venda:,.2f}")

        st.subheader("Veículo na troca (opcional)")
        t1, t2 = st.columns(2)
        troca_mm = t1.text_input("Marca/Modelo troca")
        troca_ano = t2.text_input("Ano/modelo troca")
        t3, t4, t5 = st.columns(3)
        troca_placa = t3.text_input("Placa troca")
        troca_cor = t4.text_input("Cor troca")
        troca_km = t5.text_input("KM troca")

        st.subheader("Financiamento (da venda)")
        f1, f2, f3 = st.columns(3)
        fin_banco = f1.text_input("Banco*", value=str(pre.get("fin_banco") or ""))
        fin_parc = f2.number_input(
            "Qtd. parcelas*",
            min_value=0,
            step=1,
            value=int(pre.get("fin_parcelas") or 0),
            help="Parcelas do financiamento (análise do banco), não quantidade de boletos.",
        )
        fin_val = f3.number_input(
            "Valor parcela R$*",
            min_value=0.0,
            step=50.0,
            value=float(pre.get("fin_valor_parcela") or 0),
            help="Valor da parcela do financiamento aprovado no banco.",
        )
        valor_lib = st.number_input(
            "Valor liberado/financiado R$*",
            min_value=0.0,
            step=100.0,
            value=float(pre.get("valor_liberado") or pre.get("valor_financiado") or 0),
        )

        st.subheader("II. Outras observações")
        ipva_loja = st.checkbox("IPVA 2026 por conta da loja", value=True)
        transf_loja = st.checkbox("Transferência por conta da loja", value=True)
        desconto = st.number_input("Desconto cedido R$", min_value=0.0, step=100.0)
        obs_default = str(pre.get("observacoes") or "")
        obs = st.text_area(
            "Observações extras (opcional — boletos já vêm pré-preenchidos; "
            "depois de salvar só pode editar 1 vez)",
            value=obs_default,
        )

        anexos_up = st.file_uploader(
            "Anexos opcionais (comprovantes) — salvos no Storage",
            type=["pdf", "png", "jpg", "jpeg", "webp"],
            accept_multiple_files=True,
        )

        gerar = st.form_submit_button(
            "Salvar e gerar documento",
            type="primary",
            use_container_width=True,
        )

    if gerar:
        obrigatorios = {
            "Nome": nome,
            "CPF/CNPJ": cpf,
            "Endereço": endereco,
            "Bairro": bairro,
            "Cidade": cidade,
            "CEP": cep,
            "E-mail": email,
            "Telefone": telefone,
            "Marca": marca,
            "Modelo": modelo,
            "Ano/modelo": ano_modelo,
            "Placa": placa,
            "Cor": cor,
            "Banco": fin_banco,
        }
        faltando = [k for k, v in obrigatorios.items() if not str(v or "").strip()]
        if faltando:
            st.error("Campos obrigatórios faltando: " + ", ".join(faltando))
            return
        # ficha_sel opcional: venda à vista sem passar pelo ElfenAI
        dados = {
            "lead_id": pre.get("lead_id"),
            "ficha_id": int(ficha_sel) if ficha_sel else None,
            "nome": nome.strip(),
            "cpf_cnpj": cpf.strip(),
            "endereco": endereco.strip(),
            "bairro": bairro.strip(),
            "cidade": cidade.strip(),
            "cep": cep.strip(),
            "email": email.strip(),
            "telefone": telefone.strip(),
            "marca": marca.strip(),
            "modelo": modelo.strip(),
            "ano_modelo": ano_modelo.strip(),
            "placa": normalizar_placa(placa) or placa.strip(),
            "cor": cor.strip(),
            "kilometragem": km.strip(),
            "entrada_dinheiro": ent_din,
            "entrada_debito": ent_deb,
            "entrada_credito": ent_cred,
            "entrada_transferencia": ent_pix,
            "entrada_boleto": ent_bol,
            "entrada_total": entrada_total_venda,  # sempre o da venda
            "troca_marca_modelo": troca_mm.strip() or None,
            "troca_ano_modelo": troca_ano.strip() or None,
            "troca_placa": troca_placa.strip() or None,
            "troca_cor": troca_cor.strip() or None,
            "troca_km": troca_km.strip() or None,
            "fin_banco": fin_banco.strip(),
            "fin_parcelas": fin_parc,
            "fin_valor_parcela": fin_val,
            "valor_liberado": valor_lib,
            "ipva_conta_loja": ipva_loja,
            "transferencia_conta_loja": transf_loja,
            "desconto_valor": desconto,
            "observacoes": obs.strip() or None,
            "vendedor_nome": pre.get("vendedor_nome") or usuario.get("nome") or "",
        }
        try:
            fid = salvar_faturamento_db(usuario, dados)
            html = html_autorizacao_faturamento(dados)
            caminho = caminho_storage_unico(f"faturamentos/{fid}", f"faturamento_{fid}.html")
            path_ok = upload_para_storage(
                STORAGE_BUCKET_ARQUIVOS,
                caminho,
                html.encode("utf-8"),
                "text/html; charset=utf-8",
            )
            if path_ok:
                with engine.begin() as conn:
                    conn.execute(
                        text(
                            """
                            UPDATE public.faturamentos
                            SET storage_bucket = :b, storage_path = :p, updated_at = NOW()
                            WHERE id = :id
                            """
                        ),
                        {"b": STORAGE_BUCKET_ARQUIVOS, "p": path_ok, "id": fid},
                    )
            # anexos opcionais
            if anexos_up:
                for arq in anexos_up:
                    try:
                        conteudo = arq.getvalue()
                        nome_arq = arq.name or "anexo.bin"
                        pth = caminho_storage_unico(f"faturamentos/{fid}/anexos", nome_arq)
                        mime = arq.type or "application/octet-stream"
                        ok_path = upload_para_storage(
                            STORAGE_BUCKET_ARQUIVOS, pth, conteudo, mime
                        )
                        if ok_path:
                            with engine.begin() as conn:
                                conn.execute(
                                    text(
                                        """
                                        INSERT INTO public.faturamento_anexos
                                            (faturamento_id, storage_bucket, storage_path, nome_arquivo)
                                        VALUES (:fid, :b, :p, :n)
                                        """
                                    ),
                                    {
                                        "fid": fid,
                                        "b": STORAGE_BUCKET_ARQUIVOS,
                                        "p": ok_path,
                                        "n": nome_arq,
                                    },
                                )
                    except Exception as err_an:
                        st.warning(f"Anexo {getattr(arq,'name', '?')} falhou: {err_an}")

            # Regenera HTML com anexos embutidos (para imprimir junto)
            html_full = html_completo_faturamento(fid, dados)
            # atualiza storage
            caminho2 = caminho_storage_unico(
                f"faturamentos/{fid}", f"faturamento_{fid}.html"
            )
            upload_para_storage(
                STORAGE_BUCKET_ARQUIVOS,
                caminho2,
                html_full.encode("utf-8"),
                "text/html; charset=utf-8",
            )
            with engine.begin() as conn:
                conn.execute(
                    text(
                        """
                        UPDATE public.faturamentos
                        SET storage_bucket = :b, storage_path = :p, updated_at = NOW()
                        WHERE id = :id
                        """
                    ),
                    {"b": STORAGE_BUCKET_ARQUIVOS, "p": caminho2, "id": fid},
                )
            st.success(f"Faturamento #{fid} salvo.")
            st.session_state["faturamento_html_preview"] = html_full
            st.session_state["faturamento_id_preview"] = fid
        except Exception as erro:
            st.error(
                "Erro ao salvar. Rode o schema atualizado "
                "(faturamentos + faturamento_anexos + obs_editada_uma_vez). "
                f"Detalhe: {erro}"
            )

    if st.session_state.get("faturamento_html_preview"):
        fid_prev = st.session_state.get("faturamento_id_preview")
        st.subheader(f"Pré-visualização — #{fid_prev}")
        st.caption(
            "Ctrl+P / Cmd+P imprime formulário + anexos (imagens). "
            "PDFs: use o download do anexo se o navegador não embutir."
        )
        __import__("streamlit.components.v1", fromlist=["html"]).html(
            st.session_state["faturamento_html_preview"],
            height=900,
            scrolling=True,
        )
        st.download_button(
            "⬇️ Baixar HTML (formulário + anexos)",
            data=st.session_state["faturamento_html_preview"].encode("utf-8"),
            file_name=f"faturamento_{fid_prev}.html",
            mime="text/html",
            key=f"dl_html_preview_{fid_prev}",
        )

    # ---- Histórico com filtros ----
    st.markdown("---")
    st.subheader("Histórico de faturamentos")
    fc1, fc2, fc3 = st.columns(3)
    f_nome = fc1.text_input("Filtro nome cliente", key="fat_f_nome")
    f_vend = fc2.text_input("Filtro vendedor", key="fat_f_vend")
    f_placa = fc3.text_input("Filtro placa", key="fat_f_placa")
    fc4, fc5, fc6 = st.columns(3)
    f_cpf = fc4.text_input("Filtro CPF/CNPJ", key="fat_f_cpf")
    f_carro = fc5.text_input("Filtro carro/modelo", key="fat_f_carro")
    f_entrada = fc6.text_input("Filtro entrada total (núm.)", key="fat_f_ent")

    try:
        with engine.connect() as conn:
            hist = pd.read_sql_query(
                text(
                    """
                    SELECT
                        id,
                        vendedor_nome,
                        nome,
                        cpf_cnpj,
                        placa,
                        modelo,
                        entrada_total,
                        status,
                        created_at,
                        obs_editada_uma_vez
                    FROM public.faturamentos
                    ORDER BY created_at DESC
                    LIMIT 200
                    """
                ),
                conn,
            )
        if hist.empty:
            st.info("Nenhum faturamento ainda.")
        else:
            if f_nome:
                hist = hist[hist["nome"].fillna("").str.contains(f_nome, case=False, na=False)]
            if f_vend:
                hist = hist[hist["vendedor_nome"].fillna("").str.contains(f_vend, case=False, na=False)]
            if f_placa:
                hist = hist[hist["placa"].fillna("").str.contains(f_placa, case=False, na=False)]
            if f_cpf:
                hist = hist[hist["cpf_cnpj"].fillna("").str.contains(f_cpf, case=False, na=False)]
            if f_carro:
                hist = hist[hist["modelo"].fillna("").str.contains(f_carro, case=False, na=False)]
            if f_entrada:
                try:
                    val = float(f_entrada.replace(",", "."))
                    hist = hist[hist["entrada_total"].fillna(0).astype(float) == val]
                except Exception:
                    pass

            st.dataframe(
                hist.rename(columns={
                    "vendedor_nome": "Vendedor",
                    "nome": "Cliente",
                    "cpf_cnpj": "CPF/CNPJ",
                    "placa": "Placa",
                    "modelo": "Carro",
                    "entrada_total": "Entrada total",
                    "status": "Status",
                    "created_at": "Criado em",
                    "obs_editada_uma_vez": "Obs já editada",
                }),
                use_container_width=True,
                hide_index=True,
            )

            # Edição única de observações / exclusão admin
            ids = hist["id"].tolist() if not hist.empty else []
            if ids:
                sel = st.selectbox("Selecionar faturamento", ids, key="fat_sel_hist")
                row = hist[hist["id"] == sel].iloc[0]
                ja_editou = bool(row.get("obs_editada_uma_vez"))

                # Download / pré-visualização sempre disponível
                try:
                    html_hist = html_completo_faturamento(int(sel))
                except Exception as err_h:
                    html_hist = ""
                    st.caption(f"Não gerou HTML: {err_h}")
                if html_hist:
                    st.download_button(
                        "⬇️ Baixar HTML deste faturamento",
                        data=html_hist.encode("utf-8"),
                        file_name=f"faturamento_{int(sel)}.html",
                        mime="text/html",
                        key=f"dl_html_hist_{int(sel)}",
                    )
                    if st.button(
                        "Ver / imprimir este faturamento",
                        key=f"ver_fat_{int(sel)}",
                    ):
                        st.session_state["faturamento_html_preview"] = html_hist
                        st.session_state["faturamento_id_preview"] = int(sel)
                        st.rerun()
                if not ja_editou:
                    nova_obs = st.text_area(
                        "Editar observações (somente 1 vez)",
                        key=f"fat_obs_edit_{sel}",
                    )
                    if st.button("Salvar observação (1x)", key=f"fat_obs_save_{sel}"):
                        with engine.begin() as conn:
                            conn.execute(
                                text(
                                    """
                                    UPDATE public.faturamentos
                                    SET observacoes = :o,
                                        obs_editada_uma_vez = TRUE,
                                        updated_at = NOW()
                                    WHERE id = :id
                                      AND COALESCE(obs_editada_uma_vez, FALSE) = FALSE
                                    """
                                ),
                                {"o": nova_obs, "id": int(sel)},
                            )
                        st.success("Observação atualizada (não poderá editar de novo).")
                        st.rerun()
                else:
                    st.caption("Observações deste faturamento já foram editadas uma vez.")

                if usuario_e_gestor() or usuario.get("tipo") == "admin":
                    if st.button("Apagar faturamento (só gerente/admin)", key=f"fat_del_{sel}"):
                        with engine.begin() as conn:
                            conn.execute(
                                text("DELETE FROM public.faturamento_anexos WHERE faturamento_id = :id"),
                                {"id": int(sel)},
                            )
                            conn.execute(
                                text("DELETE FROM public.faturamentos WHERE id = :id"),
                                {"id": int(sel)},
                            )
                        st.success("Faturamento apagado.")
                        st.rerun()
    except Exception as erro:
        st.caption(f"Histórico indisponível até rodar o schema. ({erro})")



# ============================================================
# SUPORTE IA — Manu Automóveis Suporte
# ============================================================
#
# Chat de ajuda para o usuário logado.
# - Contexto do banco APENAS do próprio escopo (vendedor = só dele)
# - Não modifica dados, não expõe outros vendedores
# - Identidade: "Manu Automóveis Suporte"
# - Se houver st.secrets["xai"]["api_key"] usa API Grok; senão responde
#   com análise local dos números do usuário.
# ============================================================

def _contexto_usuario_para_ia(usuario: Dict[str, Any]) -> str:
    """Monta texto com métricas e pendências só do escopo do usuário."""
    linhas = [
        f"Usuário: {usuario.get('nome')} | tipo: {usuario.get('tipo')} | loja: {usuario.get('loja')}",
    ]
    tipo = usuario.get("tipo")
    try:
        # Período: este mês
        hoje = date.today()
        di = hoje.replace(day=1)
        metricas = obter_metricas(usuario, data_inicio=di, data_fim=hoje)
        linhas.append(
            f"Métricas deste mês (escopo do usuário): "
            f"leads={metricas.get('total_leads', 0)}, "
            f"responderam={metricas.get('total_responderam', 0)}, "
            f"fichas={metricas.get('total_fichas', 0)}, "
            f"aprovados={metricas.get('total_aprovados', 0)}, "
            f"vendidos={metricas.get('total_vendidos', 0)}"
        )
    except Exception as erro:
        linhas.append(f"(métricas indisponíveis: {erro})")

    # Leads sem resposta (só do escopo)
    try:
        df = buscar_leads(
            usuario, "nao_responderam", "", limite=15,
            data_inicio=di, data_fim=hoje,
        )
        if not df.empty:
            nomes = df.get("nome_lead", df.get("nome_completo", pd.Series())).head(8).tolist()
            linhas.append(
                f"Leads sem resposta recentes (amostra, só seus): {nomes}"
            )
            linhas.append(f"Total sem resposta no filtro: {len(df)}")
    except Exception:
        pass

    # Tarefas pendentes do usuário
    try:
        tar = obter_tarefas(usuario)
        if not tar.empty:
            pend = tar[tar["resposta"].isna()] if "resposta" in tar.columns else tar
            linhas.append(f"Tarefas visíveis: {len(tar)} | pendentes de resposta: {len(pend)}")
    except Exception:
        pass

    if tipo == "vendedor":
        linhas.append(
            "REGRAS: este usuário é vendedor. Nunca mencione dados de outros vendedores. "
            "Sugira ações práticas: follow-up WhatsApp, priorizar cliente na loja, "
            "completar ficha, revisar negados."
        )
    elif tipo in {"admin", "gerente", "marketing"}:
        linhas.append(
            "Usuário gestor: pode falar de visão geral da loja/escopo dele, "
            "sem inventar números fora do contexto fornecido."
        )
    else:
        linhas.append(
            "Responda só sobre o que for relevante ao perfil "
            f"({tipo}): estoque, oficina, documentos, crédito, etc."
        )

    linhas.append(
        "Você NÃO pode alterar banco de dados, código ou permissões. "
        "Apenas orientar e responder perguntas."
    )
    return "\n".join(linhas)


def _resposta_local_ia(pergunta: str, contexto: str, usuario: Dict[str, Any]) -> str:
    """Fallback sem API: dicas baseadas nos números do contexto."""
    p = (pergunta or "").lower()
    nome = usuario.get("nome") or "colega"

    if any(x in p for x in ("quem é você", "quem e voce", "quem voce", "who are you")):
        return (
            "Sou **Manu Automóveis Suporte** — assistente interno de ajuda. "
            "Posso analisar seus números (só do seu acesso) e sugerir próximos passos. "
            "Não altero dados do sistema."
        )

    # extrai números do contexto se possível
    leads = responderam = fichas = aprovados = vendidos = 0
    for part in contexto.split(","):
        part = part.strip()
        if part.startswith("leads="):
            try:
                leads = int(part.split("=")[1])
            except Exception:
                pass
        elif part.startswith("responderam="):
            try:
                responderam = int(part.split("=")[1])
            except Exception:
                pass
        elif part.startswith("fichas="):
            try:
                fichas = int(part.split("=")[1])
            except Exception:
                pass
        elif part.startswith("aprovados="):
            try:
                aprovados = int(part.split("=")[1])
            except Exception:
                pass
        elif part.startswith("vendidos="):
            try:
                vendidos = int(part.split("=")[1])
            except Exception:
                pass

    taxa_resp = (100 * responderam / leads) if leads else 0
    taxa_ficha = (100 * fichas / leads) if leads else 0
    taxa_venda = (100 * vendidos / leads) if leads else 0

    dicas = []
    if "melhor" in p or "melhorar" in p or "dica" in p or "ajuda" in p or "como" in p:
        if leads and taxa_resp < 40:
            dicas.append(
                f"Sua taxa de resposta está em ~{taxa_resp:.0f}%. "
                "Priorize os leads **sem resposta** com WhatsApp no mesmo dia "
                "(mensagem curta + 2 horários de visita)."
            )
        if leads and taxa_ficha < 15 and responderam > 0:
            dicas.append(
                "Muita gente responde e pouca vira ficha. No atendimento, "
                "peça CPF e interesse no carro cedo e marque **cliente na loja** "
                "quando estiver presente — a ficha sobe na fila do crédito."
            )
        if fichas and aprovados == 0:
            dicas.append(
                "Há fichas sem aprovação ainda. Confirme se documentos e renda "
                "estão completos; fale com o ElfenAI/crédito sobre pendências."
            )
        if aprovados and vendidos == 0:
            dicas.append(
                "Você tem aprovados sem compra. Foque em fechar entrada, "
                "simular parcelas e agendar retorno com proposta pronta."
            )
        if not dicas:
            dicas.append(
                f"Neste mês: {leads} leads, {responderam} respostas, "
                f"{fichas} fichas, {aprovados} aprovados, {vendidos} vendas "
                f"(conv. lead→venda ~{taxa_venda:.1f}%). "
                "Mantenha follow-up diário nos quentes e registre tudo no sistema."
            )
        return (
            f"Olá, {nome}. Sou **Manu Automóveis Suporte**.\n\n"
            + "\n\n".join(f"• {d}" for d in dicas)
        )

    return (
        f"Sou **Manu Automóveis Suporte**. Vi seu contexto deste mês: "
        f"{leads} leads, {responderam} responderam, {fichas} fichas, "
        f"{aprovados} aprovados, {vendidos} vendas.\n\n"
        "Pergunte por exemplo: *como posso melhorar?*, *o que priorizar hoje?*, "
        "*como aumentar fichas?*. Não tenho acesso a dados de outros vendedores "
        "e não altero o sistema — só oriento."
    )


def _chamar_xai_chat(mensagens: list, contexto: str) -> Optional[str]:
    """Chama API xAI (Grok) se api_key estiver nos secrets."""
    import json
    import urllib.request
    import urllib.error

    try:
        key = st.secrets.get("xai", {}).get("api_key") or st.secrets.get("XAI_API_KEY")
    except Exception:
        key = None
    if not key:
        return None

    system = (
        "Você é Manu Automóveis Suporte, assistente interno da loja de carros. "
        "Quando perguntarem quem você é, responda exatamente que é Manu Automóveis Suporte. "
        "Use APENAS o contexto de dados abaixo (já filtrado ao usuário). "
        "Nunca invente dados de outros vendedores. "
        "Nunca diga que pode alterar banco, código ou permissões. "
        "Seja prático, curto e em português do Brasil.\n\n"
        f"CONTEXTO DO USUÁRIO:\n{contexto}"
    )
    payload = {
        "model": st.secrets.get("xai", {}).get("model", "grok-3"),
        "messages": [{"role": "system", "content": system}] + mensagens,
        "temperature": 0.5,
    }
    req = urllib.request.Request(
        "https://api.x.ai/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]
    except Exception as erro:
        return f"(API indisponível: {erro}. Usando modo local.)"


def pagina_suporte_ia(usuario: Dict[str, Any]) -> None:
    st.title("Manu Automóveis Suporte")
    st.caption(
        "Assistente de ajuda com base nos **seus** dados. "
        "Não acessa outros vendedores e não altera o sistema."
    )

    if "ia_mensagens" not in st.session_state:
        st.session_state["ia_mensagens"] = []

    # Histórico
    for msg in st.session_state["ia_mensagens"]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    pergunta = st.chat_input("Pergunte ao suporte…")
    if pergunta:
        st.session_state["ia_mensagens"].append(
            {"role": "user", "content": pergunta}
        )
        with st.chat_message("user"):
            st.markdown(pergunta)

        with st.chat_message("assistant"):
            # Indicador sutil de "digitando"
            placeholder = st.empty()
            placeholder.markdown("*Manu está digitando…*")

            contexto = _contexto_usuario_para_ia(usuario)
            historico_api = [
                {"role": m["role"], "content": m["content"]}
                for m in st.session_state["ia_mensagens"][-12:]
            ]
            resposta = _chamar_xai_chat(historico_api, contexto)
            if not resposta or resposta.startswith("(API indisponível"):
                local = _resposta_local_ia(pergunta, contexto, usuario)
                if resposta and resposta.startswith("(API"):
                    resposta = local + "\n\n" + resposta
                else:
                    resposta = local

            placeholder.markdown(resposta)

        st.session_state["ia_mensagens"].append(
            {"role": "assistant", "content": resposta}
        )

    if st.button("Limpar conversa", key="ia_limpar"):
        st.session_state["ia_mensagens"] = []
        st.rerun()


# ============================================================
# EXECUÇÃO PRINCIPAL
# ============================================================

if st.session_state["usuario_logado"] is None:
    mostrar_login()
    st.stop()


usuario_atual = st.session_state["usuario_logado"]
mostrar_sidebar(usuario_atual)


paginas_permitidas = set()

if usuario_tem("view_leads"):
    paginas_permitidas.add("leads")

if usuario_tem("view_stock"):
    paginas_permitidas.add("estoque")

if usuario_tem("view_transferencias"):
    paginas_permitidas.add("transferencias")

if usuario_tem("view_team"):
    paginas_permitidas.add("vendedores")

if usuario_tem("use_chat"):
    paginas_permitidas.add("chat")

if usuario_tem("view_credit_fichas"):
    paginas_permitidas.add("fichas")

if usuario_tem("view_oficina"):
    paginas_permitidas.add("oficina")

if usuario_tem("view_tasks"):
    paginas_permitidas.add("tarefas")

if usuario_tem("view_goals"):
    paginas_permitidas.add("metas")

if usuario_tem("view_faturamento") or usuario_e_gestor():
    paginas_permitidas.add("faturamento")

paginas_permitidas.add("suporte_ia")

if usuario_e_gestor() or st.session_state.get("usuario_logado", {}).get("tipo") == "vendedor":
    paginas_permitidas.add("whatsapp")

if not paginas_permitidas:
    paginas_permitidas.add("chat")

pagina_padrao = (
    "oficina"
    if usuario_atual["tipo"] in {"guariba", "mecanico"}
    else ("leads" if "leads" in paginas_permitidas else next(iter(paginas_permitidas)))
)

if st.session_state["pagina_atual"] not in paginas_permitidas:
    st.session_state["pagina_atual"] = pagina_padrao


pagina_atual = st.session_state["pagina_atual"]

if pagina_atual == "estoque":
    pagina_estoque(usuario_atual)
elif pagina_atual == "leads":
    if usuario_atual["tipo"] == "documentista":
        pagina_documentista(usuario_atual)
    else:
        pagina_leads(usuario_atual)
elif pagina_atual in {"documentos", "transferencias"}:
    pagina_documentista(usuario_atual)
elif pagina_atual == "vendedores":
    pagina_vendedores(usuario_atual)
elif pagina_atual == "chat":
    pagina_chat(usuario_atual)
elif pagina_atual == "fichas":
    pagina_fichas(usuario_atual)
elif pagina_atual == "oficina":
    pagina_oficina(usuario_atual)
elif pagina_atual == "tarefas":
    pagina_tarefas(usuario_atual)
elif pagina_atual == "metas":
    pagina_metas(usuario_atual)
elif pagina_atual == "faturamento":
    pagina_faturamento(usuario_atual)
elif pagina_atual == "suporte_ia":
    pagina_suporte_ia(usuario_atual)
elif pagina_atual == "whatsapp":
    pagina_whatsapp(usuario_atual)