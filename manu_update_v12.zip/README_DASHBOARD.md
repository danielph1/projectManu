# Dashboard Admin — Manu Automóveis

App **separado** do operacional (`app_manu.py`), só para **admin**.

## Instalação

```bash
pip install -r requirements_dashboard.txt
```

## Secrets

Use o **mesmo** `secrets.toml` / Streamlit Cloud secrets:

```toml
[postgres]
url = "postgresql://..."
```

## Rodar

```bash
streamlit run admin_dashboard.py
```

No Cloud: crie outro app apontando para `admin_dashboard.py` no mesmo repo, ou multi-page.

## O que tem

- Funil: lead → responderam → ficha → aprovados → compraram
- Finanças: bruto, liberado, entrada, pendente, oficina, líquido aproximado
- Projeção do próximo mês (média 1/2/3 meses + tendência)
- Desempenho por vendedor (vermelho se conversão/tarefas ruins)
- Guaribas e mecânicos (tarefas)
- Filtro **loja** (381 / 746 / NINA) ou **TODAS**
