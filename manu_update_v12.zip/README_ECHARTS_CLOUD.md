# Corrigir "Instale: pip install streamlit-echarts" no Streamlit Cloud

Instalar no **VS Code local não altera a nuvem**.

## No app do Dashboard (admin_dashboard.py)

1. Na raiz do repositório Git do Streamlit Cloud, tenha um arquivo **`requirements.txt`** com:

```
streamlit>=1.28
streamlit-echarts>=0.4.0
sqlalchemy>=2.0
pandas>=2.0
psycopg2-binary>=2.9
```

2. Commit + push
3. No Streamlit Cloud: **Manage app → Reboot** (ou aguarde o redeploy)

Sem essa linha `streamlit-echarts` no `requirements.txt` do **mesmo repo** do app, o gráfico continua em JSON.

## Conferir

Settings do app → General → mostra qual arquivo Python e se usa requirements.txt da raiz.
